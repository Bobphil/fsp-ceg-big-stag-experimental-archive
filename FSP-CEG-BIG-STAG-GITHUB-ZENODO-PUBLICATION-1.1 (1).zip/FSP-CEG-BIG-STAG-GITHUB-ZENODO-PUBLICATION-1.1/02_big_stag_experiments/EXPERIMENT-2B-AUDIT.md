# UCP-XR-EXPERIMENT-2B — Procedural Fragility Recognition and Warrant-Topology Reopening

## Purpose

Test whether a plurality-based BIG STAG system can recognize when an authorization is procedurally fragile without treating fragility as automatic defeat of the authorized action.

## Frozen fragility diagnostics

- **Vote splitting:** largest substantive action family differs from the authorized proposal family.
- **Agenda dependence:** removing/excluding an action family changes the authorized proposal.
- **Low participation:** fewer than 75% of the electorate participates.
- **Bloc concentration:** a coordinated bloc supplies the entire winning plurality.

## Response grammar

A recognized fragility:
1. leaves present authorization standing;
2. preserves the affected minority/warrant topology;
3. keeps inquiry open;
4. records a fragility-specific REOPEN commitment;
5. never equates authorization with truth or consensus;
6. never treats REOPEN as automatic reversal.

## Results

| Case | Authorization | Fragility | Scoped REOPEN | Authorization stands |
|---|---|---|---:|---|
| Control | P2_MONITOR | none | 0 | yes |
| Vote split | P3_STRONG | vote splitting | 1 | yes |
| Agenda exclusion | P1_DISCLOSURE | agenda dependence | 1 | yes |
| Coordinated bloc | P3_STRONG | vote splitting + bloc concentration | 2 | yes |
| Participation loss | P3_STRONG | low participation | 1 | yes |
| Return recomposition | P2_MONITOR | none at final phase | 0 | yes |

## Interpretation

The experiment distinguishes **procedural decisiveness** from **procedural robustness**. A plurality can still close action while carrying metadata that its authorization is sensitive to proposal fragmentation, agenda structure, participation, or coalition concentration. The response is not to pretend the vote never happened, nor to replace plurality with another voting rule. The response is to preserve the warrant topology whose structure made the result fragile and to precommit a narrowly matched path for REOPEN.

This yields the executable firewall:

> **Fragile authorization ≠ invalid authorization ≠ robust authorization.**

And:

> **REOPEN trigger ≠ reversal.**

## Case-specific reopening

- Vote splitting → proposal-family recount/reformulation.
- Agenda dependence → agenda reintroduction or alternative-proposal availability.
- Low participation → participation recovery or new Return evidence.
- Bloc concentration → independent Return or bloc decoupling.

## Important correction made during acceptance

The first 2B diagnostic incorrectly flagged the control case because it used “winner below 50% of the electorate” as part of the low-participation test. That conflated a normal plurality with turnout weakness. The criterion was corrected so **low participation is about turnout (<75%)**, not merely lack of an absolute-majority winner. No aggregation rule or fixture was changed.

## Claim ceiling

2B shows that the frozen BIG STAG plurality architecture can carry procedural-fragility metadata and scoped reopening commitments without collapsing action closure into inquiry closure. It does not establish that these four fragility diagnostics are exhaustive, that their thresholds are normatively correct, or that plurality is the preferred real-world aggregation mechanism.
