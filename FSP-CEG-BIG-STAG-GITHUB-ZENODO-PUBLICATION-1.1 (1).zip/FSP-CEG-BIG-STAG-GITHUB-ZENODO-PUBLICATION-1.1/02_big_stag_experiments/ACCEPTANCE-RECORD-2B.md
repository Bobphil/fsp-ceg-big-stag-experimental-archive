# UCP-XR-EXPERIMENT-2B — Acceptance Record

- Full inherited + 2B regression harness: **233/233 PASS**.
- 2B invariants: **12/12 PASS**.
- Inherited files checked (excluding intentional package-script extension): **107**.
- Inherited files changed unexpectedly: **0**.
- Canonical cases: CONTROL, VOTE_SPLIT, AGENDA_EXCLUSION, COORDINATED_BLOC, PARTICIPATION_LOSS, RETURN_RECOMPOSITION.
- Fragility recognition does **not** reverse authorization automatically.
- Recognized fragility creates a scoped REOPEN commitment and preserves the relevant minority topology.

## Claim ceiling

This establishes executable recognition of four procedural fragilities inside the frozen 2A aggregation fixtures. It does not establish optimal fragility thresholds, an optimal voting rule, or real-world democratic legitimacy.
