# UCP-XR-EXPERIMENT-2E — Return Network Audit

## Build
**Return Network: Task-Space PRF Coalitions, Message Channels, Warrant Reception, Escalation, Reconstruction, and REOPEN Termination**

2E is a diagnostic overlay on the exact Experiment 2D package. It does not compare alternative institutional designs yet. Its purpose is to decompose the abstract transition `Return → REOPEN` into observable institutional stages.

## Operational unit
A PRF remains an individual situated warrant-bearing agent. The operational actor in this experiment is a **task-space PRF coalition**: multiple PRFs with sufficient alternative-warrant convergence to support a bounded task while preserving internal warrant diversity.

Six task-space coalitions are represented:
- affected-party / consequence-detection,
- technical-anomaly,
- independent-review,
- authorization,
- plurality / coalition assembly,
- restoration / appeal.

Seven explicit message channels connect these coalitions. Each channel carries source, destination, latency, fidelity, independence, persistence, sender-standing requirement, receiver obligation, and escalation route.

## Expanded Return grammar
`consequence → situated detection → coalition message formation → governed channel → coalition reception → warrant uptake → warrant-topology reconstruction → escalation / authorization routing → plurality recomputation → REOPEN consequence → repair → termination`

2E also separates:
- **REOPEN signal** — a recognized reason to reconsider,
- **REOPEN uptake** — the reason enters an authorized institutional pathway,
- **REOPEN consequence** — the warrant topology is actually reopened/recomputed.

## Frozen diagnostic cases
| Case | Distinct result |
|---|---|
| CONTROL_SUCCESS | Detection, transmission, uptake, reconstruction, recomputation, repair, and termination all succeed. |
| DETECTION_FAILURE | Consequence never becomes a Return claim; no message is formed. |
| TRANSMISSION_FAILURE | Claim is formed but dropped before review receives it. |
| RECEPTION_FAILURE | Message arrives, but the receiving coalition does not credit it enough for uptake. |
| STANDING_FAILURE | Evidence is detected, but sender lacks recognized standing for the formal channel. |
| ESCALATION_FAILURE | Primary path is captured and the independent appeal route is blocked before assembly recomputation. |
| RECONSTRUCTION_FAILURE | Review credits the Return claim, but preserved records cannot reconstruct the prior warrant topology. |
| TERMINATION_FAILURE | Reopening changes the institutional state and repair completes, but review cannot be properly terminated. |

## Key result
The seven failures are behaviorally identifiable rather than being represented as one generic `REOPEN_FAILED` state. This matters because the appropriate repair depends on where the process failed.

A transmission repair cannot solve reception distrust. More standing does not reconstruct lost warrant records. Better detection does not cure trigger capture. And a successful repair does not itself establish that repeated review should terminate.

## Architectural implications
2D showed that fragility-response success depends on diagnostic coverage, trigger integrity, topology recoverability, and termination. 2E turns those dependencies into institutional pathways.

This gives the meta-governance functions sharper computational meaning:
- **Detection**: who can notice and characterize a relevant consequence?
- **Standing**: whose coalition claim is eligible for institutional attention?
- **Transmission**: through what channel can it travel, and with what fidelity/latency?
- **Reception**: how does the receiving coalition assess source, evidence, and warrants?
- **Escalation**: what independent route remains if the ordinary channel is blocked or captured?
- **Reconstruction**: can the earlier warrant topology be recovered rather than merely the winning decision?
- **Termination**: who can responsibly close review after the relevant repair condition is met?

## Important correction of vocabulary
Operational messages are **coalition-to-coalition**. Individual PRFs remain visible inside each coalition and retain their distinct warrants. No coalition is treated as internally unanimous merely because it supports a common bounded task.

## Claim ceiling
2E establishes deterministic executability and behavioral identifiability of a small Return/REOPEN communication network inside the synthetic BIG STAG model. It does **not** establish that the six coalitions, seven channels, standing rules, fidelity values, escalation structure, or termination arrangement are normatively optimal or empirically representative of real institutions.

The next valid comparison is therefore not yet “which government design is best.” It is to hold the same PRF population and Return events fixed while varying **channel architecture**: independence, redundancy, persistence, receiver obligations, cross-triggering, and termination authority. Only then can we test whether distributed channel design improves corrigibility under capture, delay, distortion, and information loss.
