# UCP-XR-EXPERIMENT-2D — Fragility-Response Layer Adversarial Stress

## Question
Does the scoped fragility-response grammar from Experiment 2C remain robust when the diagnostic and reopening layer itself is unreliable, strategic, captured, repetitive, or unable to reconstruct the relevant warrant topology?

## Architecture held fixed
Experiment 2D does **not** replace plurality, add a preferred aggregation rule, or strengthen the 2B diagnostics. It overlays adversarial conditions on the 2C response process and explicitly separates:

- true procedural fragility;
- observed fragility flags;
- response execution/effectiveness.

The response policies remain `IGNORE`, `MATCHED_REOPEN`, and `BLANKET_REOPEN`.

## Stress cases

### False-positive flag
A clean authorization is incorrectly labeled `VOTE_SPLIT`. Matched reopening performs an unnecessary review without changing authorization.

### Missed fragility
A real vote-splitting fragility is not flagged. Matched reopening has nothing to route and the fragility remains unresolved.

### Interacting fragilities
Vote splitting and low participation occur together. Both are observed; matched reopening can clear both, demonstrating that multiple simultaneous repairs are possible when the diagnostic state is complete.

### Strategic triggering
A clean authorization receives a strategically manufactured bloc-concentration flag for two cycles. Matched reopening repeatedly spends procedural resources without a real underlying fragility.

### Trigger capture
The agenda-dependence diagnosis is correct and the trigger fires, but the agenda-reintroduction mechanism is captured. The response process runs without repairing the fragility.

### Repeated reopening
A vote-splitting fragility is repaired on the first reopening, but a stale diagnostic continues to fire for two more cycles. The later reopenings are redundant.

### Irrecoverable topology
Agenda dependence is correctly detected, but the excluded warrant topology has already been lost. The reopening procedure cannot reconstruct it; six preserved-PRF units are recorded as topology loss.

## Frozen comparative summary

| Policy | Fragilities cleared | Reopen events | Successful repairs | Unnecessary actions | Topology loss | Response overhead |
|---|---:|---:|---:|---:|---:|---:|
| IGNORE | 2/7 | 0 | 0 | 0 | 31 | 0 |
| MATCHED_REOPEN | 4/7 | 9 | 3 | 5 | 6 | 17 |
| BLANKET_REOPEN | 4/7 | 9 | 3 | 31 | 6 | 43 |

Matched reopening retains its overhead advantage over blanket reopening, but its canonical 2C protection result does **not** survive the full stress suite.

## Main findings

### 1. Detection remains a necessary condition
A scoped response cannot repair a fragility it never sees. In the missed-fragility case, matched reopening performs no action and the real fragility remains in place.

### 2. Triggering is not equivalent to repair
Trigger capture shows that a correctly diagnosed problem and correctly fired REOPEN commitment can still fail if the repair channel is captured.

**Trigger fired ≠ repair succeeded.**

### 3. Preservation has a hard temporal limit
In the irrecoverable-topology case, reopening occurs after the relevant coalition/warrant structure has already disappeared. The system cannot reconstruct what was not preserved.

**REOPEN capacity ≠ reconstruction capacity.**

### 4. Scoped reopening is vulnerable to false and strategic flags
False positives and strategic triggering create unnecessary matched review. Selectivity reduces the cost relative to blanket reopening, but does not eliminate manipulation risk.

### 5. Reopening itself can become stale
Repeated-reopen stress shows that a valid trigger must eventually retire when its corresponding fragility is cleared. Otherwise REOPEN becomes procedural recurrence rather than corrigibility.

### 6. Interacting fragilities are not automatically fatal
When both interacting fragilities are correctly observed and their repair routes remain functional, matched reopening successfully clears both. The problem is therefore not multiplicity alone; it is incomplete diagnosis, captured response, stale triggering, or lost topology.

## Policy comparison

### IGNORE
The apparent zero-cost baseline is achieved by accepting unresolved fragility and severe topology loss. It clears only the two worlds with no true fragility.

### MATCHED_REOPEN
Remains the least wasteful active response: 17 units of modeled overhead versus 43 for blanket reopening. But it clears only four of seven worlds under adversarial conditions.

### BLANKET_REOPEN
Does not improve protection over matched reopening in this suite. It clears the same four worlds while generating 31 unnecessary actions and the same six units of irrecoverable topology loss. Applying every repair cannot compensate for missing detection, captured mechanisms, or vanished evidence.

## Falsification result
Experiment 2C discovered a useful **conditional** procedural grammar, not a fully robust one.

The 2C claim that matched reopening preserves correction capacity at much lower overhead survives only when:

- relevant fragility is detected;
- the matching trigger cannot be captured;
- reopening happens before the warrant topology becomes irrecoverable;
- trigger state is retired after repair;
- and false/strategic fragility signals remain bounded.

When those conditions fail, matched reopening retains an efficiency advantage over blanket reopening but loses its protection equivalence.

## Strongest warranted claim
> Within the bounded Experiment 2D stress model, scoped fragility-matched reopening remains substantially less costly than blanket reopening, but its corrective success depends on diagnostic coverage, trigger integrity, timely topology preservation, and termination of stale triggers. Blanket reopening does not solve failures caused by missed detection, trigger capture, or irrecoverable topology loss.

## Claim ceiling
This experiment does not establish empirical rates of procedural manipulation or capture, nor does it validate the specific thresholds or repair mechanisms used in 2B–2D. It establishes only model-internal failure conditions for the current fragility-response grammar.
