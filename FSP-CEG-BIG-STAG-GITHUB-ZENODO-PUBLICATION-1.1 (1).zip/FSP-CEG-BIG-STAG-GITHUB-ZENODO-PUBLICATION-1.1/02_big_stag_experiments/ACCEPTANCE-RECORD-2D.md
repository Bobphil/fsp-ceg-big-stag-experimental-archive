# UCP-XR-EXPERIMENT-2D — Acceptance Record

## Scope
Adversarial stress of the Experiment 2C fragility-response layer. The inherited plurality and 2B fragility diagnostics are not revised. The stress overlay separates true fragility, observed flags, and response effectiveness.

## Adversarial cases
1. False-positive fragility flag
2. Missed true fragility
3. Interacting fragilities
4. Strategic triggering
5. Trigger capture
6. Repeated reopening after successful repair
7. Irrecoverable warrant-topology loss

## Acceptance
- Full inherited + 2D regression suite: **253/253 PASS**
- New 2D response-stress invariants: **12/12 PASS**
- Frozen raw traces: **21** (7 cases × 3 response policies)
- Raw traces frozen before comparative interpretation: **YES**
- Inherited source integrity: **159 files checked; 0 changed**, excluding `package.json` script extension and new 2D files.

## Firewalls preserved
- Fragility flag ≠ truth.
- Procedural fragility ≠ automatic invalidation.
- REOPEN ≠ reversal.
- Trigger fired ≠ repair succeeded.
- Observed fragility ≠ true fragility.
- Preserved topology ≠ reconstructable topology.

## Regression command
`npm run test:all`

See `test-output-2d.txt` and `results2d/FREEZE-MANIFEST.json`.
