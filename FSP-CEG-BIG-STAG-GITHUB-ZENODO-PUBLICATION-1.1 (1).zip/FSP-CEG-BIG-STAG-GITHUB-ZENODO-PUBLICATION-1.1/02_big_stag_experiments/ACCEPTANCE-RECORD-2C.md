# EXPERIMENT-2C Acceptance Record

- Full regression harness: **243/243 PASS**
- 2C response invariants: **12/12 PASS**
- Frozen response traces: **18** (6 cases × 3 response policies)
- Plurality action-selection rule: unchanged
- 2B fragility diagnostics: unchanged
- Automatic reversal: prohibited in all 18 traces
- Truth/consensus claims: absent in all 18 traces

## Response-policy summary

| Policy | Fragile cases | Reopens | Corrections | Topology loss | Unnecessary reopens | Response overhead |
|---|---:|---:|---:|---:|---:|---:|
| IGNORE | 4 | 0 | 0 | 25 | 0 | 0 |
| MATCHED_REOPEN | 4 | 4 | 3 | 0 | 0 | 5 |
| BLANKET_REOPEN | 4 | 4 | 3 | 0 | 11 | 16 |
