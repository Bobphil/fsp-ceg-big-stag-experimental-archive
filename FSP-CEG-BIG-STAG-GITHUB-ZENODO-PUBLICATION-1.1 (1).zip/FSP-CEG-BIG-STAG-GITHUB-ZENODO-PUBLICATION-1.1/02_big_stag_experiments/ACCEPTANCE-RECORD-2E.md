# UCP-XR-EXPERIMENT-2E — Acceptance Record

## Status
PASS.

- Full inherited + 2E regression: **261/261 PASS**.
- New 2E invariants: **14/14 PASS**.
- Frozen diagnostic traces: **8**.
- Inherited 2D files checked byte-for-byte: **194 identical; 0 unexpected changes** (`package.json` intentionally extended only for 2E commands).

## Architecture lock
Individual PRFs remain the underlying warrant-bearing agents. **Task-space PRF coalitions** are the operational senders and receivers of Return / REOPEN messages. Coalition task agreement does not imply internal warrant uniformity.

## Acceptance target
Behaviorally distinguish:
1. detection failure,
2. transmission failure,
3. reception / credibility failure,
4. standing failure,
5. escalation failure,
6. warrant-topology reconstruction failure,
7. REOPEN termination failure,
while preserving a successful end-to-end control route.

## Firewalls
- message sent ≠ message received ≠ message credited ≠ warrant updated ≠ action changed
- REOPEN signal ≠ REOPEN uptake ≠ REOPEN consequence
- coalition agreement on a bounded task ≠ internal PRF consensus
- plurality authorization ≠ truth
- repair completed ≠ reopening properly terminated
