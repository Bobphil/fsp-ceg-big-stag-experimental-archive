# UCP-XR-EXPERIMENT-2 — BIG STAG Audit

## Purpose

Restore the population-level CEG architecture: heterogeneous PRFs with partial maps and warrants form shared-task coalitions; plurality selects provisional action without converting the winning coalition into truth; losing PRFs and warrant structures remain preserved; Return changes individual warrant states; coalitions can recompose through time.

## Canonical architecture

- 12 heterogeneous PRFs.
- Shared task forms through second-order governance warrant, not first-order consensus.
- Coalition membership is based on current preferred action; coalition members may carry different reason families.
- One PRF contributes one count to plurality selection.
- Tie-break after equal plurality/support is lower coercion; this is a frozen procedural rule, not a truth criterion.
- Minority coalitions are archived at every transition and their PRFs remain active.
- T1–T6 evidence is returned to every PRF; situated sensitivities produce heterogeneous warrant updates.
- Coalitions are recomputed after each Return event.
- Action closure coexists with inquiry openness.

## Canonical authorization sequence

- T0: P2 temporary restriction, 5/12.
- T1: P2 temporary restriction, 5/12.
- T2: P3 strong control, 7/12 after capability jump.
- T3: P2 temporary restriction, 5/12 after attenuation.
- T4: P1 disclosure, 6/12 after governance misuse.
- T5: P1 disclosure, 5/12 in a 5–5 tie with P3; frozen lower-coercion tie-break selects P1.
- T6: P2 temporary restriction, 6/12 after restoration signal.

## Canonical structural metrics

- Authorization switches: 4.
- Coalition membership changes: 38.
- Alternative-warrant convergence instances: 20.
- Minority archive records: 18.
- Minority preservation rate: 1.000.
- Return events: 6.
- First-order policy diversity at T6: 4 policies represented.
- Final plurality share: 0.500.

## Firewalls preserved

- Plurality selection ≠ truth.
- Authorization ≠ consensus.
- Majority/plurality rule ≠ warrant generation.
- Losing coalition ≠ erased warrant.
- Action closure ≠ inquiry closure.
- Shared-task agreement ≠ shared risk theory.
- No PRF is modeled as a polity-wide oracle.

## Claim ceiling

This build tests whether the population-level governance architecture is executable and internally coherent in a deterministic synthetic fixture. It does **not** establish that plurality is the best real-world aggregation rule, that these PRF distributions are empirically realistic, that the authorized policies are correct, or that the architecture is effective for real existential-risk governance.
