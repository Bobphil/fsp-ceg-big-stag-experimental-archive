# UCP-XR-EXPERIMENT-2A — BIG STAG Aggregation Stress

## Purpose

Stress the Experiment 2 population-level action-selection layer while preserving the original PRF, shared-task, minority-preservation, Return, and claim-ceiling architecture. This is a vulnerability test of simple plurality, not a proposal to replace it with another voting rule.

## Frozen stress cases

### CONTROL
Unsplintered bounded-action proposal wins 5/12 (41.67%). This already demonstrates that provisional authorization need not imply majority consensus.

### VOTE_SPLIT
Two P2 variants divide six PRFs 3–3 while P3 remains unified at four votes. P3 therefore wins the proposal plurality with 4/12 even though the P2 **action family** has 6/12 support. This is a direct proposal-fragmentation vulnerability.

### AGENDA_EXCLUSION
Removing the P2 family from the available agenda changes the authorized proposal from P2 monitoring to P1 disclosure (6/12). The outcome is therefore agenda-dependent in this fixture.

### COORDINATED_BLOC
A coordinated P3 bloc of four PRFs supplies the winning proposal while adjacent P2 alternatives split. The largest underlying action family is P2 (5/12), but the P3 proposal wins 4/12.

### PARTICIPATION_LOSS
Five PRFs withhold participation. P3 receives 4 of 7 votes cast (57.14%) but only 4 of the full 12-PRF electorate (33.33%). Thus a cast-vote majority can remain an electorate minority.

### RETURN_RECOMPOSITION
At T0, P1 disclosure wins 5/12 while P2 is a minority. After an independent hazard-confirmation Return signal, several PRFs move and P2 becomes the plurality at 6/12. A PRF preserved in the earlier minority later participates in the winning coalition.

## What survives the stress

Across every case:

- plurality authorization is explicitly recorded as **not truth**;
- authorization is explicitly recorded as **not consensus**;
- losing PRF records remain preserved;
- the electorate remains 12 PRFs;
- minority-preservation rate remains 1.0;
- Return can recompose coalition membership and later authorization.

## What fails or becomes fragile

Simple proposal plurality is not invariant to:

1. **proposal granularity / vote splitting**;
2. **agenda inclusion or exclusion**;
3. **coordinated blocs facing fragmented alternatives**;
4. **participation loss**.

Therefore a plurality victory has to be interpreted as a procedure-specific authorization result, not a direct measure of unified collective warrant.

## Central distinction

> **Authorized plurality ≠ largest substantive warrant family ≠ electorate majority ≠ consensus ≠ truth.**

This does not invalidate plurality as an action-selection mechanism. It identifies information that must remain visible around the authorization event if the process is to remain corrigible.

## Claim ceiling

2A establishes only that the frozen simple-plurality implementation is vulnerable to familiar aggregation pathologies inside a synthetic 12-PRF model while minority preservation and Return-driven recomposition remain executable. It does **not** establish which real-world voting or aggregation method should replace or supplement plurality, nor that any one procedural rule is normatively superior.

## Next disciplined question

The next test should compare **procedural robustness diagnostics** before replacing the rule: can the system detect when an authorization is fragile because of proposal splitting, agenda dependence, low participation, or bloc concentration and respond by preserving/reopening the relevant warrant topology rather than pretending the plurality is more decisive than it is?
