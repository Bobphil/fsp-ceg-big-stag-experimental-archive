# QUICK REPRODUCTION

## Canonical full-lineage rerun
1. Extract this archive.
2. Enter:
   `06_executable_corpus/runnable_snapshots/FSP-EMERGENT-LEVELS-1`
3. Run:
   `npm run test:all:emergent-levels`
4. Expected result:
   `300 tests`, `300 pass`, `0 fail`.

## BIG STAG / channel-ablation lineage rerun
1. Enter:
   `06_executable_corpus/runnable_snapshots/UCP-XR-EXPERIMENT-2F-CHANNEL-ABLATION`
2. Run:
   `npm run test:all`
3. Expected result:
   `269 tests`, `269 pass`, `0 fail`.

The recovered packages use Node's built-in test runner and declare no external npm dependencies.
