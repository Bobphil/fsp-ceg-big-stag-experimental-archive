# RERUN ENVIRONMENT

Fresh rerun date: 2026-11-23

- Node.js: v22.16.0
- npm: 10.9.2
- Platform: Linux container environment used for archive verification
- External npm dependencies: none declared in the recovered package.json files used for the reruns

Commands executed:

## UCP-XR-EXPERIMENT-2F-CHANNEL-ABLATION
`npm run test:all`

Fresh result: **269/269 PASS**

## FSP-EMERGENT-LEVELS-1
`npm run test:all:emergent-levels`

Fresh result: **300/300 PASS**

The full output is preserved in `fresh_rerun_receipts/`.
