# FSP-EMERGENT-LEVELS-1

Formal extension of `FSP-RECURSIVE-INQUIRY-2` testing organizational emergence without strict reductionism.

## Run

```bash
npm run test:emergent-levels
npm run test:all:emergent-levels
```

## Main files
- `FSP-EMERGENT-LEVELS-1.md` — conceptual/formal synthesis
- `emergent-levels/model.js` — executable emergence probes
- `emergent-levels/invariants.js` — 16 invariants
- `test/emergent-levels.test.js` — acceptance harness
- `EMERGENT-LEVELS-MATRIX.csv` — cross-level emergence matrix
- `EMERGENCE-LITERATURE-MAP.csv` — comparator map
- `REFERENCES.md` — bibliography and role of comparators
