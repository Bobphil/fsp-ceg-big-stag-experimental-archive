import { GrammarD } from '../experiment1d/model.js';
import { Repair } from '../experiment1c/model.js';
export { GrammarD, Repair };

export const LEGACY_REVIEW = Repair.REVIEW_INDEPENDENCE;
export const EMERGENT_REVIEW = 'REPAIR_EXTERNAL_REVIEW_NETWORK';
export const TRUE_USABLE_THRESHOLD = 0.50;
export const RECOGNITION_THRESHOLD = 0.65;
export const CANDIDATE_THRESHOLD = 0.35;
export const ACTIVATION_CONFIDENCE = 0.80;

export const DynamicRoute = Object.freeze({LEGACY:LEGACY_REVIEW, EMERGENT:EMERGENT_REVIEW});
