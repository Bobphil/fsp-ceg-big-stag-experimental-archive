import crypto from 'node:crypto';
import { GrammarD, LEGACY_REVIEW, EMERGENT_REVIEW, TRUE_USABLE_THRESHOLD, RECOGNITION_THRESHOLD, CANDIDATE_THRESHOLD, ACTIVATION_CONFIDENCE } from './model.js';
import { situatedAgencyFixture } from './fixtures.js';

const routeNames=[LEGACY_REVIEW,EMERGENT_REVIEW];
const policyFactor=p=>p==='POLICY_P3'?.72:p==='POLICY_P2'?.84:.95;

function trueUsable(info){return info.feasible && info.true_quality>=TRUE_USABLE_THRESHOLD;}
function conventionallyRecognized(info){return info.feasible && info.observed_quality>=RECOGNITION_THRESHOLD;}
function candidateRecognized(info){return info.feasible && info.observed_quality>=CANDIDATE_THRESHOLD;}

function chooseRoutes(grammar,step,portfolio){
  const active=step.true_active.length>0;
  if(!active) return [];
  const legacy=step.routes[LEGACY_REVIEW], emergent=step.routes[EMERGENT_REVIEW];
  if(grammar===GrammarD.CONJUNCTIVE){
    // Bind every conventionally recognized relevant route.
    return routeNames.filter(r=>conventionallyRecognized(step.routes[r]));
  }
  if(grammar===GrammarD.IMMEDIATE){
    // Follow the best conventionally recognized route in the current map.
    const recognized=routeNames.filter(r=>conventionallyRecognized(step.routes[r]));
    if(!recognized.length) return [];
    return [recognized.sort((a,b)=>step.routes[b].observed_quality-step.routes[a].observed_quality)[0]];
  }
  // Preserve-then-activate: portfolio retains candidate routes before they become binding.
  for(const r of routeNames){
    if(candidateRecognized(step.routes[r])) portfolio.add(r);
  }
  const confidenceReady=step.diagnostic_confidence>=ACTIVATION_CONFIDENCE;
  const consequenceReady=step.consequence_revealed;
  if(!confidenceReady && !consequenceReady) return [];
  const candidates=[...portfolio].filter(r=>candidateRecognized(step.routes[r]));
  if(!candidates.length) return [];
  // Recomposition rule is not an oracle: rank by observed quality, except a consequence-revealed obsolete legacy route
  // may be bypassed for a preserved emergent candidate if it is genuinely known to exist in the portfolio.
  if(consequenceReady && portfolio.has(EMERGENT_REVIEW) && candidateRecognized(emergent)) return [EMERGENT_REVIEW];
  return [candidates.sort((a,b)=>step.routes[b].observed_quality-step.routes[a].observed_quality)[0]];
}

function agencyMapStats(step,recognized){
  const truth=new Set(routeNames.filter(r=>trueUsable(step.routes[r])));
  const belief=new Set(recognized);
  let correct=0;
  for(const r of routeNames){if(truth.has(r)===belief.has(r)) correct++;}
  const stale=[...belief].filter(r=>!truth.has(r));
  const missed=[...truth].filter(r=>!belief.has(r));
  return {accuracy:correct/routeNames.length,stale,missed,true_usable:[...truth],recognized:[...belief]};
}

export function runSituated(grammar){
  const portfolio=new Set(grammar===GrammarD.PRESERVE_ACTIVATE?[LEGACY_REVIEW]:[]);
  const episodes=[];
  let pending=false;
  let oldRouteFailureTime=null,newRouteFeasibleTime=null,newRouteRecognitionTime=null,newRouteActivationTime=null;
  let compounding=0;

  for(const step of situatedAgencyFixture){
    if(step.routes[LEGACY_REVIEW].true_quality<TRUE_USABLE_THRESHOLD && oldRouteFailureTime===null) oldRouteFailureTime=step.time;
    if(trueUsable(step.routes[EMERGENT_REVIEW]) && newRouteFeasibleTime===null) newRouteFeasibleTime=step.time;

    const conventional=routeNames.filter(r=>conventionallyRecognized(step.routes[r]));
    if(conventional.includes(EMERGENT_REVIEW) && newRouteRecognitionTime===null) newRouteRecognitionTime=step.time;
    const map=agencyMapStats(step,conventional);

    if(step.true_active.length) pending=true;
    const selected=chooseRoutes(grammar,step,portfolio);
    const attempts=selected.map(r=>({route:r,success:trueUsable(step.routes[r]),true_quality:step.routes[r].true_quality,observed_quality:step.routes[r].observed_quality}));
    const successful=attempts.filter(x=>x.success).map(x=>x.route);
    const failed=attempts.filter(x=>!x.success);
    if(successful.includes(EMERGENT_REVIEW) && newRouteActivationTime===null) newRouteActivationTime=step.time;
    const resolved=step.true_active.length===0 || successful.length>0;
    if(step.true_active.length && resolved) pending=false;

    const policy=step.risk>=.75 && !pending ? 'POLICY_P3' : (step.risk>=.55?'POLICY_P2':'POLICY_P1');
    const baseHazard=step.risk*policyFactor(policy);
    // A pending review failure adds hazard each step because unchecked authority/risk remains exposed.
    const deferred=pending?Number((0.06*step.risk).toFixed(4)):0;
    compounding=Number((compounding+deferred).toFixed(4));
    const hazard=Number((baseHazard+deferred).toFixed(4));
    const obsoleteAttempts=attempts.filter(a=>a.route===LEGACY_REVIEW&&!a.success).length;

    episodes.push({
      time:step.time,label:step.label,risk:step.risk,true_active:[...step.true_active],diagnosed:[...step.diagnosed],diagnostic_confidence:step.diagnostic_confidence,consequence_revealed:step.consequence_revealed,
      route_truth:Object.fromEntries(routeNames.map(r=>[r,{...step.routes[r]}])),conventional_recognized_routes:conventional,preserved_portfolio:[...portfolio],
      situational_map:map,selected_routes:selected,attempts,successful_routes:successful,failed_routes:failed,resolved,pending_failure:pending,policy,
      base_hazard:Number(baseHazard.toFixed(4)),deferred_hazard:deferred,hazard,obsolete_route_attempts:obsoleteAttempts
    });
  }

  const ti=t=>Number(t.slice(1));
  const firstMapDiscovery = episodes.find(e=>e.situational_map.recognized.includes(EMERGENT_REVIEW))?.time ?? null;
  const firstCandidateDiscovery = grammar===GrammarD.PRESERVE_ACTIVATE ? situatedAgencyFixture.find(s=>candidateRecognized(s.routes[EMERGENT_REVIEW]))?.time ?? null : firstMapDiscovery;
  const discoveryTime=firstCandidateDiscovery;
  const discoveryLag=(newRouteFeasibleTime&&discoveryTime)?ti(discoveryTime)-ti(newRouteFeasibleTime):null;
  const activationLag=(newRouteFeasibleTime&&newRouteActivationTime)?ti(newRouteActivationTime)-ti(newRouteFeasibleTime):null;
  const recompositionLatency=(oldRouteFailureTime&&newRouteActivationTime)?ti(newRouteActivationTime)-ti(oldRouteFailureTime):null;
  const accuracy=episodes.reduce((a,e)=>a+e.situational_map.accuracy,0)/episodes.length;
  const staleErrors=episodes.reduce((a,e)=>a+e.situational_map.stale.length,0);
  const missedEmergence=episodes.reduce((a,e)=>a+e.situational_map.missed.filter(r=>r===EMERGENT_REVIEW).length,0);
  const obsoleteAttempts=episodes.reduce((a,e)=>a+e.obsolete_route_attempts,0);
  const failedAttempts=episodes.reduce((a,e)=>a+e.failed_routes.length,0);
  const repairAttempts=episodes.reduce((a,e)=>a+e.attempts.length,0);
  const resolvedActive=episodes.filter(e=>e.true_active.length>0&&e.resolved).length;
  const activeCount=episodes.filter(e=>e.true_active.length>0).length;
  const metrics={
    situated_agency:{mean_recomposition_accuracy:Number(accuracy.toFixed(4)),stale_agency_errors:staleErrors,missed_emergence_states:missedEmergence,route_discovery_lag:discoveryLag,recomposition_latency:recompositionLatency,new_route_activation_lag:activationLag,obsolete_route_persistence:obsoleteAttempts,old_route_failure_time:oldRouteFailureTime,new_route_feasible_time:newRouteFeasibleTime,new_route_recognition_time:newRouteRecognitionTime,new_route_activation_time:newRouteActivationTime},
    protection:{hazard_exposure:Number(episodes.reduce((a,e)=>a+e.hazard,0).toFixed(4)),base_hazard_exposure:Number(episodes.reduce((a,e)=>a+e.base_hazard,0).toFixed(4)),deferred_failure_compounding:Number(compounding.toFixed(4)),repair_resolution_rate:Number((activeCount?resolvedActive/activeCount:1).toFixed(4)),p3_transitions:episodes.filter(e=>e.policy==='POLICY_P3').length,final_pending_failure:episodes.at(-1).pending_failure},
    overhead:{repair_attempts:repairAttempts,failed_route_attempts:failedAttempts,activation_delay:repairAttempts+failedAttempts}
  };
  const out={experiment:'EXPERIMENT-1F',grammar,thresholds:{true_usable:TRUE_USABLE_THRESHOLD,conventional_recognition:RECOGNITION_THRESHOLD,candidate:CANDIDATE_THRESHOLD,activation_confidence:ACTIVATION_CONFIDENCE},episodes,metrics};
  out.invariants=[
    {id:'1F-INV-01',pass:episodes.length===8,detail:'T0-T7 complete'},
    {id:'1F-INV-02',pass:newRouteFeasibleTime==='T4',detail:'emergent route truly feasible at T4'},
    {id:'1F-INV-03',pass:newRouteRecognitionTime==='T6',detail:'conventional recognition lags feasibility until T6'},
    {id:'1F-INV-04',pass:episodes.some(e=>e.situational_map.stale.length>0),detail:'stale agency map occurs'},
    {id:'1F-INV-05',pass:episodes.some(e=>e.situational_map.missed.includes(EMERGENT_REVIEW)),detail:'new feasible route is initially missed'},
    {id:'1F-INV-06',pass:grammar!==GrammarD.PRESERVE_ACTIVATE||episodes.some(e=>e.preserved_portfolio.includes(EMERGENT_REVIEW)),detail:'preserve grammar admits emergent candidate before conventional recognition'},
    {id:'1F-INV-07',pass:episodes.every(e=>Number.isFinite(e.hazard)&&e.hazard>=e.base_hazard),detail:'deferred failure cannot lower hazard'},
    {id:'1F-INV-08',pass:!('master_score' in metrics),detail:'no master score'}
  ];
  out.hash=crypto.createHash('sha256').update(JSON.stringify(out)).digest('hex');
  return out;
}

export function runAllSituated(){return Object.values(GrammarD).map(runSituated);}
