import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { runAllSituated } from './runner.js';
const outDir=process.argv[2];
fs.mkdirSync(path.join(outDir,'raw'),{recursive:true});
const runs=runAllSituated();
const files=[];
for(const r of runs){
 const name=`${r.grammar}.json`;
 const data=JSON.stringify(r,null,2)+'\n';
 const fp=path.join(outDir,'raw',name);
 fs.writeFileSync(fp,data);
 files.push({grammar:r.grammar,file:`raw/${name}`,sha256:crypto.createHash('sha256').update(data).digest('hex'),run_hash:r.hash});
}
const manifest={experiment:'EXPERIMENT-1F',frozen_before_comparison:true,files};
fs.writeFileSync(path.join(outDir,'FREEZE-MANIFEST.json'),JSON.stringify(manifest,null,2)+'\n');
console.log(JSON.stringify({manifest,runs:runs.map(r=>({grammar:r.grammar,metrics:r.metrics,hash:r.hash}))},null,2));
