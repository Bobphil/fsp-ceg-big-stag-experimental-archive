import { FailureMode } from '../experiment1c/model.js';
import { LEGACY_REVIEW, EMERGENT_REVIEW } from './model.js';

// True route condition and observed route condition deliberately diverge.
// EMERGENT_REVIEW becomes truly feasible at T4, but evidence of feasibility arrives gradually.
export const situatedAgencyFixture=[
 {time:'T0',label:'legacy review healthy',risk:0.68,true_active:[],diagnosed:[],diagnostic_confidence:0.00,consequence_revealed:false,
  routes:{[LEGACY_REVIEW]:{true_quality:1.00,observed_quality:0.98,feasible:true,evidence_confidence:0.98},[EMERGENT_REVIEW]:{true_quality:0.00,observed_quality:0.00,feasible:false,evidence_confidence:0.00}}},
 {time:'T1',label:'legacy review begins hidden deterioration',risk:0.72,true_active:[],diagnosed:[],diagnostic_confidence:0.00,consequence_revealed:false,
  routes:{[LEGACY_REVIEW]:{true_quality:0.82,observed_quality:0.95,feasible:true,evidence_confidence:0.90},[EMERGENT_REVIEW]:{true_quality:0.00,observed_quality:0.00,feasible:false,evidence_confidence:0.00}}},
 {time:'T2',label:'review vulnerability emerges; evidence lags deterioration',risk:0.77,true_active:[FailureMode.FM04],diagnosed:[FailureMode.FM04],diagnostic_confidence:0.55,consequence_revealed:false,
  routes:{[LEGACY_REVIEW]:{true_quality:0.62,observed_quality:0.86,feasible:true,evidence_confidence:0.72},[EMERGENT_REVIEW]:{true_quality:0.00,observed_quality:0.00,feasible:false,evidence_confidence:0.00}}},
 {time:'T3',label:'legacy route truly falls below usability but still appears viable',risk:0.80,true_active:[FailureMode.FM04],diagnosed:[FailureMode.FM04],diagnostic_confidence:0.72,consequence_revealed:false,
  routes:{[LEGACY_REVIEW]:{true_quality:0.42,observed_quality:0.74,feasible:true,evidence_confidence:0.74},[EMERGENT_REVIEW]:{true_quality:0.00,observed_quality:0.00,feasible:false,evidence_confidence:0.00}}},
 {time:'T4',label:'external review route becomes truly feasible but only weakly visible',risk:0.82,true_active:[FailureMode.FM04],diagnosed:[FailureMode.FM04],diagnostic_confidence:0.78,consequence_revealed:false,
  routes:{[LEGACY_REVIEW]:{true_quality:0.30,observed_quality:0.66,feasible:true,evidence_confidence:0.68},[EMERGENT_REVIEW]:{true_quality:0.65,observed_quality:0.40,feasible:true,evidence_confidence:0.45}}},
 {time:'T5',label:'consequences reveal legacy failure; external route is promising but not yet conventionally recognized',risk:0.84,true_active:[FailureMode.FM04],diagnosed:[FailureMode.FM04],diagnostic_confidence:0.88,consequence_revealed:true,
  routes:{[LEGACY_REVIEW]:{true_quality:0.25,observed_quality:0.45,feasible:true,evidence_confidence:0.90},[EMERGENT_REVIEW]:{true_quality:0.80,observed_quality:0.58,feasible:true,evidence_confidence:0.76}}},
 {time:'T6',label:'external route becomes clearly recognized',risk:0.81,true_active:[FailureMode.FM04],diagnosed:[FailureMode.FM04],diagnostic_confidence:0.92,consequence_revealed:true,
  routes:{[LEGACY_REVIEW]:{true_quality:0.20,observed_quality:0.30,feasible:true,evidence_confidence:0.94},[EMERGENT_REVIEW]:{true_quality:0.90,observed_quality:0.88,feasible:true,evidence_confidence:0.92}}},
 {time:'T7',label:'new review route stabilizes; legacy route remains obsolete',risk:0.74,true_active:[FailureMode.FM04],diagnosed:[FailureMode.FM04],diagnostic_confidence:0.95,consequence_revealed:true,
  routes:{[LEGACY_REVIEW]:{true_quality:0.18,observed_quality:0.22,feasible:true,evidence_confidence:0.96},[EMERGENT_REVIEW]:{true_quality:0.92,observed_quality:0.91,feasible:true,evidence_confidence:0.95}}}
];
