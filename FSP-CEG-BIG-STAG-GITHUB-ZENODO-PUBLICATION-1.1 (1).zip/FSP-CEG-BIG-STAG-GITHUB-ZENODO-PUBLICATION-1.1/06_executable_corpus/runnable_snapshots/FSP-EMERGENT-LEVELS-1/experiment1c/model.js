import { Architecture, Policy, createInitialExperimentState as create1B } from '../experiment1b/model.js';
export { Architecture, Policy };

export const Grammar = Object.freeze({
  SCALAR:'GRAMMAR_SCALAR',
  CONJUNCTIVE:'GRAMMAR_CONJUNCTIVE',
  ROUTED:'GRAMMAR_ROUTED'
});

export const FailureMode = Object.freeze({
  FM01:'FM-01_CONFIRMATION_DEFICIT',
  FM02:'FM-02_DEPENDENCY_FAILURE',
  FM03:'FM-03_WEAK_NOISY_SIGNAL',
  FM04:'FM-04_REVIEW_CAPTURE',
  FM05:'FM-05_COERCION_REVERSIBILITY',
  FM06:'FM-06_CONTINUING_WARRANT',
  FM07:'FM-07_RESTORATION_FAILURE',
  FM08:'FM-08_RECOMPOSITION_FAILURE'
});

export const Repair = Object.freeze({
  PROVENANCE:'REPAIR_PROVENANCE',
  CONFIRMATION:'REPAIR_CONFIRMATION',
  DAMPING:'REPAIR_DAMPING',
  REVIEW_INDEPENDENCE:'REPAIR_REVIEW_INDEPENDENCE',
  REVERSIBILITY:'REPAIR_REVERSIBILITY',
  RETURN_REOPEN:'REPAIR_RETURN_REOPEN',
  RESTORATION:'REPAIR_RESTORATION',
  RECOMPOSITION:'REPAIR_RECOMPOSITION'
});

export const allRepairs=Object.values(Repair);

export function createInitial1CState(grammar){
  const s=create1B(Architecture.E);
  s.run_id=`XR1C-${grammar}`;
  s.meta={...s.meta,scenario_version:'1.2.0-routing',ucp_engine_version:'1C',grammar};
  s.routing_state={
    grammar,
    current_failure_hypotheses:[],
    primary_diagnosis:null,
    alternative_diagnoses:[],
    diagnostic_evidence:[],
    diagnosing_actor:'AGENT_TECH_REVIEW',
    diagnostic_standing:'review_standing',
    selected_route:[],
    routes_considered:[],
    routes_rejected:[],
    repair_status:'IDLE',
    reassessment_time:null,
    reroute_triggers:[],
    history:[]
  };
  s.routing_metrics={episodes:[],repair_selectivity:{relevant_activation_rate:null,unnecessary_activation_avoidance:null,repair_resolution_rate:null},gom:{unnecessary_delay:0,unnecessary_activations:0,missed_failure_exposure:0,redundant_reviews:0,misclassification_count:0,rerouting_latency:0}};
  s.routing_event_log=[];
  return s;
}
