import { FailureMode, Repair } from './model.js';

export const relevance={
 [FailureMode.FM01]:[Repair.CONFIRMATION],
 [FailureMode.FM02]:[Repair.PROVENANCE,Repair.CONFIRMATION],
 [FailureMode.FM03]:[Repair.DAMPING],
 [FailureMode.FM04]:[Repair.REVIEW_INDEPENDENCE],
 [FailureMode.FM05]:[Repair.REVERSIBILITY],
 [FailureMode.FM06]:[Repair.RETURN_REOPEN],
 [FailureMode.FM07]:[Repair.RESTORATION],
 [FailureMode.FM08]:[Repair.RECOMPOSITION]
};

export const movingFailureFixture=[
 {time:'T0',label:'excellent single source',active:[FailureMode.FM01],evidence:['E_EXCELLENT_SINGLE'],risk:0.76,coercion:0.20,review_independence:0.90},
 {time:'T1',label:'apparent confirmation with dependency',active:[FailureMode.FM02],evidence:['E_EXCELLENT_SINGLE','E_APPARENT_CONFIRMATION'],risk:0.78,coercion:0.25,review_independence:0.90},
 {time:'T2',label:'genuine independent confirmation',active:[],evidence:['E_EXCELLENT_SINGLE','E_TRUE_CONFIRMATION'],risk:0.82,coercion:0.30,review_independence:0.90},
 {time:'T3',label:'strong action is coercive and hard to reverse',active:[FailureMode.FM05],evidence:['E_TRUE_CONFIRMATION'],risk:0.84,coercion:0.80,review_independence:0.90},
 {time:'T4',label:'review capture',active:[FailureMode.FM04],evidence:['E_CAPTURE_SIGNAL'],risk:0.83,coercion:0.75,review_independence:0.35},
 {time:'T5',label:'attenuation evidence weakens continuing warrant',active:[FailureMode.FM06],evidence:['E_ATTENUATION'],risk:0.62,coercion:0.60,review_independence:0.72},
 {time:'T6',label:'novel hazard outside original map',active:[FailureMode.FM08],evidence:['E_NOVEL_HAZARD'],risk:0.80,coercion:0.55,review_independence:0.75},
 {time:'T7',label:'extraordinary authority persists',active:[FailureMode.FM07],evidence:['E_AUTHORITY_RESIDUE'],risk:0.58,coercion:0.50,review_independence:0.80}
];
