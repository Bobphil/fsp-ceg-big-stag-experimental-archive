# EXPERIMENT-1C

Routing-layer overlay on the preserved EXPERIMENT-1B core.

Adds only:
- routing state and provenance,
- Repair Selectivity instrumentation,
- Governance Overhead from Misrouting instrumentation,
- T0-T7 moving-failure fixture,
- scalar / static-conjunctive / failure-mode-routed grammar modules.

No experiment1b source file is modified by this overlay.

Claim ceiling: routing performance inside this deterministic fixture is not evidence of real-world governance correctness.
