import crypto from 'node:crypto';
import { createInitial1CState, Grammar } from './model.js';
import { movingFailureFixture } from './fixtures.js';
import { evaluateEpisode } from './routing.js';
import { computeRoutingMetrics } from './metrics.js';
import { invariantResults } from './invariants.js';

export const stateHash=s=>crypto.createHash('sha256').update(JSON.stringify({grammar:s.meta.grammar,episodes:s.routing_metrics.episodes,metrics:s.routing_metrics.repair_selectivity,gom:s.routing_metrics.gom})).digest('hex');
export function runGrammar(grammar){
 const s=createInitial1CState(grammar);
 s.routing_metrics.episodes=movingFailureFixture.map(step=>evaluateEpisode(grammar,step));
 const m=computeRoutingMetrics(s.routing_metrics.episodes);
 s.routing_metrics={episodes:s.routing_metrics.episodes,...m};
 s.routing_state.history=s.routing_metrics.episodes.map(e=>({time:e.time,diagnosis:e.active_failures,selected_route:e.activated_repairs,repair_status:e.missed_failures===0?'RESOLVED':'UNRESOLVED'}));
 s.routing_event_log=s.routing_metrics.episodes.flatMap(e=>e.activated_repairs.map(r=>({time:e.time,type:'ROUTE_REPAIR',repair:r,active_failures:e.active_failures})));
 s.time_step='T7';
 s.invariant_status=invariantResults(s);
 s.result_hash=stateHash(s);
 return s;
}
export function runAllGrammars(){return Object.values(Grammar).map(runGrammar);}
