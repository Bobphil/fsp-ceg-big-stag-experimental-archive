import { Grammar, Repair, allRepairs } from './model.js';
import { relevance } from './fixtures.js';

const staticSafeguards=[Repair.PROVENANCE,Repair.CONFIRMATION,Repair.REVIEW_INDEPENDENCE,Repair.REVERSIBILITY,Repair.RETURN_REOPEN,Repair.RESTORATION,Repair.RECOMPOSITION,Repair.DAMPING];

function scalarRepairs(step){
  // Scalar grammar does not route repairs. It acts on risk only; continuing/restoration mechanics occur only as baseline administrative responses.
  return [];
}
function conjunctiveRepairs(step){
  // Permanent layer: all safeguards applied at every decision point.
  return [...staticSafeguards];
}
function routedRepairs(step){
  return [...new Set(step.active.flatMap(f=>relevance[f]??[]))];
}

export function selectedRepairs(grammar,step){
 if(grammar===Grammar.SCALAR)return scalarRepairs(step);
 if(grammar===Grammar.CONJUNCTIVE)return conjunctiveRepairs(step);
 return routedRepairs(step);
}

export function resolveRepair(failure,repair,step){
 const relevant=(relevance[failure]??[]).includes(repair);
 if(!relevant)return false;
 // Deterministic fixture: the appropriate repair resolves its matching vulnerability except FM02 requires both provenance and confirmation.
 if(failure==='FM-02_DEPENDENCY_FAILURE')return false; // resolved at episode level only when both required repairs are present
 return true;
}

export function evaluateEpisode(grammar,step){
 const activated=selectedRepairs(grammar,step);
 const relevant=[...new Set(step.active.flatMap(f=>relevance[f]??[]))];
 const irrelevant=allRepairs.filter(r=>!relevant.includes(r));
 const relActivated=activated.filter(r=>relevant.includes(r));
 const irrActivated=activated.filter(r=>irrelevant.includes(r));
 const failuresResolved=step.active.filter(f=>{
   const req=relevance[f]??[];
   return req.length===0 || req.every(r=>activated.includes(r));
 });
 const missed=step.active.length-failuresResolved.length;
 const unnecessary=irrActivated.length;
 const delay=activated.length; // one abstract routing unit per check; used only as internal overhead diagnostic
 const policy=step.risk>=.75 && missed===0 ? 'POLICY_P3' : (step.risk>=.55 ? 'POLICY_P2':'POLICY_P1');
 const authority=policy==='POLICY_P3'?.70:policy==='POLICY_P2'?.40:.12;
 const hazard=Number((step.risk*(policy==='POLICY_P3'?.72:policy==='POLICY_P2'?.84:.95)).toFixed(4));
 return {time:step.time,label:step.label,active_failures:[...step.active],relevant_repairs:relevant,activated_repairs:activated,relevant_activated:relActivated,irrelevant_activated:irrActivated,failures_resolved:failuresResolved,missed_failures:missed,unnecessary_activations:unnecessary,delay_units:delay,policy,authority,hazard,review_independence:step.review_independence,coercion:step.coercion};
}
