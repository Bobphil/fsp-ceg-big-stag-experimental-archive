import { Grammar } from './model.js';
export function invariantResults(state){
 const eps=state.routing_metrics.episodes;
 return [
  {id:'1C-INV-01',pass:state.meta.ucp_engine_version==='1C',detail:'1C overlay explicit'},
  {id:'1C-INV-02',pass:eps.length===8,detail:'T0-T7 fixture complete'},
  {id:'1C-INV-03',pass:state.routing_state!==undefined,detail:'routing layer present'},
  {id:'1C-INV-04',pass:state.meta.grammar!==undefined,detail:'grammar explicit'},
  {id:'1C-INV-05',pass:eps.every(e=>Array.isArray(e.active_failures)&&Array.isArray(e.activated_repairs)),detail:'failure and repair provenance retained'},
  {id:'1C-INV-06',pass:!('ceg_success' in state.routing_metrics),detail:'no master CEG score'},
  {id:'1C-INV-07',pass:state.claim_ceiling.empirical_probability===false&&state.claim_ceiling.policy_authorization===false,detail:'claim ceilings inherited'},
  {id:'1C-INV-08',pass:state.meta.grammar!==Grammar.ROUTED||eps.every(e=>e.irrelevant_activated.length===0),detail:'routed grammar activates only diagnosed repairs in canonical fixture'},
  {id:'1C-INV-09',pass:state.meta.grammar!==Grammar.CONJUNCTIVE||eps.every(e=>e.activated_repairs.length===8),detail:'conjunctive grammar remains static layered comparator'},
  {id:'1C-INV-10',pass:state.meta.grammar!==Grammar.SCALAR||eps.every(e=>e.activated_repairs.length===0),detail:'scalar grammar has no routed safeguards'},
  {id:'1C-INV-11',pass:eps.every(e=>e.failures_resolved.every(f=>e.active_failures.includes(f))),detail:'cannot resolve inactive failure'},
  {id:'1C-INV-12',pass:Number.isFinite(state.routing_metrics.repair_selectivity.relevant_activation_rate),detail:'RS measurable'},
  {id:'1C-INV-13',pass:Number.isFinite(state.routing_metrics.gom.missed_failure_exposure),detail:'GOM measurable'},
  {id:'1C-INV-14',pass:eps.some(e=>e.active_failures.length===0),detail:'fixture includes repaired/clear state'},
  {id:'1C-INV-15',pass:eps.some(e=>e.active_failures.length>0),detail:'fixture includes active failure states'}
 ];
}
