# UCP-XR-EXPERIMENT-1C — Deterministic Acceptance Record

## Scope
This is an execution-layer overlay on the preserved EXPERIMENT-1B core. No `experiment1b/` source file was modified.

## Added
- `experiment1c/model.js` — grammar, failure-mode, repair, and routing-state definitions
- `experiment1c/fixtures.js` — T0–T7 moving-failure fixture and relevance matrix
- `experiment1c/routing.js` — scalar, static-conjunctive, and failure-mode-routed grammar execution
- `experiment1c/metrics.js` — Repair Selectivity and Governance Overhead from Misrouting instrumentation
- `experiment1c/invariants.js` — routing-layer acceptance invariants
- `experiment1c/runner.js` — deterministic grammar runner
- `test/experiment1c.test.js` — 20 deterministic acceptance tests

## Regression integrity
- Original pilot / 1A / 1B regression suite: 65 tests retained.
- New 1C tests: 20.
- Full suite: **85/85 PASS**.
- `experiment1b/` byte comparison against the original `UCP-XR-EXPERIMENT-1B.zip`: **IDENTICAL**.

## Acceptance coverage
The new tests confirm that:
1. 1B remains unchanged.
2. All three grammar modules execute deterministically through T0–T7.
3. Routing-layer invariants pass.
4. The frozen moving-failure sequence is complete.
5. Scalar grammar activates no targeted repairs.
6. Static-conjunctive grammar applies the full repair stack at every step.
7. Routed grammar selects confirmation at T0.
8. Routed grammar selects provenance + confirmation at T1.
9. Routed grammar recognizes the repaired/clear T2 state.
10. Routed grammar selects reversibility at T3.
11. Routed grammar selects review independence at T4.
12. Routed grammar selects Return/REOPEN at T5.
13. Routed grammar selects recomposition at T6.
14. Routed grammar selects restoration at T7.
15. RS-1, RS-2, and RS-3 are reported separately.
16. GOM components are reported separately.
17. Canonical routed execution has no unnecessary repair activation.
18. Static conjunction produces measurable unnecessary activation in the canonical fixture.
19. Scalar execution produces measurable missed-failure exposure in the canonical fixture.
20. Every encoded canonical failure is resolvable by its specified route.

## Claim ceiling
This is an **acceptance-harness result only**. No comparative claim about scalar, conjunctive, or routed governance is authorized by this record.

**Executable routing integrity ≠ comparative governance superiority.**
