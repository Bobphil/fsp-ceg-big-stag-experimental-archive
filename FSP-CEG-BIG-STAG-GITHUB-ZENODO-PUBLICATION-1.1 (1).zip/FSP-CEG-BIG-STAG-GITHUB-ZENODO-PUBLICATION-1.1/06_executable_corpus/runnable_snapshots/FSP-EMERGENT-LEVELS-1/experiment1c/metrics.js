import { allRepairs } from './model.js';
export function computeRoutingMetrics(episodes){
 let relevantRequired=0,relevantActivated=0,irrelevantAvailable=0,irrelevantActivated=0,failures=0,resolved=0;
 let unnecessaryDelay=0,unnecessaryActivations=0,missedFailureExposure=0,redundantReviews=0,misclassificationCount=0,reroutingLatency=0;
 for(const e of episodes){
   relevantRequired+=e.relevant_repairs.length;
   relevantActivated+=e.relevant_activated.length;
   irrelevantAvailable+=Math.max(0,allRepairs.length-e.relevant_repairs.length);
   irrelevantActivated+=e.irrelevant_activated.length;
   failures+=e.active_failures.length;
   resolved+=e.failures_resolved.length;
   unnecessaryActivations+=e.unnecessary_activations;
   unnecessaryDelay+=e.unnecessary_activations;
   missedFailureExposure+=Number((e.missed_failures*e.hazard).toFixed(4));
   redundantReviews+=e.activated_repairs.filter(r=>e.relevant_repairs.includes(r)===false).length;
 }
 const rar=relevantRequired?relevantActivated/relevantRequired:1;
 const uaa=irrelevantAvailable?1-(irrelevantActivated/irrelevantAvailable):1;
 const rrr=failures?resolved/failures:1;
 return {
  repair_selectivity:{
   relevant_activation_rate:Number(rar.toFixed(4)),
   unnecessary_activation_avoidance:Number(uaa.toFixed(4)),
   repair_resolution_rate:Number(rrr.toFixed(4))
  },
  gom:{unnecessary_delay:unnecessaryDelay,unnecessary_activations:unnecessaryActivations,missed_failure_exposure:Number(missedFailureExposure.toFixed(4)),redundant_reviews:redundantReviews,misclassification_count:misclassificationCount,rerouting_latency:reroutingLatency},
  existing_profile:{hazard_exposure:Number(episodes.reduce((z,e)=>z+e.hazard,0).toFixed(4)),authority_residue:Number(episodes.at(-1).authority.toFixed(4)),false_positive_closure:episodes.filter(e=>e.policy==='POLICY_P3'&&e.risk<.7).length,authorization_delay:episodes.reduce((z,e)=>z+e.delay_units,0),repair_count:episodes.reduce((z,e)=>z+e.activated_repairs.length,0)}
 };
}
