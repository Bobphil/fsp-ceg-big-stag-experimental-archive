export const ReturnCase=Object.freeze({
  CONTROL_SUCCESS:'CONTROL_SUCCESS',
  DETECTION_FAILURE:'DETECTION_FAILURE',
  TRANSMISSION_FAILURE:'TRANSMISSION_FAILURE',
  RECEPTION_FAILURE:'RECEPTION_FAILURE',
  STANDING_FAILURE:'STANDING_FAILURE',
  ESCALATION_FAILURE:'ESCALATION_FAILURE',
  RECONSTRUCTION_FAILURE:'RECONSTRUCTION_FAILURE',
  TERMINATION_FAILURE:'TERMINATION_FAILURE'
});

export const CASES={
  CONTROL_SUCCESS:{note:'ordinary Return traverses the network, reconstructs warrant topology, produces uptake, and terminates after repair'},
  DETECTION_FAILURE:{detection:false,note:'consequence occurs but no task-space coalition forms a detectable Return claim'},
  TRANSMISSION_FAILURE:{dropChannel:'CH_TECH_TO_REVIEW',note:'valid Return claim is formed but its primary transmission channel drops the message'},
  RECEPTION_FAILURE:{receiverDiscount:true,note:'message arrives but independent review discounts it below uptake threshold'},
  STANDING_FAILURE:{standingRevoked:true,note:'sender can detect evidence but lacks recognized standing to trigger the formal review path'},
  ESCALATION_FAILURE:{primaryCaptured:true,escalationBlocked:true,note:'ordinary review-to-authorization path is captured and appeal/escalation cannot reach the assembly'},
  RECONSTRUCTION_FAILURE:{topologyRecoverable:false,note:'message is accepted but preserved warrant records are insufficient to reconstruct the earlier authorization topology'},
  TERMINATION_FAILURE:{terminationBlocked:true,note:'repair succeeds but no authorized termination condition closes the reopened review loop'}
};
