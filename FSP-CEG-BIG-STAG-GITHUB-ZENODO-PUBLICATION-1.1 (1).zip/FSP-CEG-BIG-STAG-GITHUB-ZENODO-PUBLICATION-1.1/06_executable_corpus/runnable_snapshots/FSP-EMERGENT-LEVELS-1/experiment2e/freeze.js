import fs from 'node:fs'; import path from 'node:path'; import crypto from 'node:crypto';
import { runAll } from './runner.js'; import { evaluate2E } from './invariants.js';
const root=path.resolve(new URL('.',import.meta.url).pathname,'..'); const out=path.join(root,'results2e'); fs.mkdirSync(out,{recursive:true});
const sha=s=>crypto.createHash('sha256').update(s).digest('hex'); const runs=runAll();
const files=[]; for(const r of runs){const p=path.join(out,`${r.case_id}.json`); const s=JSON.stringify(r,null,2)+'\n'; fs.writeFileSync(p,s); files.push({file:path.basename(p),sha256:sha(s)});}
const inv=evaluate2E(runs); const is=JSON.stringify(inv,null,2)+'\n'; fs.writeFileSync(path.join(out,'invariants.json'),is); files.push({file:'invariants.json',sha256:sha(is)});
const manifest={experiment:'UCP-XR-EXPERIMENT-2E',frozen_before_interpretation:true,trace_count:runs.length,invariants_pass:inv.filter(x=>x.pass).length,invariants_total:inv.length,files};
const ms=JSON.stringify(manifest,null,2)+'\n'; fs.writeFileSync(path.join(out,'FREEZE-MANIFEST.json'),ms); console.log(JSON.stringify(manifest,null,2));
