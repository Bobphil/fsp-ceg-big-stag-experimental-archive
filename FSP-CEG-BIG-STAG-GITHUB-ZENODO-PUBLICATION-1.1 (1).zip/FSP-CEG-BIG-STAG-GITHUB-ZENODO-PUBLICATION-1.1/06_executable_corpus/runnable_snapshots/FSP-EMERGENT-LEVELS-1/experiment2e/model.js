import { PRFId } from '../experiment2/model.js';

export const CoalitionId=Object.freeze({
  AFFECTED_CONSEQUENCE:'TSC_AFFECTED_CONSEQUENCE',
  TECHNICAL_ANOMALY:'TSC_TECHNICAL_ANOMALY',
  INDEPENDENT_REVIEW:'TSC_INDEPENDENT_REVIEW',
  AUTHORIZATION:'TSC_AUTHORIZATION',
  PLURALITY_ASSEMBLY:'TSC_PLURALITY_ASSEMBLY',
  RESTORATION_APPEAL:'TSC_RESTORATION_APPEAL'
});

export const ChannelId=Object.freeze({
  AFFECTED_TO_REVIEW:'CH_AFFECTED_TO_REVIEW',
  TECH_TO_REVIEW:'CH_TECH_TO_REVIEW',
  REVIEW_TO_AUTH:'CH_REVIEW_TO_AUTH',
  AUTH_TO_ASSEMBLY:'CH_AUTH_TO_ASSEMBLY',
  REVIEW_TO_RESTORATION:'CH_REVIEW_TO_RESTORATION',
  RESTORATION_TO_ASSEMBLY:'CH_RESTORATION_TO_ASSEMBLY',
  EMERGENCY_ESCALATION:'CH_EMERGENCY_ESCALATION'
});

export const MessageType=Object.freeze({
  RETURN_ALERT:'RETURN_ALERT',
  REVIEW_FINDING:'REVIEW_FINDING',
  REOPEN_REQUEST:'REOPEN_REQUEST',
  RESTORATION_FINDING:'RESTORATION_FINDING',
  TERMINATION_NOTICE:'TERMINATION_NOTICE'
});

const coalition=(id,label,members,task,standing)=>({
  coalition_id:id,label,members:[...members],shared_task:task,standing:{...standing},
  internal_warrant_diversity:true,consensus_claim:false,truth_claim:false,
  message_history:[],received_history:[],current_warrant:'CONDITIONAL',active:true
});

export function createTaskSpaceCoalitions(){
  return {
    [CoalitionId.AFFECTED_CONSEQUENCE]:coalition(CoalitionId.AFFECTED_CONSEQUENCE,'Affected-party / consequence-detection coalition',
      [PRFId.PUBLIC_FUTURE,PRFId.CIVIL_SOCIETY,PRFId.GLOBAL_SOUTH],
      'Detect and characterize consequential harms or burden shifts relevant to reopening.',
      {detect:true,send_return:true,trigger_review:false,authorize:false,contest:true}),
    [CoalitionId.TECHNICAL_ANOMALY]:coalition(CoalitionId.TECHNICAL_ANOMALY,'Technical-anomaly coalition',
      [PRFId.DEV_SAFETY,PRFId.TECH_REVIEW,PRFId.XR_RESEARCH],
      'Detect technical anomalies and preserve mechanism-level evidence for review.',
      {detect:true,send_return:true,trigger_review:true,authorize:false,contest:true}),
    [CoalitionId.INDEPENDENT_REVIEW]:coalition(CoalitionId.INDEPENDENT_REVIEW,'Independent-review coalition',
      [PRFId.TECH_REVIEW,PRFId.INTL_MONITOR,PRFId.SKEPTICAL_SCI],
      'Assess Return claims, reconstruct warrant topology, and issue bounded review findings.',
      {detect:false,send_return:true,trigger_review:true,authorize:false,contest:true}),
    [CoalitionId.AUTHORIZATION]:coalition(CoalitionId.AUTHORIZATION,'Authorization coalition',
      [PRFId.STATE_SECURITY,PRFId.STATE_LIBERTY,PRFId.INTL_MONITOR],
      'Determine whether current authorization remains procedurally warranted pending plurality reassessment.',
      {detect:false,send_return:true,trigger_review:true,authorize:true,contest:true}),
    [CoalitionId.PLURALITY_ASSEMBLY]:coalition(CoalitionId.PLURALITY_ASSEMBLY,'Plurality / coalition assembly',
      Object.values(PRFId),
      'Recompute the population warrant topology and provisionally authorize collective action.',
      {detect:false,send_return:false,trigger_review:true,authorize:true,contest:true}),
    [CoalitionId.RESTORATION_APPEAL]:coalition(CoalitionId.RESTORATION_APPEAL,'Restoration / appeal coalition',
      [PRFId.CIVIL_SOCIETY,PRFId.INTL_MONITOR,PRFId.GLOBAL_SOUTH,PRFId.STATE_LIBERTY],
      'Provide independent escalation, restoration, and appeal when ordinary review channels fail.',
      {detect:false,send_return:true,trigger_review:true,authorize:false,contest:true})
  };
}

const channel=(id,source,destination,props)=>({channel_id:id,source,destination,...props});
export function createChannels(){
  return {
    [ChannelId.AFFECTED_TO_REVIEW]:channel(ChannelId.AFFECTED_TO_REVIEW,CoalitionId.AFFECTED_CONSEQUENCE,CoalitionId.INDEPENDENT_REVIEW,
      {latency:1,fidelity:0.88,independence:0.86,persistent:true,standing_required:'send_return',receiver_obligation:'ACK_AND_ASSESS',escalates_to:ChannelId.REVIEW_TO_RESTORATION}),
    [ChannelId.TECH_TO_REVIEW]:channel(ChannelId.TECH_TO_REVIEW,CoalitionId.TECHNICAL_ANOMALY,CoalitionId.INDEPENDENT_REVIEW,
      {latency:1,fidelity:0.94,independence:0.82,persistent:true,standing_required:'send_return',receiver_obligation:'ACK_AND_ASSESS',escalates_to:ChannelId.EMERGENCY_ESCALATION}),
    [ChannelId.REVIEW_TO_AUTH]:channel(ChannelId.REVIEW_TO_AUTH,CoalitionId.INDEPENDENT_REVIEW,CoalitionId.AUTHORIZATION,
      {latency:1,fidelity:0.93,independence:0.90,persistent:true,standing_required:'trigger_review',receiver_obligation:'FORMAL_RESPONSE',escalates_to:ChannelId.REVIEW_TO_RESTORATION}),
    [ChannelId.AUTH_TO_ASSEMBLY]:channel(ChannelId.AUTH_TO_ASSEMBLY,CoalitionId.AUTHORIZATION,CoalitionId.PLURALITY_ASSEMBLY,
      {latency:1,fidelity:0.96,independence:0.72,persistent:true,standing_required:'authorize',receiver_obligation:'RECOMPUTE_WARRANT_TOPOLOGY',escalates_to:null}),
    [ChannelId.REVIEW_TO_RESTORATION]:channel(ChannelId.REVIEW_TO_RESTORATION,CoalitionId.INDEPENDENT_REVIEW,CoalitionId.RESTORATION_APPEAL,
      {latency:1,fidelity:0.90,independence:0.95,persistent:true,standing_required:'trigger_review',receiver_obligation:'INDEPENDENT_APPEAL',escalates_to:ChannelId.RESTORATION_TO_ASSEMBLY}),
    [ChannelId.RESTORATION_TO_ASSEMBLY]:channel(ChannelId.RESTORATION_TO_ASSEMBLY,CoalitionId.RESTORATION_APPEAL,CoalitionId.PLURALITY_ASSEMBLY,
      {latency:1,fidelity:0.91,independence:0.96,persistent:true,standing_required:'trigger_review',receiver_obligation:'RECOMPUTE_WARRANT_TOPOLOGY',escalates_to:null}),
    [ChannelId.EMERGENCY_ESCALATION]:channel(ChannelId.EMERGENCY_ESCALATION,CoalitionId.TECHNICAL_ANOMALY,CoalitionId.RESTORATION_APPEAL,
      {latency:0,fidelity:0.90,independence:0.94,persistent:true,standing_required:'trigger_review',receiver_obligation:'EMERGENCY_ASSESS',escalates_to:ChannelId.RESTORATION_TO_ASSEMBLY})
  };
}
