import { runAll, ReturnCase } from './runner.js';
export function evaluate2E(runs=runAll()){
  const c=[]; const add=(id,pass,detail)=>c.push({id,pass:Boolean(pass),detail}); const g=id=>runs.find(x=>x.case_id===id);
  add('E2E-INV-01',runs.every(x=>!x.truth_claim&&!x.consensus_claim),'Return network never manufactures truth or consensus');
  add('E2E-INV-02',runs.every(x=>!x.automatic_reversal),'REOPEN consequence never means automatic reversal');
  add('E2E-INV-03',g(ReturnCase.CONTROL_SUCCESS).reopen_consequence&&g(ReturnCase.CONTROL_SUCCESS).terminated,'control traverses detection-to-consequence and terminates');
  add('E2E-INV-04',g(ReturnCase.DETECTION_FAILURE).failures.detection===1&&!g(ReturnCase.DETECTION_FAILURE).reopen_signal,'detection failure prevents signal formation');
  add('E2E-INV-05',g(ReturnCase.TRANSMISSION_FAILURE).failures.transmission===1&&!g(ReturnCase.TRANSMISSION_FAILURE).review_uptake,'transmission failure is behaviorally distinct');
  add('E2E-INV-06',g(ReturnCase.RECEPTION_FAILURE).failures.reception===1&&g(ReturnCase.RECEPTION_FAILURE).messages[0].received&&!g(ReturnCase.RECEPTION_FAILURE).review_uptake,'message received but not credited is distinct from transmission failure');
  add('E2E-INV-07',g(ReturnCase.STANDING_FAILURE).failures.standing===1&&g(ReturnCase.STANDING_FAILURE).detected&&!g(ReturnCase.STANDING_FAILURE).review_uptake,'standing failure occurs after detection but before uptake');
  add('E2E-INV-08',g(ReturnCase.ESCALATION_FAILURE).failures.escalation===1&&!g(ReturnCase.ESCALATION_FAILURE).reopen_consequence,'escalation can fail after ordinary path capture');
  add('E2E-INV-09',g(ReturnCase.RECONSTRUCTION_FAILURE).failures.reconstruction===1&&g(ReturnCase.RECONSTRUCTION_FAILURE).review_uptake&&!g(ReturnCase.RECONSTRUCTION_FAILURE).warrant_reconstructed,'uptake can occur without topology reconstruction');
  add('E2E-INV-10',g(ReturnCase.TERMINATION_FAILURE).repair_completed&&g(ReturnCase.TERMINATION_FAILURE).failures.termination===1&&g(ReturnCase.TERMINATION_FAILURE).review_open,'repair can succeed while reopening fails to terminate');
  add('E2E-INV-11',g(ReturnCase.CONTROL_SUCCESS).coalitions['TSC_PLURALITY_ASSEMBLY'].members.length===12,'plurality assembly remains grounded in all individual PRFs');
  add('E2E-INV-12',Object.values(g(ReturnCase.CONTROL_SUCCESS).coalitions).every(x=>x.internal_warrant_diversity),'task-space coalitions preserve internal PRF warrant diversity');
  add('E2E-INV-13',g(ReturnCase.CONTROL_SUCCESS).messages.every(m=>m.source.startsWith('TSC_')&&m.destination.startsWith('TSC_')),'operational messages are coalition-to-coalition, not oracle-to-system');
  add('E2E-INV-14',runs.length===8,'eight diagnostic Return-network cases are present');
  return c;
}
