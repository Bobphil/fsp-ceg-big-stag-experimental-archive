# UCP-XR-EXPERIMENT-2E — Return Network

Population-level overlay on Experiment 2D. Individual PRFs remain the warrant-bearing units; **task-space PRF coalitions** are the operational senders and receivers of Return/REOPEN messages.

The first 2E pass is diagnostic, not an optimization of channel architecture. It asks whether failures at detection, transmission, reception, standing, escalation, warrant-topology reconstruction, and termination are behaviorally distinguishable.

Firewalls:
- message sent ≠ message received ≠ message credited ≠ warrant updated ≠ action changed
- REOPEN signal ≠ REOPEN uptake ≠ REOPEN consequence
- coalition agreement on a bounded task ≠ internal warrant uniformity
- plurality authorization ≠ truth
- repair completed ≠ reopening properly terminated
