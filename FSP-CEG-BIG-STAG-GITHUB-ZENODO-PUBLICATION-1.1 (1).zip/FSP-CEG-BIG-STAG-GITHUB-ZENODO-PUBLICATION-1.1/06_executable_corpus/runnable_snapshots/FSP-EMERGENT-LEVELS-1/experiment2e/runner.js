import crypto from 'node:crypto';
import { CoalitionId, ChannelId, MessageType, createTaskSpaceCoalitions, createChannels } from './model.js';
import { ReturnCase, CASES } from './fixtures.js';
const hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const clone=x=>structuredClone(x);

function msg(id,type,source,destination,payload={}){return {message_id:id,type,source,destination,payload,formed:true,transmitted:false,received:false,uptaken:false,latency:0,path:[]};}
function send(state,message,channelId,cfg){
  const ch=state.channels[channelId]; const src=state.coalitions[ch.source]; const dst=state.coalitions[ch.destination];
  if(!src.standing[ch.standing_required]){state.failures.standing++; state.log.push({stage:'TRANSMISSION',channel:channelId,status:'STANDING_DENIED'}); return false;}
  if(cfg.dropChannel===channelId){state.failures.transmission++; state.log.push({stage:'TRANSMISSION',channel:channelId,status:'DROPPED'}); return false;}
  message.transmitted=true; message.latency+=ch.latency; message.path.push(channelId); src.message_history.push(message.message_id);
  if(cfg.escalationBlocked && [ChannelId.REVIEW_TO_RESTORATION,ChannelId.RESTORATION_TO_ASSEMBLY,ChannelId.EMERGENCY_ESCALATION].includes(channelId)){
    state.failures.escalation++; state.log.push({stage:'ESCALATION',channel:channelId,status:'BLOCKED'}); return false;
  }
  message.received=true; dst.received_history.push(message.message_id); state.log.push({stage:'TRANSMISSION',channel:channelId,status:'DELIVERED',latency:ch.latency,fidelity:ch.fidelity}); return true;
}

export function runCase(caseId){
  const cfg=CASES[caseId]; if(!cfg) throw new Error(`Unknown 2E case ${caseId}`);
  const state={case_id:caseId,note:cfg.note,coalitions:createTaskSpaceCoalitions(),channels:createChannels(),messages:[],log:[],failures:{detection:0,transmission:0,reception:0,standing:0,escalation:0,reconstruction:0,termination:0},
    detected:false,review_uptake:false,warrant_reconstructed:false,assembly_recomputed:false,reopen_signal:false,reopen_uptake:false,reopen_consequence:false,repair_completed:false,terminated:false,review_open:false,
    preserved_warrant_records:6,truth_claim:false,consensus_claim:false,automatic_reversal:false};
  if(cfg.standingRevoked) state.coalitions[CoalitionId.TECHNICAL_ANOMALY].standing.send_return=false;
  if(cfg.detection===false){state.failures.detection++; state.log.push({stage:'DETECTION',status:'FAILED'}); return finalize(state);}
  state.detected=true; state.log.push({stage:'DETECTION',status:'DETECTED',coalition:CoalitionId.TECHNICAL_ANOMALY});

  const alert=msg('M1',MessageType.RETURN_ALERT,CoalitionId.TECHNICAL_ANOMALY,CoalitionId.INDEPENDENT_REVIEW,{anomaly:'PROCEDURAL_FRAGILITY_RETURN',confidence:0.82,requested:'ASSESS'}); state.messages.push(alert);
  if(!send(state,alert,ChannelId.TECH_TO_REVIEW,cfg)) return finalize(state);
  if(cfg.receiverDiscount){state.failures.reception++; state.log.push({stage:'RECEPTION',status:'RECEIVED_NOT_CREDITED',receiver:CoalitionId.INDEPENDENT_REVIEW}); return finalize(state);}
  alert.uptaken=true; state.review_uptake=true; state.reopen_signal=true; state.review_open=true; state.log.push({stage:'RECEPTION',status:'UPTAKEN',receiver:CoalitionId.INDEPENDENT_REVIEW});

  if(cfg.topologyRecoverable===false){state.failures.reconstruction++; state.log.push({stage:'RECONSTRUCTION',status:'FAILED',records:state.preserved_warrant_records}); return finalize(state);}
  state.warrant_reconstructed=true; state.log.push({stage:'RECONSTRUCTION',status:'RECONSTRUCTED',records:state.preserved_warrant_records});

  const finding=msg('M2',MessageType.REVIEW_FINDING,CoalitionId.INDEPENDENT_REVIEW,CoalitionId.AUTHORIZATION,{finding:'CURRENT_AUTHORIZATION_PROCEDURALLY_FRAGILE',requested:'REOPEN_ASSEMBLY'}); state.messages.push(finding);
  if(cfg.primaryCaptured){
    state.failures.transmission++; state.log.push({stage:'TRANSMISSION',channel:ChannelId.REVIEW_TO_AUTH,status:'CAPTURED'});
    const appeal=msg('M3',MessageType.REOPEN_REQUEST,CoalitionId.INDEPENDENT_REVIEW,CoalitionId.RESTORATION_APPEAL,{reason:'PRIMARY_CHANNEL_CAPTURE',requested:'ESCALATE'}); state.messages.push(appeal);
    if(!send(state,appeal,ChannelId.REVIEW_TO_RESTORATION,cfg)) return finalize(state);
    appeal.uptaken=true; state.reopen_uptake=true;
    const restoration=msg('M4',MessageType.RESTORATION_FINDING,CoalitionId.RESTORATION_APPEAL,CoalitionId.PLURALITY_ASSEMBLY,{finding:'INDEPENDENT_REOPEN_WARRANTED'}); state.messages.push(restoration);
    if(!send(state,restoration,ChannelId.RESTORATION_TO_ASSEMBLY,cfg)) return finalize(state);
    restoration.uptaken=true;
  } else {
    if(!send(state,finding,ChannelId.REVIEW_TO_AUTH,cfg)) return finalize(state);
    finding.uptaken=true; state.reopen_uptake=true;
    const auth=msg('M3',MessageType.REOPEN_REQUEST,CoalitionId.AUTHORIZATION,CoalitionId.PLURALITY_ASSEMBLY,{status:'PROVISIONAL_AUTHORIZATION_STANDS_DURING_REVIEW',requested:'RECOMPUTE'}); state.messages.push(auth);
    if(!send(state,auth,ChannelId.AUTH_TO_ASSEMBLY,cfg)) return finalize(state);
    auth.uptaken=true;
  }
  state.assembly_recomputed=true; state.reopen_consequence=true; state.repair_completed=true; state.log.push({stage:'CONSEQUENCE',status:'WARRANT_TOPOLOGY_RECOMPUTED',automatic_reversal:false});

  if(cfg.terminationBlocked){state.failures.termination++; state.log.push({stage:'TERMINATION',status:'BLOCKED',review_open:true}); return finalize(state);}
  state.terminated=true; state.review_open=false; state.log.push({stage:'TERMINATION',status:'CLOSED_AFTER_REPAIR'}); return finalize(state);
}

function finalize(state){
  state.stage_success={detection:state.detected,transmission:state.messages.some(m=>m.transmitted),reception:state.review_uptake,uptake:state.reopen_uptake,reconstruction:state.warrant_reconstructed,consequence:state.reopen_consequence,termination:state.terminated};
  state.message_count=state.messages.length; state.total_latency=state.messages.reduce((a,m)=>a+m.latency,0); state.final_hash=hash(state); return state;
}
export function runAll(){return Object.values(ReturnCase).map(runCase);}
export { ReturnCase };
