# UCP-XR-PILOT-1 — Heterogeneous AI Governance Micro-World

Version 1.1.0 extends the original dependency-free Node pilot with explicit second-order governance-warrant formation, negotiated shared-task construction, Return latency/damping, recursive meta-governance checks, controlled branch provenance, and adversarial fault injection.

## Run

Requires Node.js 20+.

```bash
npm test
npm run demo
```

## Acceptance status

**25/25 tests pass.**

The original 12 acceptance tests remain intact. The extension adds tests that verify:

- shared tasks are negotiated rather than silently assumed;
- first-order rejection can coexist with a formed second-order governance warrant;
- authorization is blocked when the required second-order governance warrant has not formed;
- Return records actual latency against class-specific maximum latency;
- weak signals can be explicitly damped without being erased;
- governance independence is represented functionally rather than by organizational labels alone;
- controlled branches retain provenance and can be compared across common assumptions;
- deliberately corrupted governance states are caught by the invariant layer.

## New executable mechanisms

### Shared-task negotiation

Agents may accept, modify, or reject a candidate task. A formation rule determines whether the task is sufficiently shared to become operational. The final task retains proposal and response history.

### Second-order governance warrants

Agents separately register whether they support, conditionally support, withhold, or reject the legitimacy of a bounded action under specified governance conditions. This is distinct from their first-order substantive warrant about the policy itself.

**Registering a governance-warrant state is not authorization standing.** All governed agents may state their second-order warrant; only actors with authorization standing may authorize action.

### Return latency and damping

Every Return signal now records:

- consequence class;
- actual latency;
- maximum permitted latency;
- whether the signal is late;
- whether it is explicitly damped;
- whether it becomes consequential.

Weak signals are preserved even when damping withholds immediate consequential status.

### Functional independence / meta-governance

Governance functions are represented separately: detect, characterize, authorize, execute, observe, Return, review, and restore. Independence is represented as a relation between controllers and checking actors. Emergency authority fails the invariant if no sufficiently independent checking path remains.

### Branch provenance comparison

`runBranch()` records branch identity, changed variables, unchanged assumptions, rationale, and completion provenance. `compareBranches()` reports metric deltas and warrant differences without treating either branch as a real-world prediction.

## Adversarial harness

The test suite deliberately injects six governance faults and requires the invariant layer to detect each one:

1. action authorized without a second-order governance warrant;
2. shared task declared formed without sufficient negotiation;
3. emergency authority observes, reviews, and restores itself with no independent checker;
4. Return signal missing latency metadata;
5. Return signal hides whether damping occurred;
6. branch loses its provenance record.

All six deliberate violations are detected.

## Current scenario contrast

The demo compares two controlled branches sharing the same agent roster and initial public evidence:

- **disclose** — near miss disclosed; negotiated task; second-order warrant forms; bounded temporary restriction; inquiry remains open; Anticipatory Return triggers REOPEN; emergency authority is restored.
- **conceal** — near miss concealed; light monitoring; lower inquiry openness; capability shock; consequential signal routed to an actor without review standing.

The current instrumentation reports higher catastrophic exposure, corrigibility cost, and Dark-Coherence risk in the concealment branch. These values are test instrumentation, not validated social-science measures.

## Architectural claim ceiling

This remains a deterministic acceptance harness, not a validated social-science model and not a forecast of AI governance outcomes.

**Simulation ≠ prediction.**

**Heterogeneous agents ≠ empirically validated human agents.**

**Second-order warrant strength ≠ measured political legitimacy.**

**Functional-independence score ≠ validated institutional independence.**

**Dark-Coherence metric ≠ diagnosis of real-world Dark Coherence.**

The purpose is narrower: verify that the conceptual distinctions survive executable transitions, controlled branching, and adversarial fault injection without being silently collapsed by the implementation.
