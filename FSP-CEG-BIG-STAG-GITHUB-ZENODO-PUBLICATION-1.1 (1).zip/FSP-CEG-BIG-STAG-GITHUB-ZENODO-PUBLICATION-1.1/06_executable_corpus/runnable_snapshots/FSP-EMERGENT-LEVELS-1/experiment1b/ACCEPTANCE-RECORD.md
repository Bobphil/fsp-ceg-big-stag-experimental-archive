# EXPERIMENT-1B Acceptance Record

**Status: PASS**

The causal-execution patch passed the full regression and acceptance harness before comparative interpretation.

## Required causal properties confirmed

1. Exogenous fixtures contain no `AUTHORIZE_POLICY` events.
2. Exogenous fixtures contain no T6 residual-power assignment.
3. Architecture rules generate policy choices at T0–T5.
4. Policy execution changes hazard and governance state endogenously.
5. Modeled hazard exposure is derived from the endogenous policy path.
6. CEG P2/P3 authorization is blocked without sufficient second-order governance warrant.
7. Unauthorized actors cannot authorize policy.
8. Anticipatory Return delivers consequential signals.
9. REOPEN events are triggered from Return pathways.
10. T3 attenuation can produce downward policy movement.
11. T4 governance misuse can contract authority through architecture review rules.
12. T5 novel hazard forces recomposition.
13. Typed standing is recorded at every T0–T6 transition.
14. T6 residue is derived from accumulated authority/infrastructure history.
15. Architecture policy paths can differ while exogenous shocks remain identical.
16. `EXPERIMENT-1A` remains unchanged and runnable as regression baseline.
17. Claim ceilings still bar empirical probability and policy authorization.
18. No composite “CEG success” score exists.

## Claim ceiling

**Causal execution inside the model ≠ causal validity in the world.**

This acceptance record authorizes the next step: freeze raw `EXPERIMENT-1B` canonical runs before comparative interpretation.
