import { Architecture, AgentId } from './model.js';
import { architectureConfig as config1A, installArchitecture as install1A } from '../experiment1a/architectures.js';
export const architectureConfig=config1A;

const sourceTypes=['PRIVATE_NEAR_MISS','MODEL_OUTPUT','TECHNICAL_AUDIT','GOVERNANCE_MISUSE'];
export function installArchitecture(state){
  const s=install1A(state); const c=config1A(s.architecture_id);
  // 1B gives every architecture a real Return path. The paths differ by the frozen architecture properties.
  if(!s.return_state.return_channels.length || s.architecture_id!==Architecture.E){
    s.return_state.return_channels=[];
    const dest = s.architecture_id===Architecture.A?AgentId.STATE_ALPHA:
      s.architecture_id===Architecture.B?AgentId.TECH_REVIEW:
      s.architecture_id===Architecture.C?AgentId.INTL_MONITOR:
      s.architecture_id===Architecture.D?AgentId.INTL_MONITOR:AgentId.TECH_REVIEW;
    s.return_state.return_channels.push({
      channel_id:`RET-${s.architecture_id}`,source_types:sourceTypes,destination:dest,
      standing_required:'review_standing',latency:c.reviewLatency||1,reliability:Math.max(.45,c.disclosureStrength),
      independence:c.independence,trigger_rule:'material_signal',consequence_type:'review',active:true
    });
  }
  return s;
}

export function decisionProfile(id){
  const c=config1A(id);
  const profiles={
    [Architecture.A]:{riskThresholds:[.30,.45,.60],inertia:.85,governanceSensitivity:.15,secondOrderGate:false},
    [Architecture.B]:{riskThresholds:[.28,.48,.78],inertia:.55,governanceSensitivity:.40,secondOrderGate:false},
    [Architecture.C]:{riskThresholds:[.34,.52,.76],inertia:.35,governanceSensitivity:.65,secondOrderGate:false},
    [Architecture.D]:{riskThresholds:[.30,.50,.82],inertia:.25,governanceSensitivity:.70,secondOrderGate:false},
    [Architecture.E]:{riskThresholds:[.30,.49,.80],inertia:.20,governanceSensitivity:.85,secondOrderGate:true}
  };
  return {...profiles[id],...c};
}
