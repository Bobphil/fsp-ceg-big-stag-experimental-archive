import { reduce as reduce1A } from '../experiment1a/reducer.js';
import { Architecture, EventType, Policy } from './model.js';
const rank={ [Policy.P0]:0,[Policy.P1]:1,[Policy.P2]:2,[Policy.P3]:3 };
export function reduce(state,event){
  if(event.type===EventType.AUTHORIZE_POLICY){
    const auth=(state.institutions.functions?.authorize??[]);
    if(!auth.includes(event.authorized_by)) throw new Error(`Unauthorized actor ${event.authorized_by}`);
    if(state.architecture_id===Architecture.E && rank[event.policy]>=2){
      if(state.shared_task.task_status!=='FORMED') throw new Error('CEG authorization requires formed shared task');
      const vals=Object.values(state.agents).map(a=>a.second_order_warrants.XR_GOV);
      const support=vals.filter(v=>['ACCEPT','CONDITIONAL_ACCEPT'].includes(v)).length;
      if(support<4) throw new Error('CEG authorization requires sufficient second-order governance warrant');
    }
  }
  return reduce1A(state,event);
}
export const run=(state,events)=>events.reduce(reduce,state);
