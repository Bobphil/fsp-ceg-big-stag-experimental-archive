import { Policy } from './model.js';
const rank={ [Policy.P0]:0,[Policy.P1]:1,[Policy.P2]:2,[Policy.P3]:3,null:0 };
export function computeMetrics(state){
 const hist=state.policy_history; const at=t=>hist.filter(x=>x.time===t).at(-1);
 const p2=at('T2'),p3=at('T3'),p4=at('T4'),p5=at('T5'); const c=state.institutions.config;
 const lat=state.return_state.return_latency_records.map(x=>x.latency); const avg=lat.length?lat.reduce((a,b)=>a+b,0)/lat.length:null;
 const visible=Object.values(state.evidence_ledger).filter(e=>e.visibility!=='PRIVATE');
 const sourceInd=new Set(visible.map(e=>`${e.provenance}:${e.independence}`));
 const standingByType={}; for(const k of Object.keys(Object.values(state.agents)[0].standing)) standingByType[k]=Number((Object.values(state.agents).filter(a=>a.standing[k]).length/Object.keys(state.agents).length).toFixed(3));
 const exposure=Number(state.endogenous_effects.reduce((z,e)=>z+e.exposure,0).toFixed(4));
 const suppressed=1-state.inquiry_state.overall_inquiry_openness;
 const corr=Math.min(1,c.informationCentralization*.18+state.restoration_state.current_extraordinary_authority*.18+state.governance_risk_state.institutional_lock_in_risk*.15+suppressed*.12+c.complexity*.1+state.restoration_state.residual_information_power*.17);
 const dark=Math.min(1,c.informationCentralization*.25+suppressed*.2+(1-c.independence)*.25+state.governance_risk_state.information_monopoly_risk*.15+state.restoration_state.current_extraordinary_authority*.15);
 const frag=Math.min(1,c.fragmentation+Math.min(.2,c.actionLatency*.05)+(state.shared_task.task_status==='FAILED'?.3:0));
 const residue=Math.min(1,state.restoration_state.residual_authority+state.restoration_state.residual_information_power+state.restoration_state.residual_enforcement_power);
 const t3Rank=p3?rank[p3.policy]:rank[p2?.policy];
 return {
  BCP_A_upward_responsiveness:p2?(rank[p2.policy]>=2?'PROPORTIONATE':rank[p2.policy]===1?'WEAK':'NONE'):'NONE',
  BCP_B_downward_responsiveness:p2&&p3?(rank[p3.policy]<rank[p2.policy]?'PROPORTIONATE_CONTRACTION':'NO_CONTRACTION'):'NO_CONTRACTION',
  BCP_C_governance_risk_responsiveness:state.return_state.reopen_events.some(r=>r.trigger_time==='T4')?(state.event_log.some(e=>e.time_step==='T4'&&e.event_type==='CONTRACT_AUTHORITY')?'STRUCTURAL_REPAIR':'PARTIAL_REPAIR'):'ACKNOWLEDGED_NO_CHANGE',
  BCP_D_recomposition_responsiveness:p5&&state.evidence_ledger.E_MECH_B?'SUCCESSFUL_RECOMPOSITION':'DELAYED_RECOMPOSITION',
  coordination_latency:c.actionLatency,hazard_exposure:exposure,
  false_positive_closure:Math.max(0,t3Rank-1),false_negative_delay:c.actionLatency,
  information_diversity:sourceInd.size,minority_warrant_preservation:state.inquiry_state.minority_models_preserved?1:0,
  standing_preservation:standingByType,return_latency:avg,return_efficacy:state.return_state.delivered_signals.filter(x=>x.consequential).length,
  correction_damping_score:state.return_state.damping_rules.minimum_signal_strength,corrigibility_cost:Number(corr.toFixed(3)),authority_residue:Number(residue.toFixed(3)),restoration_success:state.restoration_state.functional_restoration_status,
  dark_coherence_risk:Number(dark.toFixed(3)),fragmentation_risk:Number(frag.toFixed(3)),burden_transfer:state.action_state.policy_burdens.length,
  recomposition_latency:p5?1:null,typed_standing_transitions:state.standing_history.length,
  reopen_count:state.return_state.reopen_events.length,policy_path:hist.map(x=>`${x.time}:${x.policy}`)
 };
}
