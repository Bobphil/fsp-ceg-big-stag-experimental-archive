import { Architecture, Policy, EventType, createInitialExperimentState } from './model.js';
import { installArchitecture } from './architectures.js';
import { initializeGovernance } from './causal.js';
import { reduce } from './reducer.js';
export const faults={
 cegWithoutSecondOrder(){let s=installArchitecture(createInitialExperimentState(Architecture.E));s=initializeGovernance(s);for(const a of Object.values(s.agents))a.second_order_warrants.XR_GOV='REJECT';return ()=>reduce(s,{type:EventType.AUTHORIZE_POLICY,time_step:'T2',authorized_by:'AGENT_STATE_ALPHA',policy:Policy.P2,basis:'fault'});},
 unauthorizedActor(){let s=installArchitecture(createInitialExperimentState(Architecture.C));return ()=>reduce(s,{type:EventType.AUTHORIZE_POLICY,time_step:'T2',authorized_by:'AGENT_DEV_ALPHA',policy:Policy.P2,basis:'fault'});}
};
