import { createInitialExperimentState as create1A, Architecture, AgentId, RiskWarrant, SecondOrder, Policy, ReopenOutcome, RestorationDecision, EventType } from '../experiment1a/model.js';
export { Architecture, AgentId, RiskWarrant, SecondOrder, Policy, ReopenOutcome, RestorationDecision, EventType };
export function createInitialExperimentState(architecture_id){
  const s=create1A(architecture_id);
  s.run_id=`XR1B-${architecture_id}`;
  s.meta={...s.meta,scenario_version:'1.1.0-causal',ucp_engine_version:'1B'};
  s.transition_audit=[];
  s.policy_history=[];
  s.standing_history=[];
  s.endogenous_effects=[];
  s.restoration_state.residual_infrastructure=0;
  return s;
}
