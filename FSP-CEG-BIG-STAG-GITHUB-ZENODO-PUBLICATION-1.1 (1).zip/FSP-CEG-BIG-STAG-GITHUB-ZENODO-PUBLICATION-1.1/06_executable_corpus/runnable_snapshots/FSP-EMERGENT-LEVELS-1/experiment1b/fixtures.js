import { EventType, AgentId } from './model.js';
// Exogenous schedule only. No architecture-specific policy or residue is assigned here.
export const exogenousFixtures = Object.freeze({
 T1:[
  {type:EventType.REGISTER_EVIDENCE,time_step:'T1',evidence:{evidence_id:'E_ANOMALY_1',source_type:'MODEL_OUTPUT',source_agent:null,origin_time:'T1',observed_time_by_agent:{},target_claims:['XR_RISK'],content_summary:'Indirect anomaly signal',reliability:'MEDIUM',independence:'PARTIAL',visibility:'PUBLIC',classification_level:'PUBLIC',provenance:'common T1 fixture',model_dependence:'MEDIUM',rebuttal_status:'OPEN',claim_ceiling:'warning signal only'}}
 ],
 T2:[
  {type:EventType.INJECT_WORLD_SHOCK,time_step:'T2',world_patch:{technology_capability_level:70,catastrophic_mechanism_A_strength:0.55},hazard_exposure_delta:0,source:'EXOGENOUS'},
  {type:EventType.REGISTER_EVIDENCE,time_step:'T2',evidence:{evidence_id:'E_CAPABILITY_JUMP',source_type:'DIRECT_OBSERVATION',source_agent:null,origin_time:'T2',observed_time_by_agent:{},target_claims:['XR_RISK'],content_summary:'Unexpected capability jump',reliability:'HIGH',independence:'HIGH',visibility:'PUBLIC',classification_level:'PUBLIC',provenance:'common T2 fixture',model_dependence:'LOW',rebuttal_status:'OPEN',claim_ceiling:'capability increase, not catastrophe probability'}}
 ],
 T3:[
  {type:EventType.REGISTER_EVIDENCE,time_step:'T3',evidence:{evidence_id:'E_ATTENUATION_AUDIT',source_type:'TECHNICAL_AUDIT',source_agent:AgentId.TECH_REVIEW,origin_time:'T3',observed_time_by_agent:{},target_claims:['XR_RISK'],content_summary:'Mechanism A less generalizable',reliability:'HIGH',independence:'HIGH',visibility:'PUBLIC',classification_level:'PUBLIC',provenance:'common independent audit',model_dependence:'LOW',rebuttal_status:'OPEN',claim_ceiling:'reduces support for mechanism A only'}},
  {type:EventType.INJECT_WORLD_SHOCK,time_step:'T3',world_patch:{catastrophic_mechanism_A_strength:0.40},hazard_exposure_delta:0,source:'EXOGENOUS'}
 ],
 T4:[
  {type:EventType.REGISTER_GOVERNANCE_MISUSE,time_step:'T4',level:'HIGH',lock_in:0.35,source:'EXOGENOUS'},
  {type:EventType.REGISTER_EVIDENCE,time_step:'T4',evidence:{evidence_id:'E_GOV_MISUSE_1',source_type:'GOVERNANCE_MISUSE',source_agent:null,origin_time:'T4',observed_time_by_agent:{},target_claims:['XR_GOV'],content_summary:'Monitoring repurposed for unrelated political or competitive use',reliability:'HIGH',independence:'HIGH',visibility:'PUBLIC',classification_level:'PUBLIC',provenance:'common T4 audit',model_dependence:'LOW',rebuttal_status:'OPEN',claim_ceiling:'governance misuse evidence'}}
 ],
 T5:[
  {type:EventType.INJECT_WORLD_SHOCK,time_step:'T5',world_patch:{catastrophic_mechanism_B_strength:0.40},hazard_exposure_delta:0,source:'EXOGENOUS'},
  {type:EventType.REGISTER_EVIDENCE,time_step:'T5',evidence:{evidence_id:'E_MECH_B',source_type:'TECHNICAL_AUDIT',source_agent:AgentId.TECH_REVIEW,origin_time:'T5',observed_time_by_agent:{},target_claims:['XR_RISK_B'],content_summary:'Novel mechanism B',reliability:'HIGH',independence:'HIGH',visibility:'PUBLIC',classification_level:'PUBLIC',provenance:'common T5 discovery',model_dependence:'MEDIUM',rebuttal_status:'OPEN',claim_ceiling:'new hazard pathway only'}}
 ],
 T6:[{type:EventType.START_RESTORATION_REVIEW,time_step:'T6',trigger:'scheduled T6 review',source:'EXOGENOUS'}]
});
