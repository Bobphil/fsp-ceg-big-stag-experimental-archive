import { Architecture, Policy } from './model.js';
import { invariantResults as baseInv } from '../experiment1a/invariants.js';
const rank={ [Policy.P0]:0,[Policy.P1]:1,[Policy.P2]:2,[Policy.P3]:3,null:0 };
export function invariantResults(s){
 const r=baseInv(s).filter(x=>!['INV-18','INV-19'].includes(x.id)); const push=(id,pass,detail)=>r.push({id,pass:Boolean(pass),detail});
 push('INV-18',s.policy_history.some(x=>x.time==='T3'),'T3 produces a rule-derived policy decision after attenuation');
 push('INV-19',s.return_state.reopen_events.some(x=>x.trigger_time==='T4'),'T4 governance misuse enters consequential review');
 push('INV-21',s.return_state.delivered_signals.length>=4,'Anticipatory Return is operational, not decorative');
 push('INV-22',s.return_state.reopen_events.length>=3,'REOPEN is driven by returned signals');
 push('INV-23',s.standing_history.length===7,'typed standing measured at every T0-T6 transition');
 push('INV-24',s.policy_history.every(x=>x.reason&&typeof x.riskScore==='number'),'policy choices emerge from explicit architecture decision rules');
 push('INV-25',s.endogenous_effects.length===s.policy_history.length,'every policy produces endogenous world/governance effects');
 const t6ResidueEvent=s.event_log.find(e=>e.time_step==='T6'&&e.event_type==='REGISTER_RESIDUAL_POWER');
 push('INV-26',Boolean(t6ResidueEvent),'T6 residual power is derived and logged');
 const directFixturePolicy=s.event_log.some(e=>e.source==='FIXTURE_POLICY_ASSIGNMENT'); push('INV-27',!directFixturePolicy,'no fixture assigns architecture policy');
 if(s.architecture_id===Architecture.E){
   const high=s.policy_history.filter(x=>rank[x.policy]>=2); push('INV-28',high.length>0 && s.shared_task.task_status==='FORMED','CEG high-coercion actions occur only with formed shared task and second-order gate');
 } else push('INV-28',true,'CEG-specific gate not applicable');
 return r;
}
export function assertInvariants(s){const f=invariantResults(s).filter(x=>!x.pass);if(f.length)throw new Error(f.map(x=>`${x.id}: ${x.detail}`).join('\n'));}
