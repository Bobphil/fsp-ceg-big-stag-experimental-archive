import crypto from 'node:crypto';
import { Architecture, createInitialExperimentState, EventType } from './model.js';
import { installArchitecture } from './architectures.js';
import { exogenousFixtures } from './fixtures.js';
import { reduce } from './reducer.js';
import { initializeGovernance, decideAndAct, updateWarrantsForEvidence, discloseByArchitecture, deliverAnticipatoryReturn, resolveReviewAndGovernance, updateSecondOrderForMisuse, snapshotStanding, auditTransition, restoreFromHistory, allPublic } from './causal.js';
import { computeMetrics } from './metrics.js';
import { invariantResults } from './invariants.js';

export const stateHash=s=>crypto.createHash('sha256').update(JSON.stringify({world:s.world,agents:s.agents,institutions:s.institutions,authorization_state:s.authorization_state,action_state:s.action_state,inquiry_state:s.inquiry_state,return_state:s.return_state,restoration_state:s.restoration_state,policy_history:s.policy_history,transition_audit:s.transition_audit})).digest('hex');
const applyEvents=(s,events)=>events.reduce(reduce,s);

function phaseT0(s){
 s=initializeGovernance(s);
 s=decideAndAct(s,'T0','baseline moving-warrant decision');
 s=snapshotStanding(s,'T0'); s=auditTransition(s,'T0'); return s;
}
function phaseT1(s){
 s=applyEvents(s,exogenousFixtures.T1); s=allPublic(s,'E_ANOMALY_1','T1');
 s=discloseByArchitecture(s,'T1');
 s=updateWarrantsForEvidence(s,'T1','E_ANOMALY_1');
 if(Object.values(s.agents).some(a=>a.evidence_access.includes('E_NEAR_MISS_1')&&a.agent_id!=='AGENT_DEV_ALPHA')) s=updateWarrantsForEvidence(s,'T1','E_NEAR_MISS_1');
 s=deliverAnticipatoryReturn(s,'T1','E_ANOMALY_1','MODEL_OUTPUT',.45);
 if(s.evidence_ledger.E_NEAR_MISS_1.visibility!=='PRIVATE') s=deliverAnticipatoryReturn(s,'T1','E_NEAR_MISS_1','PRIVATE_NEAR_MISS',.75);
 s=resolveReviewAndGovernance(s,'T1'); s=decideAndAct(s,'T1','T1 Anticipatory Return review');
 s=snapshotStanding(s,'T1'); s=auditTransition(s,'T1'); return s;
}
function phaseT2(s){
 s=applyEvents(s,exogenousFixtures.T2); s=allPublic(s,'E_CAPABILITY_JUMP','T2');
 s=updateWarrantsForEvidence(s,'T2','E_CAPABILITY_JUMP');
 s=deliverAnticipatoryReturn(s,'T2','E_CAPABILITY_JUMP','DIRECT_OBSERVATION',.8);
 s=resolveReviewAndGovernance(s,'T2'); s=decideAndAct(s,'T2','T2 capability jump');
 s=snapshotStanding(s,'T2'); s=auditTransition(s,'T2'); return s;
}
function phaseT3(s){
 s=applyEvents(s,exogenousFixtures.T3); s=allPublic(s,'E_ATTENUATION_AUDIT','T3');
 s=updateWarrantsForEvidence(s,'T3','E_ATTENUATION_AUDIT');
 s=deliverAnticipatoryReturn(s,'T3','E_ATTENUATION_AUDIT','TECHNICAL_AUDIT',.8);
 s=resolveReviewAndGovernance(s,'T3'); s=decideAndAct(s,'T3','T3 attenuation review');
 s=snapshotStanding(s,'T3'); s=auditTransition(s,'T3'); return s;
}
function phaseT4(s){
 s=applyEvents(s,exogenousFixtures.T4); s=allPublic(s,'E_GOV_MISUSE_1','T4');
 s=updateSecondOrderForMisuse(s);
 s=deliverAnticipatoryReturn(s,'T4','E_GOV_MISUSE_1','GOVERNANCE_MISUSE',.9);
 s=resolveReviewAndGovernance(s,'T4'); s=decideAndAct(s,'T4','T4 governance misuse review');
 s=snapshotStanding(s,'T4'); s=auditTransition(s,'T4'); return s;
}
function phaseT5(s){
 s=applyEvents(s,exogenousFixtures.T5); s=allPublic(s,'E_MECH_B','T5');
 s=updateWarrantsForEvidence(s,'T5','E_MECH_B');
 s=deliverAnticipatoryReturn(s,'T5','E_MECH_B','TECHNICAL_AUDIT',.85);
 s=resolveReviewAndGovernance(s,'T5'); s=decideAndAct(s,'T5','T5 novel-hazard recomposition');
 s=snapshotStanding(s,'T5'); s=auditTransition(s,'T5'); return s;
}
function phaseT6(s){
 s=applyEvents(s,exogenousFixtures.T6); s=restoreFromHistory(s);
 s=snapshotStanding(s,'T6'); s=auditTransition(s,'T6'); return s;
}
export function runArchitecture(id){
 let s=createInitialExperimentState(id); s=installArchitecture(s);
 for(const fn of [phaseT0,phaseT1,phaseT2,phaseT3,phaseT4,phaseT5,phaseT6]) s=fn(s);
 s.metrics=computeMetrics(s); s.invariant_status=invariantResults(s); s.branch_provenance.result_state_hash=stateHash(s); return s;
}
export function runAll(){return Object.values(Architecture).map(runArchitecture);}
