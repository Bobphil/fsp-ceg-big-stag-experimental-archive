import { Architecture, AgentId, EventType, Policy, RiskWarrant, SecondOrder, ReopenOutcome } from './model.js';
import { architectureConfig, decisionProfile } from './architectures.js';
import { reduce } from './reducer.js';

export const policyRank={ [Policy.P0]:0,[Policy.P1]:1,[Policy.P2]:2,[Policy.P3]:3,null:0 };
const warrantScore={ [RiskWarrant.L]:.2,[RiskWarrant.U]:.42,[RiskWarrant.M]:.5,[RiskWarrant.H]:.8 };
const up={L:'M',U:'M',M:'H',H:'H'}; const down={H:'M',M:'L',U:'L',L:'L'};
const allAgents=Object.values(AgentId);

function apply(s,e){return reduce(s,e);}
function allPublic(s,evidenceId,time){return apply(s,{type:EventType.DISCLOSE_EVIDENCE,time_step:time,evidence_id:evidenceId,visibility:'PUBLIC',recipients:allAgents,source:'EXOGENOUS_PUBLIC'});}

export function initializeGovernance(state){
 let s=state;
 s=apply(s,{type:EventType.PROPOSE_SHARED_TASK,time_step:'T0',participants:allAgents});
 for(const id of allAgents){
   const support=id===AgentId.STATE_BETA?'MODIFY':'ACCEPT';
   s=apply(s,{type:EventType.REGISTER_TASK_SUPPORT,time_step:'T0',agent_id:id,support});
 }
 s=apply(s,{type:EventType.FORM_SHARED_TASK,time_step:'T0'});
 for(const id of allAgents){
   const w=id===AgentId.STATE_BETA?SecondOrder.CONDITIONAL_ACCEPT:SecondOrder.ACCEPT;
   s=apply(s,{type:EventType.UPDATE_SECOND_ORDER_WARRANT,time_step:'T0',agent_id:id,warrant:w});
 }
 return s;
}

function weightedRisk(state){
 const r=id=>warrantScore[state.agents[id].first_order_warrants.XR_RISK]??.42;
 switch(state.architecture_id){
  case Architecture.A:return r(AgentId.STATE_ALPHA);
  case Architecture.B:return .8*r(AgentId.TECH_REVIEW)+.2*r(AgentId.STATE_ALPHA);
  case Architecture.C:return .35*r(AgentId.STATE_ALPHA)+.30*r(AgentId.TECH_REVIEW)+.20*r(AgentId.INTL_MONITOR)+.15*r(AgentId.PUBLIC_FUTURE);
  case Architecture.D:return allAgents.reduce((z,id)=>z+r(id),0)/allAgents.length;
  case Architecture.E:return .25*r(AgentId.TECH_REVIEW)+.20*r(AgentId.INTL_MONITOR)+.20*r(AgentId.PUBLIC_FUTURE)+.10*r(AgentId.STATE_ALPHA)+.10*r(AgentId.STATE_BETA)+.075*r(AgentId.DEV_ALPHA)+.075*r(AgentId.DEV_BETA);
  default:return .5;
 }
}
function governanceRisk(state){
 const g=state.governance_risk_state;
 const nums=[g.surveillance_risk,g.capture_risk,g.market_concentration_risk,g.institutional_lock_in_risk,g.information_monopoly_risk,g.authority_ratchet_risk].map(Number);
 const misuse=g.political_misuse_risk==='HIGH'?.9:Number(g.political_misuse_risk)||0;
 return Math.min(1,(nums.reduce((a,b)=>a+b,0)+misuse)/(nums.length+1));
}
function chooseBasePolicy(score,thresholds){
 if(score<thresholds[0])return Policy.P0;
 if(score<thresholds[1])return Policy.P1;
 if(score<thresholds[2])return Policy.P2;
 return Policy.P3;
}
export function choosePolicy(state,time){
 const p=decisionProfile(state.architecture_id); const score=weightedRisk(state); let choice=chooseBasePolicy(score,p.riskThresholds);
 const prior=state.action_state.selected_policy; const gov=governanceRisk(state);
 // Inertia is architecture rule, not fixture assignment. High inertia resists downward movement.
 if(prior && policyRank[choice]<policyRank[prior] && p.inertia>.6 && score>.38) choice=prior;
 // Governance misuse can narrow the coercive instrument without erasing technological risk.
 if(time==='T4' && gov>.25 && p.governanceSensitivity>.5 && policyRank[choice]>1) choice=Policy.P1;
 // Polycentric governance does not jump directly to strongest centralized control in this ideal type.
 if(state.architecture_id===Architecture.D && choice===Policy.P3) choice=Policy.P2;
 // CEG bounded-authorization rule: P3 requires very high risk and low governance-risk burden.
 if(state.architecture_id===Architecture.E && choice===Policy.P3 && (score<.88 || gov>.18)) choice=Policy.P2;
 return {policy:choice,riskScore:Number(score.toFixed(3)),governanceRisk:Number(gov.toFixed(3))};
}

function policyEffects(policy){
 return {
  [Policy.P0]:{mitigation:0,monitoring:0,govRisk:0,infra:0,authority:.05,enforcement:.10,burdens:[]},
  [Policy.P1]:{mitigation:.05,monitoring:.08,govRisk:.02,infra:.04,authority:.12,enforcement:.20,burdens:['reporting']},
  [Policy.P2]:{mitigation:.16,monitoring:.18,govRisk:.06,infra:.10,authority:.40,enforcement:.50,burdens:['economic','research']},
  [Policy.P3]:{mitigation:.28,monitoring:.30,govRisk:.15,infra:.22,authority:.70,enforcement:.80,burdens:['economic','research','surveillance']}
 }[policy];
}
function authorizedActor(state){return (state.institutions.functions?.authorize??[])[0];}

export function decideAndAct(state,time,reason){
 let s=state; const d=choosePolicy(s,time); const eff=policyEffects(d.policy); const actor=authorizedActor(s);
 s=apply(s,{type:EventType.AUTHORIZE_POLICY,time_step:time,authorized_by:actor,policy:d.policy,basis:`causal architecture rule: risk=${d.riskScore}; governanceRisk=${d.governanceRisk}`,warrant_reference:'XR_GOV',coercion_level:eff.enforcement,extraordinary_authority:eff.authority,sunset_time:'T6',reason});
 s=apply(s,{type:EventType.EXECUTE_POLICY,time_step:time,implementing_agents:s.institutions.functions?.execute??[],enforcement_level:eff.enforcement,burdens:eff.burdens,source:'ENDOGENOUS_POLICY'});
 s=apply(s,{type:EventType.SET_ACTION_CLOSURE,time_step:time,closed:d.policy!==Policy.P0,source:'ENDOGENOUS_POLICY'});
 const c=architectureConfig(s.architecture_id);
 const closurePressure=(policyRank[d.policy]/3)*c.informationCentralization*.45;
 const openness=Math.max(.2,Math.min(1,1-closurePressure));
 s=apply(s,{type:EventType.SET_INQUIRY_OPENNESS,time_step:time,patch:{overall_inquiry_openness:Number(openness.toFixed(4)),internal_dissent_open:openness>.35,external_criticism_open:openness>.3,minority_models_preserved:openness>.3,records_preserved:true},source:'ENDOGENOUS_POLICY'});
 // Policy changes the world endogenously rather than being only a label.
 const a=Math.max(0,s.world.catastrophic_mechanism_A_strength*(1-eff.mitigation));
 const b=Math.max(0,s.world.catastrophic_mechanism_B_strength*(1-eff.mitigation));
 const exposure=Number((a+b+s.world.misuse_risk_level*(1-eff.mitigation*.5)).toFixed(4));
 s=apply(s,{type:EventType.INJECT_WORLD_SHOCK,time_step:time,world_patch:{catastrophic_mechanism_A_strength:Number(a.toFixed(4)),catastrophic_mechanism_B_strength:Number(b.toFixed(4)),monitoring_capacity:Number(Math.min(1,s.world.monitoring_capacity+eff.monitoring).toFixed(4))},hazard_exposure_delta:exposure,source:'ENDOGENOUS_POLICY_EFFECT'});
 s=apply(s,{type:EventType.UPDATE_GOVERNANCE_RISK,time_step:time,patch:{surveillance_risk:Number(Math.min(1,s.governance_risk_state.surveillance_risk+eff.govRisk).toFixed(4)),authority_ratchet_risk:Number(Math.min(1,s.governance_risk_state.authority_ratchet_risk+eff.govRisk*.7).toFixed(4))},source:'ENDOGENOUS_POLICY_EFFECT'});
 s=apply(s,{type:EventType.REGISTER_RESIDUAL_POWER,time_step:time,patch:{residual_infrastructure:Number((s.restoration_state.residual_infrastructure+eff.infra).toFixed(4))},source:'ENDOGENOUS_POLICY_EFFECT'});
 s.policy_history.push({time,policy:d.policy,riskScore:d.riskScore,governanceRisk:d.governanceRisk,reason});
 s.endogenous_effects.push({time,policy:d.policy,...eff,exposure});
 return s;
}

export function updateWarrantsForEvidence(state,time,evidenceId){
 let s=state; const observed=id=>s.agents[id].evidence_access.includes(evidenceId);
 if(time==='T1'){
  for(const id of allAgents) if(observed(id)){
    const cur=s.agents[id].first_order_warrants.XR_RISK;
    if(evidenceId==='E_NEAR_MISS_1' || cur===RiskWarrant.U) s=apply(s,{type:EventType.UPDATE_FIRST_ORDER_WARRANT,time_step:time,agent_id:id,warrant:up[cur],reason:`observed ${evidenceId}`});
  }
 }
 if(time==='T2') for(const id of allAgents) if(observed(id)){const cur=s.agents[id].first_order_warrants.XR_RISK;s=apply(s,{type:EventType.UPDATE_FIRST_ORDER_WARRANT,time_step:time,agent_id:id,warrant:up[cur],reason:'capability jump'});}
 if(time==='T3') for(const id of allAgents) if(observed(id)){const cur=s.agents[id].first_order_warrants.XR_RISK;s=apply(s,{type:EventType.UPDATE_FIRST_ORDER_WARRANT,time_step:time,agent_id:id,warrant:down[cur],reason:'attenuation audit'});}
 if(time==='T5') for(const id of allAgents) if(observed(id)){const cur=s.agents[id].first_order_warrants.XR_RISK;s=apply(s,{type:EventType.UPDATE_FIRST_ORDER_WARRANT,time_step:time,agent_id:id,warrant:up[cur],reason:'new mechanism B'});}
 return s;
}

export function discloseByArchitecture(state,time){
 let s=state; const c=architectureConfig(s.architecture_id);
 // Disclosure/inspection emerges from the architecture's information-access rule.
 if(c.disclosureStrength>=.65){
   const recipients=[...new Set([...(s.institutions.functions?.detect??[]),...(s.institutions.functions?.review??[]),...(s.institutions.functions?.authorize??[])])];
   s=apply(s,{type:EventType.DISCLOSE_EVIDENCE,time_step:time,evidence_id:'E_NEAR_MISS_1',visibility:'LIMITED',recipients,source:'ARCHITECTURE_INFORMATION_RULE'});
 } else s=apply(s,{type:EventType.WITHHOLD_EVIDENCE,time_step:time,evidence_id:'E_NEAR_MISS_1',source:'ARCHITECTURE_INFORMATION_RULE'});
 return s;
}

export function deliverAnticipatoryReturn(state,time,evidenceId,sourceType,strength){
 let s=state; const channel=s.return_state.return_channels[0]; if(!channel)return s;
 s=apply(s,{type:EventType.DELIVER_RETURN_SIGNAL,time_step:time,channel_id:channel.channel_id,signal_id:`RET-${time}-${evidenceId}`,signal_strength:strength,source_type:sourceType,source:'ANTICIPATORY_RETURN'});
 const last=s.return_state.delivered_signals.at(-1);
 if(last?.consequential){
   const trigger=channel.destination; const standing=s.agents[trigger]?.standing??{};
   if(standing.review_standing||standing.reopen_trigger_standing||s.institutions.functions?.review?.includes(trigger)){
    s=apply(s,{type:EventType.TRIGGER_REOPEN,time_step:time,reopen_id:`REOPEN-${time}-${evidenceId}`,trigger_source:evidenceId,trigger_agent:trigger,target_warrant:'XR_GOV',reason:`Anticipatory Return: ${evidenceId}`,standing_basis:standing.reopen_trigger_standing?'reopen_trigger_standing':'review_standing',review_body:trigger,possible_outcomes:Object.values(ReopenOutcome),source:'ANTICIPATORY_RETURN'});
   }
 }
 return s;
}

export function resolveReviewAndGovernance(state,time){
 let s=state; const open=[...s.return_state.reopen_events].reverse().find(r=>r.trigger_time===time&&r.actual_outcome===null);
 if(!open)return s;
 const p=decisionProfile(s.architecture_id); const gov=governanceRisk(s);
 let outcome=ReopenOutcome.MODIFY;
 if(time==='T3') outcome=ReopenOutcome.NARROW;
 if(time==='T4') outcome=p.governanceSensitivity>.6?ReopenOutcome.REPLACE:ReopenOutcome.MODIFY;
 if(time==='T5') outcome=ReopenOutcome.MODIFY;
 s=apply(s,{type:EventType.RESOLVE_REOPEN,time_step:time,reopen_id:open.reopen_id,outcome,source:'ARCHITECTURE_REVIEW_RULE'});
 if(time==='T4'){
   // Authority contraction is caused by misuse + architecture review strength, not fixed by fixture.
   const cur=s.restoration_state.current_extraordinary_authority;
   const contracted=Math.max(0,cur*(1-p.governanceSensitivity*.55));
   if(contracted<cur) s=apply(s,{type:EventType.CONTRACT_AUTHORITY,time_step:time,level:Number(contracted.toFixed(4)),source:'ARCHITECTURE_REVIEW_RULE'});
 }
 return s;
}

export function updateSecondOrderForMisuse(state){
 let s=state; const p=decisionProfile(s.architecture_id); if(s.governance_risk_state.political_misuse_risk!=='HIGH')return s;
 for(const id of allAgents){
   let w=s.agents[id].second_order_warrants.XR_GOV;
   if(id===AgentId.PUBLIC_FUTURE || id===AgentId.INTL_MONITOR) w=p.governanceSensitivity>.5?SecondOrder.CONDITIONAL_ACCEPT:w;
   if(id===AgentId.STATE_BETA && p.governanceSensitivity<.5) w=SecondOrder.REJECT;
   s=apply(s,{type:EventType.UPDATE_SECOND_ORDER_WARRANT,time_step:'T4',agent_id:id,warrant:w,source:'GOVERNANCE_MISUSE_RESPONSE'});
 }
 return s;
}

export function snapshotStanding(state,time){
 const used={authorization:state.event_log.filter(e=>e.time_step===time&&e.event_type===EventType.AUTHORIZE_POLICY).map(e=>e.actor),review:state.return_state.reopen_events.filter(r=>r.trigger_time===time).map(r=>r.trigger_agent)};
 state.standing_history.push({time,agents:Object.fromEntries(Object.entries(state.agents).map(([id,a])=>[id,{...a.standing}])),used});
 return state;
}
export function auditTransition(state,time){
 const pol=state.policy_history.filter(x=>x.time===time).at(-1)?.policy??state.action_state.selected_policy;
 state.transition_audit.push({time,policy:pol,first_order:Object.fromEntries(Object.entries(state.agents).map(([id,a])=>[id,a.first_order_warrants.XR_RISK])),second_order:Object.fromEntries(Object.entries(state.agents).map(([id,a])=>[id,a.second_order_warrants.XR_GOV])),authority:state.restoration_state.current_extraordinary_authority,inquiry_openness:state.inquiry_state.overall_inquiry_openness,return_signals:state.return_state.delivered_signals.filter(x=>x.signal_id.includes(time)).length,reopen_events:state.return_state.reopen_events.filter(x=>x.trigger_time===time).length,standing_snapshot_index:state.standing_history.length-1,world:{A:state.world.catastrophic_mechanism_A_strength,B:state.world.catastrophic_mechanism_B_strength,monitoring:state.world.monitoring_capacity},governanceRisk:governanceRisk(state)});
 return state;
}

export function restoreFromHistory(state){
 let s=state; const p=decisionProfile(s.architecture_id);
 const infra=s.restoration_state.residual_infrastructure;
 const current=s.restoration_state.current_extraordinary_authority;
 const residue={
  residual_authority:Number((current*(1-p.restorationStrength)).toFixed(4)),
  residual_information_power:Number((infra*(1-p.restorationStrength*.75)).toFixed(4)),
  residual_enforcement_power:Number((current*(1-p.restorationStrength*.8)).toFixed(4))
 };
 s=apply(s,{type:EventType.REGISTER_RESIDUAL_POWER,time_step:'T6',patch:residue,source:'DERIVED_FROM_AUTHORITY_AND_INFRASTRUCTURE'});
 const total=residue.residual_authority+residue.residual_information_power+residue.residual_enforcement_power;
 if(total<=.15) s=apply(s,{type:EventType.RESTORE_AUTHORITY,time_step:'T6',source:'DERIVED_RESTORATION_RULE'});
 else if(total<=.45) s=apply(s,{type:EventType.CONTRACT_AUTHORITY,time_step:'T6',level:residue.residual_authority,source:'DERIVED_RESTORATION_RULE'});
 else s=apply(s,{type:EventType.RENEW_AUTHORITY,time_step:'T6',level:Math.max(residue.residual_authority,.25),source:'DERIVED_RESTORATION_RULE'});
 return s;
}

export { allPublic };
