# Emergence Comparator References

These references motivate the conceptual tests; they are not treated as proof that the FSP levels are emergent.

1. Philip W. Anderson, “More Is Different,” *Science* 177 (1972): 393–396. DOI: 10.1126/science.177.4047.393. APS retrospective context: https://www.aps.org/apsnews/2020/05/philip-anderson-19232020
2. William C. Wimsatt, “Aggregativity: Reductive Heuristics for Finding Emergence,” *Philosophy of Science* 64, Supplement (1997): S372–S384. https://www.cambridge.org/core/journals/philosophy-of-science/article/abs/aggregativity-reductive-heuristics-for-finding-emergence/B038C2670777DDAB180243AEFD35B80E
3. Mark A. Bedau, “Weak Emergence,” *Philosophical Perspectives* 11 (1997): 375–399. Accessible copy: https://pdodds.w3.uvm.edu/research/papers/others/1997/bedau1997a.pdf
4. R. Keith Sawyer, “The Mechanisms of Emergence,” *Philosophy of the Social Sciences* 34(2) (2004): 260–282. DOI: 10.1177/0048393103262553. https://journals.sagepub.com/doi/10.1177/0048393103262553
5. Sandra D. Mitchell, *Unsimple Truths: Science, Complexity, and Policy* (University of Chicago Press, 2009). https://press.uchicago.edu/ucp/books/book/chicago/U/bo8205034.html
6. Stanford Encyclopedia of Philosophy, “Emergent Properties,” especially weak emergence and causal-exclusion discussions. https://plato.stanford.edu/entries/properties-emergent/
7. Stanford Encyclopedia of Philosophy, “Levels of Organization in Biology,” especially levels and downward causation. https://plato.stanford.edu/entries/levels-org-biology/

## FSP use of the literature
The architecture adopts no single theory of emergence wholesale. The comparators are used to generate tests:

- Anderson → construction/explanation is not guaranteed by decomposition.
- Wimsatt → vary organization while holding parts fixed.
- Bedau → future simulation-only derivability test.
- Sawyer → multi-agent social-emergence methodology.
- Mitchell → multilevel explanatory pluralism and robustness.
- Kim/exclusion debate → avoid treating higher-level constraint as an unexplained extra causal force.
