# Acceptance Record — FSP-RECURSIVE-INQUIRY-2

- Full inherited + R2 harness: **288/288 PASS**; 0 failures.
- Dedicated R2 harness: **15/15 PASS**; 0 failures.
- Inherited files byte-identical excluding intentionally extended package.json: **276**.
- Unexpected inherited changes: **0**.

## Frozen findings
1. Strict decomposition without remainder: **REJECTED**.
2. Decomposition with explicit scale-specific remainder: **SUPPORTED inside model**.
3. Strict failure isomorphism: **REJECTED**.
4. Recurrent failure core: representation substitution, residue loss, premature closure.
5. Six candidate shared corrigibility invariants survive cross-scale check; each ablation destroys modeled admissibility.
6. Sufficient decompression stops before total recovery when no current action-sensitive distinction remains open and future reopening capacity is preserved.
7. Irrecoverability escalates to meta-REOPEN rather than generating infinite local recursion.
8. Information metrics remain descriptive and cannot assign standing or authorization.
