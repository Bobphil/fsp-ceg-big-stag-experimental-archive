import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';
import {runAllDifficultEmergence} from './runner.js';
const outDir=path.resolve('../results/raw');fs.mkdirSync(outDir,{recursive:true});
const runs=runAllDifficultEmergence();const manifest={experiment:'EXPERIMENT-1G',frozen_at:new Date().toISOString(),files:[]};
for(const r of runs){const p=path.join(outDir,`${r.grammar}.json`);fs.writeFileSync(p,JSON.stringify(r,null,2));const b=fs.readFileSync(p);manifest.files.push({grammar:r.grammar,file:path.basename(p),sha256:crypto.createHash('sha256').update(b).digest('hex')});}
fs.writeFileSync(path.resolve('../results/FREEZE-MANIFEST.json'),JSON.stringify(manifest,null,2));console.log(JSON.stringify(manifest,null,2));
