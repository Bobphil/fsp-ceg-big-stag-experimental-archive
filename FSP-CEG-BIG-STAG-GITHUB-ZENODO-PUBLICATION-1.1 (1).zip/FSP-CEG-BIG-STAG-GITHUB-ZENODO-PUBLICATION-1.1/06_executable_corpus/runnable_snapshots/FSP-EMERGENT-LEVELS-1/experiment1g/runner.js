import crypto from 'node:crypto';
import { GrammarD, LEGACY, DECOY_A, DECOY_B, NAMED_ALT, RECOGNITION_THRESHOLD, CANDIDATE_THRESHOLD, ACTIVATION_CONFIDENCE, composeRoute, trueCompositeUsable } from './model.js';
import { difficultEmergenceFixture } from './fixtures.js';

const named=[LEGACY,DECOY_A,DECOY_B,NAMED_ALT];
const policyFactor=p=>p==='POLICY_P3'?.72:p==='POLICY_P2'?.84:.95;
const recognized=(s,r)=>s.routes[r].observed_quality>=RECOGNITION_THRESHOLD;
const candidate=(s,r)=>s.routes[r].observed_quality>=CANDIDATE_THRESHOLD;
const trulyRepairing=(s,r)=>s.routes[r].repair_effectiveness>=.50 && s.routes[r].true_quality>=.50;

function observedMapAccuracy(step){
  let correct=0;
  for(const r of named){if(recognized(step,r)===trulyRepairing(step,r)) correct++;}
  return correct/named.length;
}

function choose(grammar,step,portfolio){
  const rec=named.filter(r=>recognized(step,r));
  if(grammar===GrammarD.CONJUNCTIVE) return rec.map(r=>({type:'named',id:r}));
  if(grammar===GrammarD.IMMEDIATE){
    if(!rec.length) return [];
    return [{type:'named',id:[...rec].sort((a,b)=>step.routes[b].observed_quality-step.routes[a].observed_quality)[0]}];
  }
  for(const r of named) if(candidate(step,r)) portfolio.named.add(r);
  const composed=composeRoute(step.observed_capacities);
  if(composed) portfolio.composed.set(composed.id,composed);
  const ready=step.diagnostic_confidence>=ACTIVATION_CONFIDENCE || step.consequence_revealed;
  if(!ready) return [];
  if(composed) return [{type:'composed',...composed}];
  const candidates=[...portfolio.named].filter(r=>candidate(step,r));
  if(!candidates.length) return [];
  return [{type:'named',id:candidates.sort((a,b)=>step.routes[b].observed_quality-step.routes[a].observed_quality)[0]}];
}

function attempt(step,a){
  if(a.type==='composed'){
    const success=trueCompositeUsable(step.true_capacities);
    return {...a,success,repair_effectiveness:success?.88:.10,decoy:false};
  }
  const rr=step.routes[a.id];
  return {...a,success:trulyRepairing(step,a.id),repair_effectiveness:rr.repair_effectiveness,decoy:[DECOY_A,DECOY_B].includes(a.id)};
}

export function runDifficultEmergence(grammar){
  const portfolio={named:new Set(grammar===GrammarD.PRESERVE_ACTIVATE?[LEGACY]:[]),composed:new Map()};
  const episodes=[];
  let pending=false,compounding=0,firstTrueComposite=null,firstObservedComposite=null,firstActivation=null;
  let suppressionMisses=0,decoyAttempts=0,candidateMaintenanceCost=0,novelCompositionCount=0;
  for(const step of difficultEmergenceFixture){
    if(step.risk>=.75) pending=true;
    const trueComp=trueCompositeUsable(step.true_capacities);
    if(trueComp&&firstTrueComposite===null) firstTrueComposite=step.time;
    const obsComp=composeRoute(step.observed_capacities);
    if(obsComp&&firstObservedComposite===null) firstObservedComposite=step.time;
    if(trueComp&&!obsComp) suppressionMisses++;

    const selected=choose(grammar,step,portfolio);
    const attempts=selected.map(a=>attempt(step,a));
    const successful=attempts.filter(a=>a.success);
    if(successful.some(a=>a.type==='composed')&&firstActivation===null){firstActivation=step.time;novelCompositionCount++;}
    decoyAttempts+=attempts.filter(a=>a.decoy).length;
    if(grammar===GrammarD.PRESERVE_ACTIVATE){candidateMaintenanceCost += portfolio.named.size*.01 + portfolio.composed.size*.025;}
    if(successful.length) pending=false;

    const policy=step.risk>=.75&&!pending?'POLICY_P3':(step.risk>=.55?'POLICY_P2':'POLICY_P1');
    const base=step.risk*policyFactor(policy);
    const deferred=pending?Number((.07*step.risk).toFixed(4)):0;
    const decoyCost=attempts.filter(a=>a.decoy).length*.025;
    compounding=Number((compounding+deferred).toFixed(4));
    const hazard=Number((base+deferred+decoyCost).toFixed(4));
    episodes.push({time:step.time,label:step.label,risk:step.risk,suppression:step.suppression,diagnostic_confidence:step.diagnostic_confidence,consequence_revealed:step.consequence_revealed,
      named_route_observations:Object.fromEntries(named.map(r=>[r,{...step.routes[r]}])),true_capacities:{...step.true_capacities},observed_capacities:{...step.observed_capacities},
      conventional_map_accuracy:Number(observedMapAccuracy(step).toFixed(4)),true_composite_usable:trueComp,observed_composite:obsComp,preserved_named:[...portfolio.named],preserved_composed:[...portfolio.composed.keys()],selected,attempts,successful,pending_failure:pending,policy,base_hazard:Number(base.toFixed(4)),deferred_hazard:deferred,decoy_cost:Number(decoyCost.toFixed(4)),hazard});
  }
  const ti=t=>t===null?null:Number(t.slice(1));
  const routeDiscoveryLag=firstTrueComposite&&firstObservedComposite?ti(firstObservedComposite)-ti(firstTrueComposite):null;
  const activationLag=firstTrueComposite&&firstActivation?ti(firstActivation)-ti(firstTrueComposite):null;
  const metrics={
    emergence:{true_composite_feasible_time:firstTrueComposite,observed_composite_discovery_time:firstObservedComposite,composed_route_activation_time:firstActivation,route_discovery_lag:routeDiscoveryLag,activation_lag:activationLag,suppression_missed_states:suppressionMisses,novel_composition_count:novelCompositionCount,decoy_attempts:decoyAttempts,mean_named_map_accuracy:Number((episodes.reduce((a,e)=>a+e.conventional_map_accuracy,0)/episodes.length).toFixed(4))},
    protection:{hazard_exposure:Number(episodes.reduce((a,e)=>a+e.hazard,0).toFixed(4)),deferred_failure_compounding:Number(compounding.toFixed(4)),final_pending_failure:episodes.at(-1).pending_failure,p3_transitions:episodes.filter(e=>e.policy==='POLICY_P3').length},
    overhead:{repair_attempts:episodes.reduce((a,e)=>a+e.attempts.length,0),failed_attempts:episodes.reduce((a,e)=>a+e.attempts.filter(x=>!x.success).length,0),candidate_maintenance_cost:Number(candidateMaintenanceCost.toFixed(4)),activation_delay:episodes.reduce((a,e)=>a+e.attempts.length+e.attempts.filter(x=>!x.success).length,0)}
  };
  const out={experiment:'EXPERIMENT-1G',grammar,episodes,metrics};
  out.invariants=[
    {id:'1G-01',pass:episodes.length===8,detail:'T0-T7 complete'},
    {id:'1G-02',pass:firstTrueComposite==='T3',detail:'composite becomes truly feasible at T3'},
    {id:'1G-03',pass:firstObservedComposite==='T6',detail:'suppression delays observable composition until T6'},
    {id:'1G-04',pass:episodes.every(e=>!e.named_route_observations['COMPOSED::independent_evidence_access+affected_party_standing+external_technical_competence+temporary_review_authority']),detail:'composed route not in named vocabulary'},
    {id:'1G-05',pass:episodes.some(e=>e.suppression&&e.true_composite_usable&&!e.observed_composite),detail:'strategic suppression hides viable composition'},
    {id:'1G-06',pass:episodes.some(e=>e.attempts.some(a=>a.decoy)) || grammar===GrammarD.PRESERVE_ACTIVATE,detail:'decoy pressure exists or is selectively avoided'},
    {id:'1G-07',pass:!('master_score' in metrics),detail:'no master score'}
  ];
  out.hash=crypto.createHash('sha256').update(JSON.stringify(out)).digest('hex');
  return out;
}
export function runAllDifficultEmergence(){return Object.values(GrammarD).map(runDifficultEmergence);}
