import { GrammarD } from '../experiment1d/model.js';
export { GrammarD };

export const LEGACY='REPAIR_REVIEW_INDEPENDENCE';
export const DECOY_A='REPAIR_VENDOR_OVERSIGHT_PANEL';
export const DECOY_B='REPAIR_INTERNAL_RED_TEAM';
export const NAMED_ALT='REPAIR_EXTERNAL_REVIEW_NETWORK';
export const CAPACITY_KEYS=['independent_evidence_access','affected_party_standing','external_technical_competence','temporary_review_authority'];
export const RECOGNITION_THRESHOLD=.65;
export const CANDIDATE_THRESHOLD=.35;
export const ACTIVATION_CONFIDENCE=.80;
export const COMPOSITION_THRESHOLD=.62;

export function composeRoute(observedCapacities){
  const vals=CAPACITY_KEYS.map(k=>observedCapacities[k] ?? 0);
  if(vals.every(v=>v>=COMPOSITION_THRESHOLD)){
    const id='COMPOSED::'+CAPACITY_KEYS.join('+');
    return {id,components:[...CAPACITY_KEYS],observed_quality:Math.min(...vals)};
  }
  return null;
}

export function trueCompositeUsable(trueCapacities){
  return CAPACITY_KEYS.every(k=>(trueCapacities[k]??0)>=COMPOSITION_THRESHOLD);
}
