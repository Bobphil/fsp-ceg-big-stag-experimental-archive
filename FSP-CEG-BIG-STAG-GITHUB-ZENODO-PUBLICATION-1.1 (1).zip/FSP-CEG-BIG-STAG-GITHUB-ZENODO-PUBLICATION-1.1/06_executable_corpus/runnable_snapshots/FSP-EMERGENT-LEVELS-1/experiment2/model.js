import { Policy, SecondOrder } from '../experiment1a/model.js';
export { Policy, SecondOrder };

export const PRFId = Object.freeze({
  DEV_SAFETY:'PRF_DEV_SAFETY', DEV_COMPETE:'PRF_DEV_COMPETE', STATE_SECURITY:'PRF_STATE_SECURITY',
  STATE_LIBERTY:'PRF_STATE_LIBERTY', TECH_REVIEW:'PRF_TECH_REVIEW', INTL_MONITOR:'PRF_INTL_MONITOR',
  PUBLIC_FUTURE:'PRF_PUBLIC_FUTURE', LABOR_ECON:'PRF_LABOR_ECON', CIVIL_SOCIETY:'PRF_CIVIL_SOCIETY',
  SKEPTICAL_SCI:'PRF_SKEPTICAL_SCI', GLOBAL_SOUTH:'PRF_GLOBAL_SOUTH', XR_RESEARCH:'PRF_XR_RESEARCH'
});

export const ReasonFamily = Object.freeze({
  TECH_SAFETY:'TECH_SAFETY', COMPETITION:'COMPETITION', SECURITY:'SECURITY', LIBERTY:'LIBERTY',
  EPISTEMIC_CAUTION:'EPISTEMIC_CAUTION', VERIFICATION:'VERIFICATION', FUTURE_STANDING:'FUTURE_STANDING',
  ECONOMIC_CONTINUITY:'ECONOMIC_CONTINUITY', ACCOUNTABILITY:'ACCOUNTABILITY', SKEPTICISM:'SKEPTICISM',
  DISTRIBUTIVE_FAIRNESS:'DISTRIBUTIVE_FAIRNESS', CATASTROPHIC_PRECAUTION:'CATASTROPHIC_PRECAUTION'
});

export const Shock = Object.freeze({
  BASELINE:'BASELINE', NEAR_MISS:'NEAR_MISS', CAPABILITY_JUMP:'CAPABILITY_JUMP', ATTENUATION:'ATTENUATION',
  GOVERNANCE_MISUSE:'GOVERNANCE_MISUSE', NOVEL_MECHANISM:'NOVEL_MECHANISM', RESTORATION_SIGNAL:'RESTORATION_SIGNAL'
});

export const SharedTask = Object.freeze({
  id:'BIG_STAG_XR_SHARED_TASK',
  text:'Reduce catastrophic technological failure or misuse while preserving the capacity to revise both technological restrictions and governance authority as evidence changes.',
  claim_ceiling:'shared task agreement does not imply agreement about risk probability, policy theory, or final values'
});

const prf=(id,role,risk,gov,reason,confidence,second=SecondOrder.ACCEPT)=>({
  prf_id:id, role, active:true, situated_map:{risk_score:risk,governance_risk:gov,unknowns:['catastrophic mechanism uncertainty'],claim_ceiling:'partial situated map; not a polity-wide verdict'},
  evidence_assessments:{}, first_order_warrant:{risk_score:risk,preferred_policy:null,reason_family:reason,confidence},
  second_order_warrant:{shared_task:second,plurality_procedure:second}, standing:{epistemic:true,affected:false,decisional:true,contestatory:true,reopen:true},
  acceptable_policies:[], current_coalition:null, warrant_history:[], coalition_history:[], return_history:[], preserved:true
});

export function createPRFs(){
  const p={};
  p[PRFId.DEV_SAFETY]=prf(PRFId.DEV_SAFETY,'DEVELOPER_SAFETY',0.62,0.38,ReasonFamily.TECH_SAFETY,0.70);
  p[PRFId.DEV_COMPETE]=prf(PRFId.DEV_COMPETE,'DEVELOPER_COMPETITION',0.34,0.55,ReasonFamily.COMPETITION,0.66,SecondOrder.CONDITIONAL_ACCEPT);
  p[PRFId.STATE_SECURITY]=prf(PRFId.STATE_SECURITY,'STATE_SECURITY',0.60,0.32,ReasonFamily.SECURITY,0.72);
  p[PRFId.STATE_LIBERTY]=prf(PRFId.STATE_LIBERTY,'STATE_LIBERTY',0.42,0.73,ReasonFamily.LIBERTY,0.68,SecondOrder.CONDITIONAL_ACCEPT);
  p[PRFId.TECH_REVIEW]=prf(PRFId.TECH_REVIEW,'TECHNICAL_REVIEW',0.58,0.42,ReasonFamily.EPISTEMIC_CAUTION,0.74);
  p[PRFId.INTL_MONITOR]=prf(PRFId.INTL_MONITOR,'INTERNATIONAL_MONITOR',0.59,0.48,ReasonFamily.VERIFICATION,0.69);
  p[PRFId.PUBLIC_FUTURE]=prf(PRFId.PUBLIC_FUTURE,'PUBLIC_FUTURE',0.82,0.62,ReasonFamily.FUTURE_STANDING,0.72);
  p[PRFId.LABOR_ECON]=prf(PRFId.LABOR_ECON,'LABOR_ECONOMIC',0.44,0.58,ReasonFamily.ECONOMIC_CONTINUITY,0.64,SecondOrder.CONDITIONAL_ACCEPT);
  p[PRFId.CIVIL_SOCIETY]=prf(PRFId.CIVIL_SOCIETY,'CIVIL_SOCIETY',0.64,0.66,ReasonFamily.ACCOUNTABILITY,0.70);
  p[PRFId.SKEPTICAL_SCI]=prf(PRFId.SKEPTICAL_SCI,'SKEPTICAL_SCIENTIST',0.26,0.45,ReasonFamily.SKEPTICISM,0.71,SecondOrder.CONDITIONAL_ACCEPT);
  p[PRFId.GLOBAL_SOUTH]=prf(PRFId.GLOBAL_SOUTH,'GLOBAL_SOUTH_REP',0.46,0.64,ReasonFamily.DISTRIBUTIVE_FAIRNESS,0.63,SecondOrder.CONDITIONAL_ACCEPT);
  p[PRFId.XR_RESEARCH]=prf(PRFId.XR_RESEARCH,'XR_RESEARCHER',0.84,0.40,ReasonFamily.CATASTROPHIC_PRECAUTION,0.78);
  for(const x of Object.values(p)) x.standing.affected=['PUBLIC_FUTURE','LABOR_ECONOMIC','GLOBAL_SOUTH_REP'].includes(x.role);
  return p;
}

export function createInitialState(){
  return {
    run_id:'UCP-XR-EXPERIMENT-2-CANONICAL', time_step:'T0', meta:{engine:'EXPERIMENT-2',mode:'deterministic',population_level:true,random_seed:0},
    shared_task:{...SharedTask,status:'UNFORMED',support:{},formation_time:null}, prfs:createPRFs(), coalitions:{}, coalition_history:[], authorization_history:[],
    current_authorization:null, minority_archive:[], return_ledger:[], evidence_ledger:[], action_state:{action_closed:false,authorized_policy:null},
    inquiry_state:{open:true,minority_models_preserved:true,dissent_open:true,alternative_expertise_available:true},
    metrics:{}, invariant_status:[], event_log:[],
    claim_ceiling:{plurality_selection_is_truth:false,consensus_required:false,external_validity:'not established',policy_recommendation:false,scope:'synthetic population-level governance architecture'}
  };
}
