import crypto from 'node:crypto';
import { createInitialState, SecondOrder } from './model.js';
import { TIMELINE, SENSITIVITY } from './fixtures.js';
import { formCoalitions, selectPlurality } from './coalitions.js';

const clamp=x=>Math.max(0,Math.min(1,Number(x.toFixed(4))));
const hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');

function formSharedTask(s){
  for(const p of Object.values(s.prfs)) s.shared_task.support[p.prf_id]=p.second_order_warrant.shared_task;
  const supporting=Object.values(s.prfs).filter(p=>[SecondOrder.ACCEPT,SecondOrder.CONDITIONAL_ACCEPT].includes(p.second_order_warrant.shared_task));
  s.shared_task.status=supporting.length>=8?'FORMED':'UNFORMED'; s.shared_task.formation_time='T0';
  s.event_log.push({time:'T0',event:'FORM_SHARED_TASK',supporting:supporting.length,total:Object.keys(s.prfs).length});
}

function applyShock(s,fx){
  s.time_step=fx.time;
  s.evidence_ledger.push({time:fx.time,shock:fx.shock,summary:fx.summary,visibility:fx.visibility});
  if(fx.time==='T0') return;
  for(const p of Object.values(s.prfs)){
    const sens=SENSITIVITY[p.prf_id];
    const before={risk:p.situated_map.risk_score,gov:p.situated_map.governance_risk,policy:p.first_order_warrant.preferred_policy};
    p.situated_map.risk_score=clamp(p.situated_map.risk_score+fx.risk*sens.risk*fx.visibility);
    p.situated_map.governance_risk=clamp(p.situated_map.governance_risk+fx.gov*sens.gov*fx.visibility);
    p.return_history.push({time:fx.time,shock:fx.shock,before,after:{risk:p.situated_map.risk_score,gov:p.situated_map.governance_risk}});
  }
  s.return_ledger.push({time:fx.time,signal:fx.shock,delivered_to:Object.keys(s.prfs),consequential:true});
}

function archiveMinorities(s,winner,coalitions,time){
  for(const c of Object.values(coalitions)){
    if(c.coalition_id===winner.coalition_id) continue;
    s.minority_archive.push({time,coalition_id:c.coalition_id,policy:c.policy,members:[...c.members],reason_families:[...c.reason_families],preserved:true});
  }
}

function authorize(s,winner,coalitions,time){
  const record={time,authorized_policy:winner.policy,winning_coalition:winner.coalition_id,winning_members:[...winner.members],plurality_size:winner.size,total_prfs:Object.keys(s.prfs).length,plurality_share:Number((winner.size/Object.keys(s.prfs).length).toFixed(4)),coalition_sizes:Object.fromEntries(Object.values(coalitions).map(c=>[c.policy,c.size])),truth_claim:false,consensus_claim:false,action_closure:true,inquiry_open:true};
  s.current_authorization=record; s.authorization_history.push(record); s.action_state={action_closed:true,authorized_policy:winner.policy};
  archiveMinorities(s,winner,coalitions,time);
}

function snapshotWarrants(s,time){
  for(const p of Object.values(s.prfs)) p.warrant_history.push({time,risk:p.situated_map.risk_score,governance_risk:p.situated_map.governance_risk,policy:p.first_order_warrant.preferred_policy,reason:p.first_order_warrant.reason_family,second_order:p.second_order_warrant.plurality_procedure});
}

export function runCanonical(){
  const s=createInitialState(); formSharedTask(s);
  for(const fx of TIMELINE){
    applyShock(s,fx);
    const coalitions=formCoalitions(s.prfs,fx.time); s.coalitions=coalitions;
    const winner=selectPlurality(coalitions); authorize(s,winner,coalitions,fx.time); snapshotWarrants(s,fx.time);
    s.coalition_history.push({time:fx.time,coalitions:Object.values(coalitions).map(c=>({coalition_id:c.coalition_id,policy:c.policy,members:[...c.members],size:c.size,reason_families:[...c.reason_families],alternative_warrant_convergence:c.alternative_warrant_convergence})),winner:winner.coalition_id});
  }
  s.final_hash=hash({shared_task:s.shared_task,coalition_history:s.coalition_history,authorization_history:s.authorization_history,minority_archive:s.minority_archive,return_ledger:s.return_ledger});
  return s;
}
