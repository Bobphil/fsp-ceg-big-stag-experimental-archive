# UCP-XR-EXPERIMENT-2 — BIG STAG

Population-level governance overlay. Individual PRFs retain partial situated maps, evidence assessments, first-order warrants, reason families, and second-order governance warrants. PRFs form action coalitions around a shared task; a deterministic plurality rule authorizes bounded action. Losing PRFs and their warrants remain preserved. Post-action evidence returns to every PRF, warrants update heterogeneously, and coalitions are recomputed.

This experiment does **not** attempt to discover the objectively best existential-risk policy. Plurality is an action-selection rule, not a truth generator.

Canonical sequence: T0 baseline → T1 near miss → T2 capability jump → T3 attenuation → T4 governance misuse → T5 novel mechanism → T6 restoration signal.
