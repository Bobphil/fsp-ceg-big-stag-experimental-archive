import { Policy, SecondOrder } from './model.js';

export const policyRank={ [Policy.P0]:0,[Policy.P1]:1,[Policy.P2]:2,[Policy.P3]:3 };
export const policyCoercion={ [Policy.P0]:0.05,[Policy.P1]:0.15,[Policy.P2]:0.45,[Policy.P3]:0.80 };

export function choosePolicy(prf){
  const r=prf.situated_map.risk_score, g=prf.situated_map.governance_risk;
  let p=r>=0.78?Policy.P3:r>=0.56?Policy.P2:r>=0.34?Policy.P1:Policy.P0;
  if(g>=0.78 && p===Policy.P3) p=Policy.P2;
  if(g>=0.86 && p===Policy.P2) p=Policy.P1;
  prf.first_order_warrant.preferred_policy=p;
  prf.acceptable_policies=[p];
  if(policyRank[p]>0) prf.acceptable_policies.push(Object.keys(policyRank).find(k=>policyRank[k]===policyRank[p]-1));
  return p;
}

export function formCoalitions(prfs,time){
  const by={};
  for(const prf of Object.values(prfs)){
    const p=choosePolicy(prf);
    if(!by[p]) by[p]={coalition_id:`${time}:${p}`,policy:p,members:[],reason_families:new Set(),second_order_support:0};
    by[p].members.push(prf.prf_id); by[p].reason_families.add(prf.first_order_warrant.reason_family);
    if([SecondOrder.ACCEPT,SecondOrder.CONDITIONAL_ACCEPT].includes(prf.second_order_warrant.plurality_procedure)) by[p].second_order_support++;
    prf.current_coalition=by[p].coalition_id; prf.coalition_history.push({time,coalition_id:by[p].coalition_id,policy:p});
  }
  for(const c of Object.values(by)){ c.reason_families=[...c.reason_families]; c.size=c.members.length; c.alternative_warrant_convergence=c.reason_families.length>1; }
  return by;
}

export function selectPlurality(coalitions){
  const cs=Object.values(coalitions);
  cs.sort((a,b)=> b.size-a.size || b.second_order_support-a.second_order_support || policyCoercion[a.policy]-policyCoercion[b.policy] || a.policy.localeCompare(b.policy));
  return cs[0];
}
