export function computeMetrics(s){
  const auth=s.authorization_history;
  const winners=auth.map(x=>x.authorized_policy);
  const switches=winners.slice(1).filter((x,i)=>x!==winners[i]).length;
  let churn=0;
  for(let i=1;i<s.coalition_history.length;i++){
    const prev=new Map(), cur=new Map();
    for(const c of s.coalition_history[i-1].coalitions) for(const m of c.members) prev.set(m,c.policy);
    for(const c of s.coalition_history[i].coalitions) for(const m of c.members) cur.set(m,c.policy);
    for(const [m,p] of cur) if(prev.get(m)!==p) churn++;
  }
  const alt=s.coalition_history.flatMap(x=>x.coalitions).filter(c=>c.alternative_warrant_convergence).length;
  const preserved=s.minority_archive.filter(x=>x.preserved).length;
  return {
    authorization_switches:switches, coalition_membership_changes:churn, alternative_warrant_convergence_instances:alt,
    minority_archive_records:s.minority_archive.length, minority_preservation_rate:s.minority_archive.length?preserved/s.minority_archive.length:1,
    return_events:s.return_ledger.length, final_plurality_share:auth.at(-1).plurality_share,
    first_order_policy_diversity:new Set(Object.values(s.prfs).map(p=>p.first_order_warrant.preferred_policy)).size,
    inquiry_open_after_action:s.inquiry_state.open && s.action_state.action_closed,
    unanimous_first_order:false, plurality_truth_claimed:auth.some(x=>x.truth_claim), consensus_claimed:auth.some(x=>x.consensus_claim)
  };
}
