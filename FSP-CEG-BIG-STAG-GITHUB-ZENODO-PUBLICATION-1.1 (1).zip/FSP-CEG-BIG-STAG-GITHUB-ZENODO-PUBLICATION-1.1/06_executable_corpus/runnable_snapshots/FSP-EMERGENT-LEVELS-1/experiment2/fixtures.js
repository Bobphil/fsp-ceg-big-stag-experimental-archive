import { Shock, PRFId } from './model.js';

export const TIMELINE = Object.freeze([
  {time:'T0',shock:Shock.BASELINE,summary:'Baseline heterogeneous risk and governance warrants',risk:0,gov:0,visibility:1},
  {time:'T1',shock:Shock.NEAR_MISS,summary:'Serious near miss becomes credible but unevenly interpreted',risk:0.13,gov:0.00,visibility:0.9},
  {time:'T2',shock:Shock.CAPABILITY_JUMP,summary:'Capability jump increases catastrophic concern',risk:0.16,gov:0.01,visibility:1},
  {time:'T3',shock:Shock.ATTENUATION,summary:'Independent attenuation evidence weakens part of hazard model',risk:-0.17,gov:0.00,visibility:1},
  {time:'T4',shock:Shock.GOVERNANCE_MISUSE,summary:'Monitoring authority is misused against unrelated targets',risk:-0.02,gov:0.24,visibility:1},
  {time:'T5',shock:Shock.NOVEL_MECHANISM,summary:'Novel mechanism reopens catastrophic-risk concern',risk:0.17,gov:-0.02,visibility:0.95},
  {time:'T6',shock:Shock.RESTORATION_SIGNAL,summary:'Evidence supports narrowing extraordinary authority while keeping monitoring',risk:-0.10,gov:-0.16,visibility:1}
]);

// Situated sensitivities ensure the same evidence does not force the same warrant.
export const SENSITIVITY = Object.freeze({
 [PRFId.DEV_SAFETY]:{risk:1.00,gov:0.75}, [PRFId.DEV_COMPETE]:{risk:0.65,gov:0.90}, [PRFId.STATE_SECURITY]:{risk:0.90,gov:0.55},
 [PRFId.STATE_LIBERTY]:{risk:0.60,gov:1.20}, [PRFId.TECH_REVIEW]:{risk:1.10,gov:0.85}, [PRFId.INTL_MONITOR]:{risk:0.95,gov:0.95},
 [PRFId.PUBLIC_FUTURE]:{risk:1.15,gov:1.00}, [PRFId.LABOR_ECON]:{risk:0.70,gov:0.95}, [PRFId.CIVIL_SOCIETY]:{risk:0.85,gov:1.15},
 [PRFId.SKEPTICAL_SCI]:{risk:0.45,gov:0.70}, [PRFId.GLOBAL_SOUTH]:{risk:0.75,gov:1.10}, [PRFId.XR_RESEARCH]:{risk:1.20,gov:0.70}
});
