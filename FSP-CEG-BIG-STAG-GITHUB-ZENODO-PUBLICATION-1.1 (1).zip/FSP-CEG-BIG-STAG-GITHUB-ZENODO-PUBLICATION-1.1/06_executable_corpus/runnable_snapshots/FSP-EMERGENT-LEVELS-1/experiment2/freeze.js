import fs from 'node:fs'; import crypto from 'node:crypto'; import path from 'node:path';
import { runCanonical } from './runner.js'; import { computeMetrics } from './metrics.js'; import { evaluateInvariants } from './invariants.js';
const out=process.argv[2]||'experiment2-results'; fs.mkdirSync(out,{recursive:true});
const s=runCanonical(); s.metrics=computeMetrics(s); s.invariant_status=evaluateInvariants(s);
const raw=JSON.stringify(s,null,2)+'\n'; const trace=path.join(out,'BIG-STAG-T0-T6.json'); fs.writeFileSync(trace,raw);
const sha=crypto.createHash('sha256').update(raw).digest('hex');
fs.writeFileSync(path.join(out,'FREEZE-MANIFEST.json'),JSON.stringify({experiment:'UCP-XR-EXPERIMENT-2',trace:'BIG-STAG-T0-T6.json',sha256:sha,all_invariants_pass:s.invariant_status.every(x=>x.pass)},null,2)+'\n');
console.log(JSON.stringify({sha256:sha,metrics:s.metrics,invariants:s.invariant_status},null,2));
