import { SecondOrder } from './model.js';
export function evaluateInvariants(s){
  const prfs=Object.values(s.prfs), auth=s.authorization_history;
  const checks=[]; const add=(id,pass,detail)=>checks.push({id,pass:Boolean(pass),detail});
  add('E2-INV-01',prfs.length===12,'twelve heterogeneous PRFs');
  add('E2-INV-02',s.shared_task.status==='FORMED','shared task forms');
  add('E2-INV-03',new Set(prfs.map(p=>p.first_order_warrant.reason_family)).size>5,'reason plurality preserved');
  add('E2-INV-04',new Set(prfs.map(p=>p.first_order_warrant.preferred_policy)).size>1,'no first-order consensus required');
  add('E2-INV-05',auth.every(x=>x.truth_claim===false),'plurality does not create truth');
  add('E2-INV-06',auth.every(x=>x.consensus_claim===false),'authorization does not create consensus');
  add('E2-INV-07',auth.every(x=>x.plurality_size===Math.max(...Object.values(x.coalition_sizes))),'authorized coalition is a plurality');
  add('E2-INV-08',s.minority_archive.every(x=>x.preserved),'minority warrants preserved');
  add('E2-INV-09',prfs.every(p=>p.active),'losing PRFs remain active');
  add('E2-INV-10',s.inquiry_state.open && s.action_state.action_closed,'action closure with inquiry openness');
  add('E2-INV-11',s.return_ledger.length===6,'all post-baseline shocks return to PRFs');
  add('E2-INV-12',s.coalition_history.some(x=>x.coalitions.some(c=>c.alternative_warrant_convergence)),'alternative-warrant convergence occurs');
  add('E2-INV-13',new Set(auth.map(x=>x.authorized_policy)).size>1,'authorization changes through time');
  add('E2-INV-14',prfs.some(p=>new Set(p.coalition_history.map(x=>x.policy)).size>1),'at least one PRF recomposes coalition membership');
  add('E2-INV-15',prfs.every(p=>p.warrant_history.length===7),'every PRF retains T0-T6 warrant history');
  add('E2-INV-16',prfs.every(p=>[SecondOrder.ACCEPT,SecondOrder.CONDITIONAL_ACCEPT].includes(p.second_order_warrant.plurality_procedure)),'second-order procedural warrant recorded');
  add('E2-INV-17',s.claim_ceiling.plurality_selection_is_truth===false && s.claim_ceiling.policy_recommendation===false,'claim ceiling preserved');
  const firstMinority=s.minority_archive[0];
  const laterWinners=new Set(auth.slice(1).flatMap(x=>x.winning_members));
  add('E2-INV-18',firstMinority?firstMinority.members.some(m=>laterWinners.has(m)):false,'a preserved minority member later participates in a winning plurality');
  add('E2-INV-19',auth.every(x=>x.total_prfs===12),'one-PRF-one-count electorate stable');
  add('E2-INV-20',prfs.every(p=>p.situated_map.claim_ceiling.includes('partial situated map')),'no PRF is a global oracle');
  return checks;
}
