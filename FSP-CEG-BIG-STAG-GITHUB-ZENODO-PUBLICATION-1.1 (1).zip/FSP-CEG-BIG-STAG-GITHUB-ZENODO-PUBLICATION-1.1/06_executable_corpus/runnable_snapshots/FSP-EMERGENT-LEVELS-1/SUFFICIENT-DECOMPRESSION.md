# Sufficient Decompression Rule

Stop local decompression and recompose when all currently action-sensitive requirements are satisfied:
1. trigger addressed;
2. trigger-relevant distinctions recovered;
3. affected standing included;
4. authorization can be reassessed;
5. zero currently action-sensitive omitted distinctions remain open;
6. residual uncertainty recorded;
7. future REOPEN route preserved.

Total recovery is not required.

If a trigger-relevant distinction is irrecoverable, local recursion stops by escalation to meta-REOPEN when such a route exists. Absence of such a route is a corrigibility failure, not a reason for infinite local review.
