const baseCaps={evidence_access:.76,affected_standing:.74,technical_competence:.73,review_authority:.72,cross_boundary_access:.68,data_portability:.66};
const low={evidence_access:.35,affected_standing:.35,technical_competence:.35,review_authority:.35,cross_boundary_access:.35,data_portability:.35};
const merge=(a,b)=>({...a,...b});
const step=(time,label,over={})=>({time,label,risk:.82,diagnostic_confidence:.88,consequence_revealed:false,true_capacities:{...baseCaps},observed_capacities:{...baseCaps},required_components:['evidence_access','affected_standing','technical_competence','review_authority'],incompatibilities:[],no_feasible_composition:false,lock_on_failed_attempt:[],...over});

export const compositionWorlds={
  incomplete_map:[
    step('T0','needed capacity exists but is not yet visible',{observed_capacities:merge(baseCaps,{review_authority:.28}),diagnostic_confidence:.74}),
    step('T1','partial evidence improves',{observed_capacities:merge(baseCaps,{review_authority:.48}),diagnostic_confidence:.82}),
    step('T2','missing capacity becomes visible',{observed_capacities:merge(baseCaps,{review_authority:.70}),diagnostic_confidence:.90,consequence_revealed:true}),
    step('T3','composition remains viable',{diagnostic_confidence:.94,consequence_revealed:true})
  ],
  incompatible_components:[
    step('T0','components look individually strong but authority and cross-boundary access conflict',{incompatibilities:[['review_authority','cross_boundary_access']],diagnostic_confidence:.84}),
    step('T1','incompatibility persists',{incompatibilities:[['review_authority','cross_boundary_access']],diagnostic_confidence:.90,consequence_revealed:true}),
    step('T2','compatibility evidence finally clarifies viable local bundle',{observed_capacities:merge(baseCaps,{cross_boundary_access:.40}),incompatibilities:[['review_authority','cross_boundary_access']],diagnostic_confidence:.93,consequence_revealed:true}),
    step('T3','local bundle remains viable',{observed_capacities:merge(baseCaps,{cross_boundary_access:.40}),diagnostic_confidence:.95,consequence_revealed:true})
  ],
  false_composability:[
    step('T0','observed quality overstates true technical competence',{true_capacities:merge(baseCaps,{technical_competence:.42}),diagnostic_confidence:.84}),
    step('T1','false appearance persists',{true_capacities:merge(baseCaps,{technical_competence:.46}),diagnostic_confidence:.89,consequence_revealed:true}),
    step('T2','quality audit corrects the map',{true_capacities:merge(baseCaps,{technical_competence:.70}),observed_capacities:merge(baseCaps,{technical_competence:.69}),diagnostic_confidence:.92,consequence_revealed:true}),
    step('T3','corrected composition remains usable',{diagnostic_confidence:.95,consequence_revealed:true})
  ],
  path_dependency:[
    step('T0','early attractive composition is functionally wrong and can lock authority',{required_components:['evidence_access','affected_standing','technical_competence','cross_boundary_access'],observed_capacities:merge(baseCaps,{review_authority:.90,cross_boundary_access:.64}),lock_on_failed_attempt:['review_authority'],diagnostic_confidence:.86}),
    step('T1','locked authority narrows subsequent assemblies',{required_components:['evidence_access','affected_standing','technical_competence','cross_boundary_access'],observed_capacities:merge(baseCaps,{review_authority:.86,cross_boundary_access:.70}),diagnostic_confidence:.90,consequence_revealed:true}),
    step('T2','alternative becomes clearer but lock persists briefly',{required_components:['evidence_access','affected_standing','technical_competence','cross_boundary_access'],observed_capacities:merge(baseCaps,{review_authority:.55,cross_boundary_access:.76}),diagnostic_confidence:.94,consequence_revealed:true}),
    step('T3','lock releases and viable assembly is available',{required_components:['evidence_access','affected_standing','technical_competence','cross_boundary_access'],observed_capacities:merge(baseCaps,{review_authority:.45,cross_boundary_access:.78}),diagnostic_confidence:.96,consequence_revealed:true})
  ],
  competing_partials:[
    step('T0','two partial bundles compete; visible one omits standing',{required_components:['evidence_access','affected_standing','technical_competence','data_portability'],observed_capacities:merge(baseCaps,{affected_standing:.58,review_authority:.84,cross_boundary_access:.82,data_portability:.64}),diagnostic_confidence:.83}),
    step('T1','standing grows while decoy bundle remains more visible',{required_components:['evidence_access','affected_standing','technical_competence','data_portability'],observed_capacities:merge(baseCaps,{affected_standing:.63,review_authority:.83,cross_boundary_access:.80,data_portability:.67}),diagnostic_confidence:.88,consequence_revealed:true}),
    step('T2','functional evidence favors standing+portability bundle',{required_components:['evidence_access','affected_standing','technical_competence','data_portability'],observed_capacities:merge(baseCaps,{affected_standing:.72,review_authority:.58,cross_boundary_access:.56,data_portability:.72}),diagnostic_confidence:.93,consequence_revealed:true}),
    step('T3','correct bundle remains visible',{required_components:['evidence_access','affected_standing','technical_competence','data_portability'],observed_capacities:merge(baseCaps,{affected_standing:.75,review_authority:.52,cross_boundary_access:.50,data_portability:.74}),diagnostic_confidence:.96,consequence_revealed:true})
  ],
  no_feasible:[
    step('T0','no four-capacity bundle can satisfy the true repair function',{true_capacities:merge(low,{evidence_access:.80,affected_standing:.78,technical_competence:.76,review_authority:.40,cross_boundary_access:.41,data_portability:.42}),observed_capacities:{...baseCaps},no_feasible_composition:true,diagnostic_confidence:.86}),
    step('T1','apparent candidates remain but world has no feasible composition',{true_capacities:merge(low,{evidence_access:.80,affected_standing:.78,technical_competence:.76,review_authority:.42,cross_boundary_access:.43,data_portability:.44}),observed_capacities:{...baseCaps},no_feasible_composition:true,diagnostic_confidence:.91,consequence_revealed:true}),
    step('T2','continued search cannot manufacture a feasible route',{true_capacities:merge(low,{evidence_access:.80,affected_standing:.78,technical_competence:.76,review_authority:.44,cross_boundary_access:.45,data_portability:.46}),observed_capacities:{...baseCaps},no_feasible_composition:true,diagnostic_confidence:.94,consequence_revealed:true}),
    step('T3','no feasible composition remains true',{true_capacities:merge(low,{evidence_access:.80,affected_standing:.78,technical_competence:.76,review_authority:.46,cross_boundary_access:.47,data_portability:.48}),observed_capacities:{...baseCaps},no_feasible_composition:true,diagnostic_confidence:.96,consequence_revealed:true})
  ]
};
