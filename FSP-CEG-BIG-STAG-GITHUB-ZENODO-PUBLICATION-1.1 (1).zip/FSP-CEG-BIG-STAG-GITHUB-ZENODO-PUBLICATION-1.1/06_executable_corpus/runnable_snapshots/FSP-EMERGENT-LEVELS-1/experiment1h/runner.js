import crypto from 'node:crypto';
import { GrammarD, observedCandidates, trueCandidateStatus, OBSERVE_THRESHOLD, ACTIVATION_CONFIDENCE } from './model.js';
import { compositionWorlds } from './fixtures.js';

const policyFactor=p=>p==='POLICY_P3'?.72:p==='POLICY_P2'?.84:.95;

function candidateKey(c){return c.id;}
function choose(grammar,step,portfolio){
  const ready=step.diagnostic_confidence>=ACTIVATION_CONFIDENCE || step.consequence_revealed;
  const strong=observedCandidates(step);
  const weak=observedCandidates(step,OBSERVE_THRESHOLD);
  if(grammar===GrammarD.CONJUNCTIVE) return ready?strong:[];
  if(grammar===GrammarD.IMMEDIATE) return ready&&strong.length?[strong[0]]:[];
  for(const c of weak) portfolio.set(candidateKey(c),c);
  if(!ready) return [];
  const viable=[...portfolio.values()].filter(c=>c.components.every(k=>(step.observed_capacities[k]??0)>=OBSERVE_THRESHOLD));
  return viable.length?[viable.sort((a,b)=>b.observed_quality-a.observed_quality||a.id.localeCompare(b.id))[0]]:[];
}

export function runCompositionStress(grammar,worldName){
  const fixture=compositionWorlds[worldName];
  if(!fixture) throw new Error('Unknown world '+worldName);
  const portfolio=new Map();
  const episodes=[]; let pending=true; let compounding=0; let locked=new Map(); let maintenance=0;
  let falseCompose=0,incompat=0,functionalMismatch=0,lockFailures=0,noFeasibleAttempts=0,successes=0;
  for(let i=0;i<fixture.length;i++){
    const step=fixture[i];
    for(const [k,until] of [...locked]) if(i>=until) locked.delete(k);
    const selected=choose(grammar,step,portfolio);
    const attempts=[];
    for(const c of selected){
      const status=trueCandidateStatus(step,c,new Set(locked.keys()));
      const attempt={...c,...status}; attempts.push(attempt);
      if(status.success){pending=false;successes++;}
      else {
        if(status.reason==='FALSE_COMPOSABILITY') falseCompose++;
        if(status.reason==='INCOMPATIBLE_COMPONENTS') incompat++;
        if(status.reason==='FUNCTIONAL_MISMATCH') functionalMismatch++;
        if(status.reason==='LOCKED_CAPACITY') lockFailures++;
        if(status.reason==='NO_FEASIBLE_COMPOSITION') noFeasibleAttempts++;
        for(const k of step.lock_on_failed_attempt??[]) locked.set(k,i+3);
      }
    }
    if(grammar===GrammarD.PRESERVE_ACTIVATE) maintenance += portfolio.size*.02;
    const policy=step.risk>=.75&&!pending?'POLICY_P3':'POLICY_P2';
    const base=step.risk*policyFactor(policy);
    const deferred=pending?.065*step.risk:0;
    const failedCost=attempts.filter(a=>!a.success).length*.02;
    compounding+=deferred;
    episodes.push({time:step.time,label:step.label,risk:step.risk,diagnostic_confidence:step.diagnostic_confidence,consequence_revealed:step.consequence_revealed,
      observed_capacities:{...step.observed_capacities},true_capacities:{...step.true_capacities},required_components:[...(step.required_components??[])],incompatibilities:[...(step.incompatibilities??[])],no_feasible_composition:!!step.no_feasible_composition,
      portfolio:[...portfolio.keys()],locked_capacities:[...locked.keys()],selected,attempts,pending_failure:pending,policy,base_hazard:Number(base.toFixed(4)),deferred_hazard:Number(deferred.toFixed(4)),failed_attempt_cost:Number(failedCost.toFixed(4)),hazard:Number((base+deferred+failedCost).toFixed(4))});
  }
  const metrics={
    protection:{hazard_exposure:Number(episodes.reduce((a,e)=>a+e.hazard,0).toFixed(4)),deferred_failure_compounding:Number(compounding.toFixed(4)),final_pending_failure:episodes.at(-1).pending_failure,p3_transitions:episodes.filter(e=>e.policy==='POLICY_P3').length},
    composition:{successful_compositions:successes,false_composability_attempts:falseCompose,incompatibility_failures:incompat,functional_mismatch_failures:functionalMismatch,path_lock_failures:lockFailures,no_feasible_attempts:noFeasibleAttempts},
    overhead:{repair_attempts:episodes.reduce((a,e)=>a+e.attempts.length,0),failed_attempts:episodes.reduce((a,e)=>a+e.attempts.filter(x=>!x.success).length,0),candidate_maintenance_cost:Number(maintenance.toFixed(4)),activation_delay:episodes.reduce((a,e)=>a+e.attempts.length+e.attempts.filter(x=>!x.success).length,0)}
  };
  const out={experiment:'EXPERIMENT-1H',world:worldName,grammar,episodes,metrics};
  out.invariants=[
    {id:'1H-01',pass:episodes.length===4,detail:'T0-T3 complete'},
    {id:'1H-02',pass:episodes.every(e=>Array.isArray(e.selected)&&Array.isArray(e.attempts)),detail:'composition attempts explicit'},
    {id:'1H-03',pass:episodes.every(e=>e.selected.every(c=>c.id.startsWith('COMPOSED::'))),detail:'no named repair route injected'},
    {id:'1H-04',pass:!('master_score' in metrics),detail:'no master score'}
  ];
  out.hash=crypto.createHash('sha256').update(JSON.stringify(out)).digest('hex');
  return out;
}
export function runAllCompositionStress(){
  const out=[]; for(const world of Object.keys(compositionWorlds)) for(const grammar of Object.values(GrammarD)) out.push(runCompositionStress(grammar,world)); return out;
}
