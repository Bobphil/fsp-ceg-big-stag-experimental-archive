import fs from 'node:fs'; import path from 'node:path'; import crypto from 'node:crypto';
import { runAllCompositionStress } from './runner.js';
const outDir=process.argv[2]||'experiment1h-results'; fs.mkdirSync(outDir,{recursive:true});
const runs=runAllCompositionStress(); const manifest=[];
for(const r of runs){const name=`${r.world}__${r.grammar}.json`; const p=path.join(outDir,name); fs.writeFileSync(p,JSON.stringify(r,null,2)+'\n'); const sha=crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex'); manifest.push({world:r.world,grammar:r.grammar,file:name,sha256:sha});}
fs.writeFileSync(path.join(outDir,'FREEZE-MANIFEST.json'),JSON.stringify({experiment:'EXPERIMENT-1H',created_at:new Date().toISOString(),runs:manifest},null,2)+'\n');
console.log(JSON.stringify(manifest,null,2));
