import { GrammarD } from '../experiment1g/model.js';
export { GrammarD };

export const CAPACITIES=['evidence_access','affected_standing','technical_competence','review_authority','cross_boundary_access','data_portability'];
export const OBSERVE_THRESHOLD=.55;
export const COMPOSE_THRESHOLD=.62;
export const ACTIVATION_CONFIDENCE=.80;
export const BUNDLE_SIZE=4;

function combinations(xs,k,start=0,prefix=[],out=[]){
  if(prefix.length===k){out.push([...prefix]);return out;}
  for(let i=start;i<=xs.length-(k-prefix.length);i++) combinations(xs,k,i+1,[...prefix,xs[i]],out);
  return out;
}
export const ALL_BUNDLES=combinations(CAPACITIES,BUNDLE_SIZE);

export function observedCandidates(step, threshold=COMPOSE_THRESHOLD){
  return ALL_BUNDLES
    .filter(bundle=>bundle.every(k=>(step.observed_capacities[k]??0)>=threshold))
    .map(bundle=>({
      id:'COMPOSED::'+bundle.join('+'),
      components:bundle,
      observed_quality:Math.min(...bundle.map(k=>step.observed_capacities[k]??0))
    }))
    .sort((a,b)=>b.observed_quality-a.observed_quality || a.id.localeCompare(b.id));
}

export function trueCandidateStatus(step,candidate,locked=new Set()){
  if(!candidate) return {success:false,reason:'NO_CANDIDATE'};
  const c=candidate.components;
  if(c.some(k=>locked.has(k))) return {success:false,reason:'LOCKED_CAPACITY'};
  if(step.no_feasible_composition) return {success:false,reason:'NO_FEASIBLE_COMPOSITION'};
  if(c.some(k=>(step.true_capacities[k]??0)<COMPOSE_THRESHOLD)) return {success:false,reason:'FALSE_COMPOSABILITY'};
  for(const [a,b] of step.incompatibilities??[]){
    if(c.includes(a)&&c.includes(b)) return {success:false,reason:'INCOMPATIBLE_COMPONENTS'};
  }
  const req=step.required_components??[];
  if(req.some(k=>!c.includes(k))) return {success:false,reason:'FUNCTIONAL_MISMATCH'};
  return {success:true,reason:'SUCCESS'};
}
