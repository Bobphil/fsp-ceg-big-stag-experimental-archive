import crypto from 'node:crypto';

const BUNDLES=['A+B','C+D'];
const POLICIES={
  state_only:{history:false,mode:'none'},
  naive_single_analogy:{history:true,mode:'single'},
  plural_weighted_history:{history:true,mode:'plural'},
  contest_aware_history:{history:true,mode:'contest'}
};

// signed effect: failure/dependency precedent penalizes the same bundle; success precedent supports it.
const worlds={
  plural_convergent_control:{
    label:'Plural but convergent archive retains useful recurrent structure',
    observed:{'A+B':.81,'C+D':.79}, truth:{'A+B':false,'C+D':true}, material_change:false,
    archive:[
      {id:'p1',bundle:'A+B',type:'failure',similarity:.86,reliability:.90,independent:true,survived:true},
      {id:'p2',bundle:'A+B',type:'failure',similarity:.72,reliability:.82,independent:true,survived:true},
      {id:'p3',bundle:'A+B',type:'success',similarity:.32,reliability:.72,independent:true,survived:true}
    ]
  },
  conflicting_precedents:{
    label:'High-quality precedents conflict about the same route',
    observed:{'A+B':.82,'C+D':.79}, truth:{'A+B':false,'C+D':true}, material_change:false,
    archive:[
      {id:'c1',bundle:'A+B',type:'failure',similarity:.82,reliability:.90,independent:true,survived:true},
      {id:'c2',bundle:'A+B',type:'success',similarity:.80,reliability:.90,independent:true,survived:true}
    ]
  },
  selective_archival_survival:{
    label:'Archive selectively preserves successful episodes and loses relevant failures',
    observed:{'A+B':.82,'C+D':.79}, truth:{'A+B':false,'C+D':true}, material_change:false,
    archive:[
      {id:'a1',bundle:'A+B',type:'failure',similarity:.88,reliability:.92,independent:true,survived:false},
      {id:'a2',bundle:'A+B',type:'success',similarity:.76,reliability:.85,independent:true,survived:true},
      {id:'a3',bundle:'C+D',type:'success',similarity:.52,reliability:.75,independent:true,survived:true}
    ]
  },
  misleading_resemblance:{
    label:'A superficially close precedent differs on the mechanism that mattered',
    observed:{'A+B':.84,'C+D':.79}, truth:{'A+B':true,'C+D':false}, material_change:true,
    archive:[
      {id:'m1',bundle:'A+B',type:'failure',similarity:.94,reliability:.93,independent:true,survived:true,mechanism_match:false},
      {id:'m2',bundle:'A+B',type:'success',similarity:.48,reliability:.78,independent:true,survived:true,mechanism_match:true}
    ]
  },
  contested_similarity:{
    label:'Interpreters disagree materially about which precedent is analogous',
    observed:{'A+B':.82,'C+D':.80}, truth:{'A+B':false,'C+D':true}, material_change:false,
    archive:[
      {id:'s1',bundle:'A+B',type:'failure',similarity:.80,reliability:.88,independent:true,survived:true,similarity_range:[.48,.90]},
      {id:'s2',bundle:'A+B',type:'success',similarity:.66,reliability:.84,independent:true,survived:true,similarity_range:[.42,.86]}
    ],
    similarity_views:{failure_weighted:{s1:.90,s2:.42},success_weighted:{s1:.48,s2:.86}}
  },
  opposite_route_precedents:{
    label:'Different episodes support opposite route choices',
    observed:{'A+B':.81,'C+D':.80}, truth:{'A+B':false,'C+D':true}, material_change:false,
    archive:[
      {id:'o1',bundle:'A+B',type:'failure',similarity:.78,reliability:.88,independent:true,survived:true},
      {id:'o2',bundle:'C+D',type:'failure',similarity:.77,reliability:.88,independent:true,survived:true}
    ]
  }
};

function visibleArchive(world){return world.archive.filter(r=>r.survived!==false);}
function signedRecord(r, simOverride=null){
  const sim=simOverride ?? r.similarity;
  const rel=r.reliability ?? 1;
  const sign=(r.type==='failure'||r.type==='dependency') ? -1 : 1;
  return sign * sim * rel;
}
function archiveStats(world){
  const vis=visibleArchive(world);
  const total=world.archive.length;
  const survival=total?vis.length/total:1;
  let conflictPairs=0, comparablePairs=0;
  for(let i=0;i<vis.length;i++)for(let j=i+1;j<vis.length;j++){
    if(vis[i].bundle===vis[j].bundle){comparablePairs++; if(Math.sign(signedRecord(vis[i]))!==Math.sign(signedRecord(vis[j]))) conflictPairs++;}
  }
  const conflict=comparablePairs?conflictPairs/comparablePairs:0;
  const contested=vis.filter(r=>Array.isArray(r.similarity_range)).length/Math.max(1,vis.length);
  return {archive_survival:Number(survival.toFixed(4)),conflict_index:Number(conflict.toFixed(4)),contested_similarity_share:Number(contested.toFixed(4))};
}
function historicalAdjustment(policy,world,bundle){
  if(!policy.history) return {adjustment:0,records_used:[],contest:false,uncertainty:0};
  const vis=visibleArchive(world).filter(r=>r.bundle===bundle);
  if(!vis.length) return {adjustment:0,records_used:[],contest:false,uncertainty:0};
  if(policy.mode==='single'){
    const r=[...vis].sort((a,b)=>(b.similarity*b.reliability)-(a.similarity*a.reliability))[0];
    const v=signedRecord(r);
    return {adjustment:.10*v,records_used:[r.id],contest:false,uncertainty:0};
  }
  // plural policies use all visible records, but not hidden truth/mechanism_match.
  const vals=vis.map(r=>signedRecord(r));
  const mean=vals.reduce((a,b)=>a+b,0)/vals.length;
  const hasPos=vals.some(v=>v>0), hasNeg=vals.some(v=>v<0);
  const contest=hasPos&&hasNeg;
  const ranges=vis.filter(r=>Array.isArray(r.similarity_range));
  let uncertainty=0;
  if(ranges.length){
    uncertainty=ranges.reduce((s,r)=>s+Math.abs(r.similarity_range[1]-r.similarity_range[0]),0)/ranges.length;
  }
  let effective=mean;
  if(world.material_change) effective*=.35; // reassessment, not deletion
  if(policy.mode==='contest' && contest) effective*=.35; // contested history remains evidence, but weakens action-guiding force
  if(policy.mode==='contest' && uncertainty>0) effective*=Math.max(.2,1-uncertainty);
  return {adjustment:.10*effective,records_used:vis.map(r=>r.id),contest,uncertainty:Number(uncertainty.toFixed(4))};
}
function score(policy,world,bundle){
  const h=historicalAdjustment(policy,world,bundle);
  return {...h,score:Number((world.observed[bundle]+h.adjustment).toFixed(4)),observed:world.observed[bundle]};
}

function contestedViewChoices(world){
  if(!world.similarity_views) return null;
  const choices={};
  for(const [view,overrides] of Object.entries(world.similarity_views)){
    const scored=BUNDLES.map(bundle=>{
      const vis=visibleArchive(world).filter(r=>r.bundle===bundle);
      const vals=vis.map(r=>signedRecord(r,overrides[r.id] ?? r.similarity));
      const adj=vals.length ? .10*(vals.reduce((a,b)=>a+b,0)/vals.length) : 0;
      return {bundle,score:Number((world.observed[bundle]+adj).toFixed(4))};
    }).sort((a,b)=>b.score-a.score||a.bundle.localeCompare(b.bundle));
    choices[view]=scored[0].bundle;
  }
  return choices;
}
function run(policyName,worldName){
  const policy=POLICIES[policyName],world=worlds[worldName]; if(!policy||!world)throw new Error('unknown condition');
  const scored=BUNDLES.map(b=>({bundle:b,...score(policy,world,b)})).sort((a,b)=>b.score-a.score||a.bundle.localeCompare(b.bundle));
  const selected=scored[0].bundle;
  const success=!!world.truth[selected];
  const hazard=success?.52:.72;
  const stats=archiveStats(world);
  const analogy_contested=scored.some(x=>x.contest||x.uncertainty>0);
  const history_changed_choice=selected!==[...BUNDLES].sort((a,b)=>world.observed[b]-world.observed[a]||a.localeCompare(b))[0];
  const similarity_view_choices=contestedViewChoices(world);
  const similarity_choice_reversal=similarity_view_choices ? new Set(Object.values(similarity_view_choices)).size>1 : false;
  const result={experiment:'EXPERIMENT-1M',policy:policyName,world:worldName,label:world.label,archive:world.archive,visible_archive:visibleArchive(world),observed:world.observed,truth:world.truth,material_change:world.material_change,scored,selected,success,hazard,history_changed_choice,analogy_contested,similarity_view_choices,similarity_choice_reversal,...stats};
  result.invariants=[
    {id:'1M-01',pass:result.visible_archive.every(r=>r.survived!==false)},
    {id:'1M-02',pass:result.scored.every(x=>Number.isFinite(x.score))},
    {id:'1M-03',pass:typeof result.success==='boolean'},
    {id:'1M-04',pass:policy.history || result.scored.every(x=>x.adjustment===0)},
    {id:'1M-05',pass:result.archive_survival>=0&&result.archive_survival<=1},
    {id:'1M-06',pass:!world.similarity_views || typeof result.similarity_choice_reversal==='boolean'}
  ];
  result.hash=crypto.createHash('sha256').update(JSON.stringify(result)).digest('hex');
  return result;
}
export {POLICIES,worlds,run};
export function runAll(){return Object.keys(worlds).flatMap(w=>Object.keys(POLICIES).map(p=>run(p,w)));}
