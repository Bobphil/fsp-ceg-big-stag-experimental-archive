import fs from 'node:fs'; import path from 'node:path'; import crypto from 'node:crypto';
import { runAllReopenable } from './runner.js';
const outDir=path.resolve('../frozen-traces'); fs.rmSync(outDir,{recursive:true,force:true}); fs.mkdirSync(outDir,{recursive:true});
const rows=[]; for(const r of runAllReopenable()){
 const name=`${r.world}__${r.memory_policy}.json`; const p=path.join(outDir,name); const text=JSON.stringify(r,null,2)+'\n'; fs.writeFileSync(p,text); const sha=crypto.createHash('sha256').update(text).digest('hex');
 rows.push({world:r.world,policy:r.memory_policy,file:name,sha256:sha,hash:r.hash});
}
const manifest={experiment:'EXPERIMENT-1J',trace_count:rows.length,created_from:'EXPERIMENT-1I exact package',traces:rows}; fs.writeFileSync(path.join(outDir,'FREEZE-MANIFEST.json'),JSON.stringify(manifest,null,2)+'\n');
console.log(JSON.stringify(manifest,null,2));
