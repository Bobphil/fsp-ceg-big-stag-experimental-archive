import { CAPACITIES, OBSERVE_THRESHOLD, COMPOSE_THRESHOLD, ACTIVATION_CONFIDENCE, BUNDLE_SIZE, ALL_BUNDLES, trueCandidateStatus } from '../experiment1h/model.js';
export { CAPACITIES, OBSERVE_THRESHOLD, COMPOSE_THRESHOLD, ACTIVATION_CONFIDENCE, BUNDLE_SIZE, ALL_BUNDLES, trueCandidateStatus };

export const HISTORICAL_FIELDS=['compatibility_provenance','dependency_history','candidate_failure_history'];
export const STATE_FIELDS=['reversibility_history','capacity_condition_history'];

export const MEMORY_POLICIES={
  sticky_full:{historical:'sticky',reopen:[],expiry:null,state:true},
  cautionary:{historical:'caution',reopen:[],expiry:null,state:true},
  reopen_evidence:{historical:'caution',reopen:['evidence'],expiry:null,state:true},
  reopen_dependency:{historical:'caution',reopen:['dependency'],expiry:null,state:true},
  reopen_any:{historical:'caution',reopen:['evidence','dependency'],expiry:null,state:true},
  reopen_any_expiry2:{historical:'caution',reopen:['evidence','dependency'],expiry:2,state:true},
  expiry2_only:{historical:'caution',reopen:[],expiry:2,state:true},
  state_sensitive_only:{historical:'none',reopen:[],expiry:null,state:true}
};

export function policy(name){const p=MEMORY_POLICIES[name]; if(!p) throw new Error('Unknown memory policy '+name); return p;}
