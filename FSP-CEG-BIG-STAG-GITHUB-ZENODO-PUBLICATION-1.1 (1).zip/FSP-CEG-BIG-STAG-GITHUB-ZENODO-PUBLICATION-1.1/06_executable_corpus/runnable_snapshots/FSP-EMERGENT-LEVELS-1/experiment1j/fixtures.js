import { memoryWorlds } from '../experiment1i/fixtures.js';
const clone=x=>JSON.parse(JSON.stringify(x));

export const reopenWorlds={};
for(const [name,steps0] of Object.entries(memoryWorlds)){
  reopenWorlds[name]=steps0.map((s,i)=>{
    const x=clone(s);
    x.reopen_event_id=`${name}:${x.time}`;
    x.material_evidence_change=false;
    x.material_dependency_change=false;
    if(i>0){
      const prev=steps0[i-1];
      for(const k of Object.keys(x.observed_capacities)){
        if(Math.abs((x.observed_capacities[k]??0)-(prev.observed_capacities[k]??0))>=.08) x.material_evidence_change=true;
        if(Math.abs((x.true_capacities[k]??0)-(prev.true_capacities[k]??0))>=.08) x.material_evidence_change=true;
      }
      const keys=new Set([...Object.keys(x.dependency_provenance??{}),...Object.keys(prev.dependency_provenance??{})]);
      for(const k of keys) if((x.dependency_provenance?.[k]??null)!==(prev.dependency_provenance?.[k]??null)) x.material_dependency_change=true;
    }
    // Competing-partials gains a real dependency-structure change at T2: the previously
    // coupled institutional pair is separated by an externalized access pathway.
    if(name==='competing_partials' && i>=2){
      x.dependency_provenance={...x.dependency_provenance,cross_boundary_access:'EXTERNAL_Y'};
      x.material_dependency_change=true;
    }
    return x;
  });
}
