import crypto from 'node:crypto';
import { reopenWorlds } from './fixtures.js';
import { MEMORY_POLICIES, policy, ALL_BUNDLES, OBSERVE_THRESHOLD, ACTIVATION_CONFIDENCE, trueCandidateStatus } from './model.js';

const policyFactor=p=>p==='POLICY_P3'?.72:p==='POLICY_P2'?.84:.95;
const mkCandidate=(bundle,step)=>({id:'COMPOSED::'+bundle.join('+'),components:[...bundle],observed_quality:Math.min(...bundle.map(k=>step.observed_capacities[k]??0))});
const observed=(step,threshold=OBSERVE_THRESHOLD)=>ALL_BUNDLES.filter(b=>b.every(k=>(step.observed_capacities[k]??0)>=threshold)).map(b=>mkCandidate(b,step)).sort((a,b)=>b.observed_quality-a.observed_quality||a.id.localeCompare(b.id));
const pairKey=(a,b)=>[a,b].sort().join('::');

function createMemory(){return {incompat:new Map(),deps:new Map(),failed:new Map(),lockSensitive:new Set(),degraded:new Set(),lastObserved:{},events:[]};}
function addRecord(map,key,record){map.set(key,{...record});}
function age(rec,i){return i-rec.at;}
function materialEvidenceForCandidate(step,rec,c){
  if(!step.material_evidence_change) return false;
  if(!rec.snapshot) return true;
  return c.components.some(k=>Math.abs((step.observed_capacities[k]??0)-(rec.snapshot[k]??0))>=.08 || Math.abs((step.true_capacities[k]??0)-(rec.trueSnapshot?.[k]??step.true_capacities[k]??0))>=.08);
}
function shouldReopen(step,rec,c,p,i){
  if(p.expiry!=null && age(rec,i)>=p.expiry) return 'EXPIRY';
  if(p.reopen.includes('evidence') && materialEvidenceForCandidate(step,rec,c)) return 'EVIDENCE_CHANGE';
  if(p.reopen.includes('dependency') && step.material_dependency_change) return 'DEPENDENCY_CHANGE';
  return null;
}
function historicalPenalty(step,c,memory,p,i,reopenEvents){
  if(p.historical==='none') return {blocked:false,penalty:0,reasons:[]};
  let penalty=0; const reasons=[];
  // Compatibility records are keyed to pairs.
  for(let a=0;a<c.components.length;a++) for(let b=a+1;b<c.components.length;b++){
    const k=pairKey(c.components[a],c.components[b]); const rec=memory.incompat.get(k); if(!rec) continue;
    const why=shouldReopen(step,rec,c,p,i); if(why){memory.incompat.delete(k); reopenEvents.push({field:'compatibility',key:k,reason:why}); continue;}
    if(p.historical==='sticky') return {blocked:true,penalty:999,reasons:['STICKY_COMPATIBILITY']};
    penalty+=.035; reasons.push('CAUTION_COMPATIBILITY');
  }
  // Dependency records apply only when the candidate still exhibits the risky dependency.
  const counts={}; for(const k of c.components){const g=step.dependency_provenance?.[k]; if(g) counts[g]=(counts[g]??0)+1;}
  for(const [g,n] of Object.entries(counts)) if(n>=2){const rec=memory.deps.get(g); if(rec){const why=shouldReopen(step,rec,c,p,i); if(why){memory.deps.delete(g); reopenEvents.push({field:'dependency',key:g,reason:why});} else if(p.historical==='sticky') return {blocked:true,penalty:999,reasons:['STICKY_DEPENDENCY']}; else {penalty+=.04; reasons.push('CAUTION_DEPENDENCY');}}}
  const f=memory.failed.get(c.id); if(f){const why=shouldReopen(step,f,c,p,i); if(why){memory.failed.delete(c.id); reopenEvents.push({field:'failure',key:c.id,reason:why});} else if(p.historical==='sticky' && (step.observed_capacities[f.weakest]??0)<f.qualityAtFailure+.08) return {blocked:true,penalty:999,reasons:['STICKY_FAILURE']}; else {penalty+=.045; reasons.push('CAUTION_FAILURE');}}
  return {blocked:false,penalty,reasons};
}
function updateCondition(step,memory){for(const [k,v] of Object.entries(step.observed_capacities)){const prev=memory.lastObserved[k]; if(prev!=null&&prev-v>=.12) memory.degraded.add(k); if(prev!=null&&v-prev>=.12) memory.degraded.delete(k); memory.lastObserved[k]=v;}}
function choose(step,portfolio,memory,p,locked,i){
  for(const c of observed(step)) portfolio.set(c.id,c);
  const ready=step.diagnostic_confidence>=ACTIVATION_CONFIDENCE||step.consequence_revealed;
  if(!ready) return {selected:[],filtered:[],reopened:[]};
  const candidates=[...portfolio.values()].filter(c=>c.components.every(k=>(step.observed_capacities[k]??0)>=OBSERVE_THRESHOLD)).map(c=>mkCandidate(c.components,step));
  const filtered=[], reopened=[], scored=[];
  for(const c of candidates){
    if(p.state && c.components.some(k=>locked.has(k)||memory.degraded.has(k)||memory.lockSensitive.has(k))){filtered.push({id:c.id,reason:'STATE_MEMORY'}); continue;}
    const h=historicalPenalty(step,c,memory,p,i,reopened); if(h.blocked){filtered.push({id:c.id,reason:h.reasons[0]}); continue;}
    scored.push({...c,memory_penalty:h.penalty,memory_reasons:h.reasons,adjusted_quality:c.observed_quality-h.penalty});
  }
  scored.sort((a,b)=>b.adjusted_quality-a.adjusted_quality||b.observed_quality-a.observed_quality||a.id.localeCompare(b.id));
  return {selected:scored.slice(0,1),filtered,reopened};
}
function learn(step,c,status,memory,p,i){
  const snap={...step.observed_capacities}, trueSnap={...step.true_capacities};
  if(p.historical==='none'){
    if((step.lock_on_failed_attempt??[]).length) for(const k of step.lock_on_failed_attempt) memory.lockSensitive.add(k);
    return;
  }
  if(status.reason==='INCOMPATIBLE_COMPONENTS') for(const [a,b] of step.incompatibilities??[]) if(c.components.includes(a)&&c.components.includes(b)) addRecord(memory.incompat,pairKey(a,b),{at:i,snapshot:snap,trueSnapshot:trueSnap});
  if(['FUNCTIONAL_MISMATCH','FALSE_COMPOSABILITY'].includes(status.reason)){
    const counts={}; for(const k of c.components){const g=step.dependency_provenance?.[k]; if(g) counts[g]=(counts[g]??0)+1;} for(const [g,n] of Object.entries(counts)) if(n>=2) addRecord(memory.deps,g,{at:i,snapshot:snap,trueSnapshot:trueSnap});
  }
  if((step.lock_on_failed_attempt??[]).length) for(const k of step.lock_on_failed_attempt) memory.lockSensitive.add(k);
  const weakest=[...c.components].sort((a,b)=>(step.observed_capacities[a]??0)-(step.observed_capacities[b]??0))[0];
  addRecord(memory.failed,c.id,{at:i,reason:status.reason,weakest,qualityAtFailure:step.observed_capacities[weakest]??0,snapshot:snap,trueSnapshot:trueSnap});
}

export function runReopenableMemory(policyName,worldName){
  const p=policy(policyName), fixture=reopenWorlds[worldName]; if(!fixture) throw new Error('Unknown world '+worldName);
  const portfolio=new Map(),memory=createMemory(),locked=new Map(); const episodes=[]; let pending=true,maintenance=0,compounding=0,successes=0;
  for(let i=0;i<fixture.length;i++){
    const step=fixture[i]; for(const [k,until] of [...locked]) if(i>=until) locked.delete(k); if(p.state) updateCondition(step,memory);
    const {selected,filtered,reopened}=choose(step,portfolio,memory,p,locked,i); const attempts=[];
    for(const c of selected){const status=trueCandidateStatus(step,c,new Set(locked.keys())); attempts.push({...c,...status}); if(status.success){pending=false;successes++;} else {learn(step,c,status,memory,p,i); for(const k of step.lock_on_failed_attempt??[]) locked.set(k,i+3);}}
    maintenance+=portfolio.size*.02; const pol=step.risk>=.75&&!pending?'POLICY_P3':'POLICY_P2'; const base=step.risk*policyFactor(pol); const deferred=pending?.065*step.risk:0; const failedCost=attempts.filter(a=>!a.success).length*.02; compounding+=deferred;
    episodes.push({time:step.time,label:step.label,policy_name:policyName,selected,filtered,reopened,attempts,portfolio_size:portfolio.size,memory:{compatibility:[...memory.incompat.keys()],dependencies:[...memory.deps.keys()],failed:[...memory.failed.keys()],lock_sensitive:[...memory.lockSensitive],degraded:[...memory.degraded]},pending_failure:pending,policy:pol,hazard:Number((base+deferred+failedCost).toFixed(4))});
  }
  const metrics={protection:{hazard_exposure:Number(episodes.reduce((a,e)=>a+e.hazard,0).toFixed(4)),deferred_failure_compounding:Number(compounding.toFixed(4)),final_pending_failure:pending,p3_transitions:episodes.filter(e=>e.policy==='POLICY_P3').length},composition:{successful_compositions:successes},memory:{reopen_events:episodes.reduce((a,e)=>a+e.reopened.length,0),historical_records_remaining:episodes.at(-1).memory.compatibility.length+episodes.at(-1).memory.dependencies.length+episodes.at(-1).memory.failed.length},overhead:{repair_attempts:episodes.reduce((a,e)=>a+e.attempts.length,0),failed_attempts:episodes.reduce((a,e)=>a+e.attempts.filter(x=>!x.success).length,0),filtered_candidates:episodes.reduce((a,e)=>a+e.filtered.length,0),candidate_maintenance_cost:Number(maintenance.toFixed(4))}};
  const out={experiment:'EXPERIMENT-1J',world:worldName,memory_policy:policyName,episodes,metrics};
  out.invariants=[{id:'1J-01',pass:episodes.length===4},{id:'1J-02',pass:episodes.every(e=>e.selected.every(c=>c.id.startsWith('COMPOSED::')))},{id:'1J-03',pass:!('master_score' in metrics)},{id:'1J-04',pass:policyName in MEMORY_POLICIES},{id:'1J-05',pass:episodes.every(e=>Array.isArray(e.reopened))}];
  out.hash=crypto.createHash('sha256').update(JSON.stringify(out)).digest('hex'); return out;
}
export function runAllReopenable(){const out=[]; for(const w of Object.keys(reopenWorlds)) for(const p of Object.keys(MEMORY_POLICIES)) out.push(runReopenableMemory(p,w)); return out;}
