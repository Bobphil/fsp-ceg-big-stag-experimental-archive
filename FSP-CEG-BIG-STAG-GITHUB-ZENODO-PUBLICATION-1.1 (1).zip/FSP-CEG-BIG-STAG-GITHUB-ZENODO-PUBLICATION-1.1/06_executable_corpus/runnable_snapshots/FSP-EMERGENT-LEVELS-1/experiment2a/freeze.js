import fs from 'node:fs'; import path from 'node:path'; import crypto from 'node:crypto';
import { runAll } from './runner.js'; import { metricsFor } from './metrics.js'; import { evaluate2A } from './invariants.js';
const root=process.argv[2]||'../experiment2a-results'; fs.mkdirSync(root,{recursive:true});
const runs=runAll(); const manifest=[];
for(const r of runs){ const fp=path.join(root,`${r.case_id}.json`); fs.writeFileSync(fp,JSON.stringify(r,null,2)); const sha=crypto.createHash('sha256').update(fs.readFileSync(fp)).digest('hex'); manifest.push({case_id:r.case_id,file:path.basename(fp),sha256:sha}); }
const metrics=runs.map(metricsFor); fs.writeFileSync(path.join(root,'metrics.json'),JSON.stringify(metrics,null,2));
const inv=evaluate2A(runs); fs.writeFileSync(path.join(root,'invariants.json'),JSON.stringify(inv,null,2));
fs.writeFileSync(path.join(root,'FREEZE-MANIFEST.json'),JSON.stringify(manifest,null,2));
console.log(JSON.stringify({cases:runs.length,invariants_pass:inv.filter(x=>x.pass).length,invariants_total:inv.length,manifest,metrics},null,2));
