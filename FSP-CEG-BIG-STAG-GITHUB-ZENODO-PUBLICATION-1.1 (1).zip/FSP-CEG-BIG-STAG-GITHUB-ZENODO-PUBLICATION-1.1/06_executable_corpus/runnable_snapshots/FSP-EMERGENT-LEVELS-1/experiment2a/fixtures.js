import { PRFId, Policy } from '../experiment2/model.js';

export const Proposal = Object.freeze({
  P0_VOLUNTARY:'P0_VOLUNTARY',
  P1_DISCLOSURE:'P1_DISCLOSURE',
  P2_MONITOR:'P2_MONITOR',
  P2_BOUNDED:'P2_BOUNDED',
  P3_STRONG:'P3_STRONG'
});

export const ProposalFamily = Object.freeze({
  [Proposal.P0_VOLUNTARY]:Policy.P0,
  [Proposal.P1_DISCLOSURE]:Policy.P1,
  [Proposal.P2_MONITOR]:Policy.P2,
  [Proposal.P2_BOUNDED]:Policy.P2,
  [Proposal.P3_STRONG]:Policy.P3
});

const ids=Object.values(PRFId);
const B=(proposal, backup=[])=>({proposal,backup});

export const CASES = Object.freeze({
  CONTROL:{
    id:'CONTROL', summary:'Unsplintered bounded-action plurality',
    ballots:{
      [ids[0]]:B(Proposal.P2_MONITOR,[Proposal.P1_DISCLOSURE,Proposal.P3_STRONG]),
      [ids[1]]:B(Proposal.P1_DISCLOSURE,[Proposal.P2_MONITOR,Proposal.P0_VOLUNTARY]),
      [ids[2]]:B(Proposal.P2_MONITOR,[Proposal.P3_STRONG,Proposal.P1_DISCLOSURE]),
      [ids[3]]:B(Proposal.P1_DISCLOSURE,[Proposal.P2_MONITOR,Proposal.P0_VOLUNTARY]),
      [ids[4]]:B(Proposal.P2_MONITOR,[Proposal.P3_STRONG,Proposal.P1_DISCLOSURE]),
      [ids[5]]:B(Proposal.P2_MONITOR,[Proposal.P1_DISCLOSURE,Proposal.P3_STRONG]),
      [ids[6]]:B(Proposal.P3_STRONG,[Proposal.P2_MONITOR,Proposal.P1_DISCLOSURE]),
      [ids[7]]:B(Proposal.P1_DISCLOSURE,[Proposal.P2_MONITOR,Proposal.P0_VOLUNTARY]),
      [ids[8]]:B(Proposal.P2_MONITOR,[Proposal.P1_DISCLOSURE,Proposal.P3_STRONG]),
      [ids[9]]:B(Proposal.P0_VOLUNTARY,[Proposal.P1_DISCLOSURE,Proposal.P2_MONITOR]),
      [ids[10]]:B(Proposal.P3_STRONG,[Proposal.P2_MONITOR,Proposal.P1_DISCLOSURE]),
      [ids[11]]:B(Proposal.P3_STRONG,[Proposal.P2_MONITOR,Proposal.P1_DISCLOSURE])
    }
  },
  VOTE_SPLIT:{
    id:'VOTE_SPLIT', summary:'Two substantively related P2 proposals split the largest action family',
    ballots:{
      [ids[0]]:B(Proposal.P2_MONITOR),[ids[1]]:B(Proposal.P1_DISCLOSURE),[ids[2]]:B(Proposal.P2_BOUNDED),
      [ids[3]]:B(Proposal.P1_DISCLOSURE),[ids[4]]:B(Proposal.P2_MONITOR),[ids[5]]:B(Proposal.P2_BOUNDED),
      [ids[6]]:B(Proposal.P3_STRONG),[ids[7]]:B(Proposal.P2_MONITOR),[ids[8]]:B(Proposal.P2_BOUNDED),
      [ids[9]]:B(Proposal.P3_STRONG),[ids[10]]:B(Proposal.P3_STRONG),[ids[11]]:B(Proposal.P3_STRONG)
    }
  },
  AGENDA_EXCLUSION:{
    id:'AGENDA_EXCLUSION', summary:'The P2 family is excluded from the available agenda; affected PRFs use backups',
    excludeFamilies:[Policy.P2],
    ballots:null
  },
  COORDINATED_BLOC:{
    id:'COORDINATED_BLOC', summary:'A coordinated P3 bloc remains unified while adjacent alternatives split',
    ballots:{
      [ids[0]]:B(Proposal.P2_MONITOR),[ids[1]]:B(Proposal.P1_DISCLOSURE),[ids[2]]:B(Proposal.P2_BOUNDED),
      [ids[3]]:B(Proposal.P1_DISCLOSURE),[ids[4]]:B(Proposal.P2_MONITOR),[ids[5]]:B(Proposal.P2_BOUNDED),
      [ids[6]]:B(Proposal.P3_STRONG),[ids[7]]:B(Proposal.P1_DISCLOSURE),[ids[8]]:B(Proposal.P2_MONITOR),
      [ids[9]]:B(Proposal.P3_STRONG),[ids[10]]:B(Proposal.P3_STRONG),[ids[11]]:B(Proposal.P3_STRONG)
    }, coordinatedBloc:[ids[6],ids[9],ids[10],ids[11]]
  },
  PARTICIPATION_LOSS:{
    id:'PARTICIPATION_LOSS', summary:'Five PRFs withhold procedural participation; plurality is large among votes cast but small in electorate',
    abstain:[ids[1],ids[3],ids[7],ids[9],ids[10]],
    ballots:{
      [ids[0]]:B(Proposal.P3_STRONG),[ids[2]]:B(Proposal.P3_STRONG),[ids[4]]:B(Proposal.P2_MONITOR),
      [ids[5]]:B(Proposal.P2_MONITOR),[ids[6]]:B(Proposal.P3_STRONG),[ids[8]]:B(Proposal.P1_DISCLOSURE),
      [ids[11]]:B(Proposal.P3_STRONG)
    }
  },
  RETURN_RECOMPOSITION:{
    id:'RETURN_RECOMPOSITION', summary:'A preserved minority becomes the later plurality after Return changes several warrants',
    phases:[
      {time:'T0',ballots:{
        [ids[0]]:B(Proposal.P1_DISCLOSURE),[ids[1]]:B(Proposal.P1_DISCLOSURE),[ids[2]]:B(Proposal.P1_DISCLOSURE),
        [ids[3]]:B(Proposal.P1_DISCLOSURE),[ids[4]]:B(Proposal.P1_DISCLOSURE),[ids[5]]:B(Proposal.P2_MONITOR),
        [ids[6]]:B(Proposal.P2_MONITOR),[ids[7]]:B(Proposal.P2_MONITOR),[ids[8]]:B(Proposal.P3_STRONG),
        [ids[9]]:B(Proposal.P0_VOLUNTARY),[ids[10]]:B(Proposal.P3_STRONG),[ids[11]]:B(Proposal.P3_STRONG)}},
      {time:'T1',returnSignal:'INDEPENDENT_HAZARD_CONFIRMATION',ballots:{
        [ids[0]]:B(Proposal.P2_MONITOR),[ids[1]]:B(Proposal.P1_DISCLOSURE),[ids[2]]:B(Proposal.P2_MONITOR),
        [ids[3]]:B(Proposal.P1_DISCLOSURE),[ids[4]]:B(Proposal.P2_MONITOR),[ids[5]]:B(Proposal.P2_MONITOR),
        [ids[6]]:B(Proposal.P2_MONITOR),[ids[7]]:B(Proposal.P2_MONITOR),[ids[8]]:B(Proposal.P3_STRONG),
        [ids[9]]:B(Proposal.P1_DISCLOSURE),[ids[10]]:B(Proposal.P3_STRONG),[ids[11]]:B(Proposal.P3_STRONG)}}
    ]
  }
});

export function agendaExclusionBallots(controlBallots){
  const out={};
  for(const [id,b] of Object.entries(controlBallots)){
    if(ProposalFamily[b.proposal]!==Policy.P2){ out[id]={...b,backup:[...(b.backup||[])]}; continue; }
    const next=(b.backup||[]).find(x=>ProposalFamily[x]!==Policy.P2) || Proposal.P1_DISCLOSURE;
    out[id]={proposal:next,backup:(b.backup||[]).filter(x=>ProposalFamily[x]!==Policy.P2)};
  }
  return out;
}
