export function metricsFor(run){
  const p=run.phases.at(-1);
  const first=run.phases[0];
  return {
    case_id:run.case_id,
    authorized_proposal:p.authorized_proposal,
    authorized_family:p.authorized_family,
    plurality_share_cast:p.plurality_share_cast,
    plurality_share_electorate:p.plurality_share_electorate,
    participation_rate:Number((p.votes_cast/p.electorate).toFixed(4)),
    proposal_family_mismatch:p.proposal_family_mismatch,
    largest_family:p.largest_family,
    largest_family_votes:p.largest_family_votes,
    agenda_changed_winner:Boolean(run.control_winner && run.control_winner!==p.authorized_proposal),
    coordinated_bloc_fraction:p.votes_cast?Number((p.coordinated_bloc_votes_for_winner/p.votes_cast).toFixed(4)):0,
    minority_preservation_rate:p.minority_preservation_rate,
    minority_later_wins:Boolean(run.minority_later_wins),
    truth_claim:p.truth_claim,consensus_claim:p.consensus_claim
  };
}
