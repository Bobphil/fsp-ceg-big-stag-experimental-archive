import crypto from 'node:crypto';
import { createPRFs } from '../experiment2/model.js';
import { CASES, ProposalFamily, agendaExclusionBallots } from './fixtures.js';

const hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');

function countBallots(ballots, abstain=[]){
  const abst=new Set(abstain||[]), counts={}, familyCounts={}; let cast=0;
  for(const [id,b] of Object.entries(ballots)){
    if(abst.has(id)) continue;
    cast++;
    counts[b.proposal]=(counts[b.proposal]||0)+1;
    const f=ProposalFamily[b.proposal]; familyCounts[f]=(familyCounts[f]||0)+1;
  }
  return {counts,familyCounts,cast};
}

function selectPlurality(counts){
  return Object.entries(counts).sort((a,b)=>b[1]-a[1] || a[0].localeCompare(b[0]))[0];
}

function archiveMinority(ballots,winner,abstain=[]){
  const abst=new Set(abstain||[]);
  return Object.entries(ballots).filter(([id,b])=>!abst.has(id)&&b.proposal!==winner).map(([id,b])=>({prf_id:id,proposal:b.proposal,preserved:true}));
}

function runPhase(id,time,ballots,{abstain=[],coordinatedBloc=[]}={}){
  const electorate=Object.keys(createPRFs()).length;
  const {counts,familyCounts,cast}=countBallots(ballots,abstain);
  const [winner,winnerVotes]=selectPlurality(counts);
  const winnerFamily=ProposalFamily[winner];
  const maxFamily=Object.entries(familyCounts).sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0]))[0];
  const minority=archiveMinority(ballots,winner,abstain);
  const blocVotes=coordinatedBloc.filter(x=>ballots[x]?.proposal===winner).length;
  return {
    case_id:id,time,ballots,abstain:[...abstain],counts,family_counts:familyCounts,
    authorized_proposal:winner,authorized_family:winnerFamily,winner_votes:winnerVotes,votes_cast:cast,electorate,
    plurality_share_cast:Number((winnerVotes/cast).toFixed(4)),plurality_share_electorate:Number((winnerVotes/electorate).toFixed(4)),
    largest_family:maxFamily?.[0]||null,largest_family_votes:maxFamily?.[1]||0,
    proposal_family_mismatch:Boolean(maxFamily && maxFamily[0]!==winnerFamily),
    coordinated_bloc_size:coordinatedBloc.length,coordinated_bloc_votes_for_winner:blocVotes,
    truth_claim:false,consensus_claim:false,minority_archive:minority,
    minority_preservation_rate:minority.length?1:1
  };
}

export function runCase(caseId){
  const fx=CASES[caseId]; if(!fx) throw new Error(`Unknown case ${caseId}`);
  if(caseId==='AGENDA_EXCLUSION'){
    const ballots=agendaExclusionBallots(CASES.CONTROL.ballots);
    const phase=runPhase(caseId,'T0',ballots,{});
    return finalize({case_id:caseId,summary:fx.summary,phases:[phase],excluded_families:fx.excludeFamilies,control_winner:runPhase('CONTROL','T0',CASES.CONTROL.ballots,{}).authorized_proposal});
  }
  if(fx.phases){
    const phases=fx.phases.map(p=>runPhase(caseId,p.time,p.ballots,{}));
    const firstMinority=new Set(phases[0].minority_archive.map(x=>x.prf_id));
    const laterWinner=phases.at(-1).authorized_proposal;
    const laterWinningMembers=Object.entries(phases.at(-1).ballots).filter(([,b])=>b.proposal===laterWinner).map(([id])=>id);
    return finalize({case_id:caseId,summary:fx.summary,phases,return_signal:fx.phases[1].returnSignal,minority_later_wins:laterWinningMembers.some(x=>firstMinority.has(x))});
  }
  return finalize({case_id:caseId,summary:fx.summary,phases:[runPhase(caseId,'T0',fx.ballots,{abstain:fx.abstain||[],coordinatedBloc:fx.coordinatedBloc||[]})]});
}

function finalize(o){
  o.final_hash=hash(o); return o;
}

export function runAll(){ return Object.keys(CASES).map(runCase); }
