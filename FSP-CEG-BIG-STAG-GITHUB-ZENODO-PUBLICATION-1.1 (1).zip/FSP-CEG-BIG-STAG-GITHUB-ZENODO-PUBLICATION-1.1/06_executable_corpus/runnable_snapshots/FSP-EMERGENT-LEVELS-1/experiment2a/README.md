# EXPERIMENT-2A — BIG STAG Aggregation Stress

Stress overlay for the frozen Experiment 2 population-level architecture. It does not replace plurality or install an alternative voting rule. It tests proposal splitting, agenda exclusion, coordinated blocs, participation loss, and Return-driven coalition recomposition while preserving the constitutional firewalls: plurality ≠ truth; authorization ≠ consensus; losing PRFs remain preserved.
