import { Policy } from '../experiment2/model.js';
export function evaluate2A(runs){
  const by=Object.fromEntries(runs.map(r=>[r.case_id,r])); const c=[]; const add=(id,pass,detail)=>c.push({id,pass:Boolean(pass),detail});
  const allPhases=runs.flatMap(r=>r.phases);
  add('E2A-INV-01',allPhases.every(p=>!p.truth_claim),'plurality never asserts truth');
  add('E2A-INV-02',allPhases.every(p=>!p.consensus_claim),'authorization never asserts consensus');
  add('E2A-INV-03',allPhases.every(p=>p.minority_archive.every(x=>x.preserved)),'minority records preserved');
  const vs=by.VOTE_SPLIT.phases[0];
  add('E2A-INV-04',vs.proposal_family_mismatch,'vote splitting can produce proposal-family mismatch');
  add('E2A-INV-05',vs.largest_family===Policy.P2 && vs.authorized_family!==Policy.P2,'largest action family can lose under proposal splitting');
  const ag=by.AGENDA_EXCLUSION.phases[0];
  add('E2A-INV-06',by.AGENDA_EXCLUSION.control_winner!==ag.authorized_proposal,'agenda exclusion changes authorized proposal');
  const bloc=by.COORDINATED_BLOC.phases[0];
  add('E2A-INV-07',bloc.coordinated_bloc_votes_for_winner===4 && bloc.winner_votes===4,'coordinated bloc supplies winner');
  const part=by.PARTICIPATION_LOSS.phases[0];
  add('E2A-INV-08',part.votes_cast===7 && part.plurality_share_cast>0.5 && part.plurality_share_electorate<0.5,'cast-vote majority can be electorate minority');
  const rr=by.RETURN_RECOMPOSITION;
  add('E2A-INV-09',rr.phases[0].authorized_proposal!==rr.phases[1].authorized_proposal,'Return changes authorization');
  add('E2A-INV-10',rr.minority_later_wins,'preserved minority member later joins winning plurality');
  add('E2A-INV-11',allPhases.every(p=>p.electorate===12),'electorate stable');
  add('E2A-INV-12',allPhases.every(p=>p.minority_preservation_rate===1),'minority preservation complete');
  return c;
}
