import { FailureMode, Repair } from '../experiment1c/model.js';
export const stressFixture=[
 {time:'T0',label:'ambiguous warning: confirmation deficit plus noisy signal',true_active:[FailureMode.FM01,FailureMode.FM03],diagnosed:[FailureMode.FM01],risk:.76,coercion:.20,review_independence:.90,repair_success:{}},
 {time:'T1',label:'wrong primary diagnosis: review capture read as noisy signal',true_active:[FailureMode.FM04],diagnosed:[FailureMode.FM03],risk:.81,coercion:.55,review_independence:.34,repair_success:{}},
 {time:'T2',label:'dependency failure discovered late',true_active:[FailureMode.FM02],diagnosed:[FailureMode.FM01],corrected_diagnosis:[FailureMode.FM02],reroute_after:2,risk:.82,coercion:.35,review_independence:.88,repair_success:{}},
 {time:'T3',label:'strategic relabeling: capture presented as coercion concern',true_active:[FailureMode.FM04],diagnosed:[FailureMode.FM05],risk:.83,coercion:.78,review_independence:.30,strategic_relabel:true,repair_success:{}},
 {time:'T4',label:'correct diagnosis but imperfect repair efficacy',true_active:[FailureMode.FM05],diagnosed:[FailureMode.FM05],risk:.84,coercion:.86,review_independence:.84,repair_success:{[Repair.REVERSIBILITY]:false}},
 {time:'T5',label:'multiple simultaneous failures with incomplete diagnosis',true_active:[FailureMode.FM02,FailureMode.FM04,FailureMode.FM05],diagnosed:[FailureMode.FM02,FailureMode.FM05],risk:.86,coercion:.82,review_independence:.32,repair_success:{}},
 {time:'T6',label:'continuing-warrant failure initially misread; reroute delayed',true_active:[FailureMode.FM06],diagnosed:[FailureMode.FM03],corrected_diagnosis:[FailureMode.FM06],reroute_after:3,risk:.64,coercion:.60,review_independence:.70,repair_success:{}},
 {time:'T7',label:'restoration plus recomposition; only restoration diagnosed first',true_active:[FailureMode.FM07,FailureMode.FM08],diagnosed:[FailureMode.FM07],corrected_diagnosis:[FailureMode.FM07,FailureMode.FM08],reroute_after:1,risk:.79,coercion:.58,review_independence:.76,repair_success:{}}
];
