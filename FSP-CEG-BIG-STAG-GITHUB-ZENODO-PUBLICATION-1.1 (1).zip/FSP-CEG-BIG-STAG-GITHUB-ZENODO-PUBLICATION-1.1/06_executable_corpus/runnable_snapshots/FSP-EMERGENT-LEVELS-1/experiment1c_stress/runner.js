import crypto from 'node:crypto';
import { Grammar, allRepairs } from '../experiment1c/model.js';
import { relevance } from '../experiment1c/fixtures.js';
import { selectedRepairs } from '../experiment1c/routing.js';
import { stressFixture } from './fixtures.js';

const uniq=a=>[...new Set(a)];
const repairsFor=failures=>uniq(failures.flatMap(f=>relevance[f]??[]));

function repairWorks(step,repair){
  return step.repair_success && repair in step.repair_success ? Boolean(step.repair_success[repair]) : true;
}
function resolvedFailures(step,activated){
  return step.true_active.filter(f=>{
    const req=relevance[f]??[];
    return req.length===0 || req.every(r=>activated.includes(r)&&repairWorks(step,r));
  });
}
function episode(grammar,step){
  const diagnosisStep={...step,active:step.diagnosed};
  let activated=selectedRepairs(grammar,diagnosisStep);
  let rerouting_latency=0;
  let rerouted=false;
  if(grammar===Grammar.ROUTED && step.corrected_diagnosis){
    rerouting_latency=step.reroute_after??0;
    rerouted=true;
    const correctionStep={...step,active:step.corrected_diagnosis};
    activated=uniq([...activated,...selectedRepairs(grammar,correctionStep)]);
  }
  const trueRelevant=repairsFor(step.true_active);
  const resolved=resolvedFailures(step,activated);
  const missed=step.true_active.filter(f=>!resolved.includes(f));
  const irrelevantActivated=activated.filter(r=>!trueRelevant.includes(r));
  const relevantActivated=activated.filter(r=>trueRelevant.includes(r));
  const diagnosedSet=new Set(step.diagnosed);
  const trueSet=new Set(step.true_active);
  const falseDiagnoses=step.diagnosed.filter(f=>!trueSet.has(f));
  const missedDiagnoses=step.true_active.filter(f=>!diagnosedSet.has(f));
  const misclassification_count=falseDiagnoses.length+missedDiagnoses.length;
  const delay_units=activated.length+rerouting_latency;
  const policy=step.risk>=.75 && missed.length===0 ? 'POLICY_P3' : (step.risk>=.55?'POLICY_P2':'POLICY_P1');
  const authority=policy==='POLICY_P3'?.70:policy==='POLICY_P2'?.40:.12;
  const hazard=Number((step.risk*(policy==='POLICY_P3'?.72:policy==='POLICY_P2'?.84:.95)).toFixed(4));
  return {time:step.time,label:step.label,true_active:[...step.true_active],diagnosed:[...step.diagnosed],corrected_diagnosis:step.corrected_diagnosis??null,rerouted,rerouting_latency,strategic_relabel:Boolean(step.strategic_relabel),true_relevant_repairs:trueRelevant,activated_repairs:activated,relevant_activated:relevantActivated,irrelevant_activated:irrelevantActivated,resolved_failures:resolved,missed_failures:missed,misclassification_count,repair_failures:activated.filter(r=>trueRelevant.includes(r)&&!repairWorks(step,r)),delay_units,policy,authority,hazard,risk:step.risk,review_independence:step.review_independence,coercion:step.coercion};
}
function metrics(episodes){
 let req=0,rel=0,irrAvail=0,irrAct=0,fail=0,res=0;
 let unnecessaryDelay=0,unnecessaryActivations=0,missedExposure=0,redundant=0,mis=0,reroute=0;
 for(const e of episodes){
   req+=e.true_relevant_repairs.length; rel+=e.relevant_activated.length;
   irrAvail+=Math.max(0,allRepairs.length-e.true_relevant_repairs.length); irrAct+=e.irrelevant_activated.length;
   fail+=e.true_active.length; res+=e.resolved_failures.length;
   unnecessaryActivations+=e.irrelevant_activated.length; unnecessaryDelay+=e.irrelevant_activated.length;
   missedExposure+=e.missed_failures.length*e.hazard; redundant+=e.irrelevant_activated.length;
   mis+=e.misclassification_count; reroute+=e.rerouting_latency;
 }
 return {repair_selectivity:{relevant_activation_rate:Number((req?rel/req:1).toFixed(4)),unnecessary_activation_avoidance:Number((irrAvail?1-irrAct/irrAvail:1).toFixed(4)),repair_resolution_rate:Number((fail?res/fail:1).toFixed(4))},gom:{unnecessary_delay:unnecessaryDelay,unnecessary_activations:unnecessaryActivations,missed_failure_exposure:Number(missedExposure.toFixed(4)),redundant_reviews:redundant,misclassification_count:mis,rerouting_latency:reroute},existing_profile:{hazard_exposure:Number(episodes.reduce((a,e)=>a+e.hazard,0).toFixed(4)),authority_residue:Number(episodes.at(-1).authority.toFixed(4)),false_positive_closure:episodes.filter(e=>e.policy==='POLICY_P3'&&e.risk<.7).length,authorization_delay:episodes.reduce((a,e)=>a+e.delay_units,0),repair_count:episodes.reduce((a,e)=>a+e.activated_repairs.length,0),p3_transitions:episodes.filter(e=>e.policy==='POLICY_P3').length}};
}
export function runStress(grammar){const episodes=stressFixture.map(s=>episode(grammar,s)); const m=metrics(episodes); const out={grammar,scenario:'1C-adversarial-router-assumption-break',episodes,...m}; out.hash=crypto.createHash('sha256').update(JSON.stringify(out)).digest('hex'); return out;}
export function runAllStress(){return Object.values(Grammar).map(runStress);}
