import { CAPACITIES, OBSERVE_THRESHOLD, ACTIVATION_CONFIDENCE, ALL_BUNDLES, trueCandidateStatus } from '../experiment1h/model.js';
export { CAPACITIES, OBSERVE_THRESHOLD, ACTIVATION_CONFIDENCE, ALL_BUNDLES, trueCandidateStatus };

export const WEIGHT_POLICIES={
  fixed_caution:{decay:1,evidenceFactor:1,dependencyFactor:1,reinforce:0,reactivate:false,state:true},
  decay_only:{decay:.75,evidenceFactor:1,dependencyFactor:1,reinforce:0,reactivate:false,state:true},
  evidence_reassess:{decay:1,evidenceFactor:.35,dependencyFactor:.35,reinforce:0,reactivate:false,state:true},
  reinforce_only:{decay:1,evidenceFactor:1,dependencyFactor:1,reinforce:.35,reactivate:true,state:true},
  dynamic_full:{decay:.85,evidenceFactor:.35,dependencyFactor:.35,reinforce:.35,reactivate:true,state:true},
  dynamic_no_decay:{decay:1,evidenceFactor:.35,dependencyFactor:.35,reinforce:.35,reactivate:true,state:true},
  state_sensitive_only:{historical:false,state:true},
  reopen_delete_baseline:{delegate1j:'reopen_any',state:true}
};
export function weightPolicy(name){const p=WEIGHT_POLICIES[name];if(!p)throw new Error('Unknown policy '+name);return p;}
