import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';
import { temporalWorlds } from './fixtures.js';import { WEIGHT_POLICIES } from './model.js';import { runTemporalMemory } from './runner.js';
const out=process.argv[2];fs.rmSync(out,{recursive:true,force:true});fs.mkdirSync(out,{recursive:true});const manifest=[];
for(const w of Object.keys(temporalWorlds))for(const p of Object.keys(WEIGHT_POLICIES)){
 if(p==='reopen_delete_baseline'&&w==='false_composability_recurrence')continue;
 const r=runTemporalMemory(p,w);if(!r.hash){const x={...r};delete x.hash;r.hash=crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');}
 const fn=`${w}__${p}.json`;const data=JSON.stringify(r,null,2)+'\n';fs.writeFileSync(path.join(out,fn),data);manifest.push({world:w,policy:p,file:fn,sha256:crypto.createHash('sha256').update(data).digest('hex'),trace_hash:r.hash});
}
const m={experiment:'EXPERIMENT-1K',created_at:new Date().toISOString(),trace_count:manifest.length,traces:manifest};fs.writeFileSync(path.join(out,'FREEZE-MANIFEST.json'),JSON.stringify(m,null,2)+'\n');console.log(JSON.stringify({trace_count:manifest.length},null,2));
