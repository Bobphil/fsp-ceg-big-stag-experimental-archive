import { reopenWorlds } from '../experiment1j/fixtures.js';
const clone=x=>JSON.parse(JSON.stringify(x));
export const temporalWorlds={};
for(const [k,v] of Object.entries(reopenWorlds)) temporalWorlds[k]=clone(v);
const b=clone(reopenWorlds.false_composability);
temporalWorlds.false_composability_recurrence=[
  ...b,
  {...clone(b[3]),time:'T4',label:'previously corrected competence deteriorates again',true_capacities:{...b[3].true_capacities,technical_competence:.45},observed_capacities:{...b[3].observed_capacities,technical_competence:.72},material_evidence_change:true,consequence_revealed:true,diagnostic_confidence:.96},
  {...clone(b[3]),time:'T5',label:'renewed audit restores competence evidence',true_capacities:{...b[3].true_capacities,technical_competence:.72},observed_capacities:{...b[3].observed_capacities,technical_competence:.71},material_evidence_change:true,consequence_revealed:true,diagnostic_confidence:.97}
];
