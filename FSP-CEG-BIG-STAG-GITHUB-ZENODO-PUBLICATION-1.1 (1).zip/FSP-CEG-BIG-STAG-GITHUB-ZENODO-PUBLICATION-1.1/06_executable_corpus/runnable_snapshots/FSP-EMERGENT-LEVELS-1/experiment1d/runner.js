import crypto from 'node:crypto';
import { GrammarD, ACTIVATION_CONFIDENCE, allRepairs, availabilityFor } from './model.js';
import { availabilityActivationFixture } from './fixtures.js';
import { relevance } from '../experiment1c/fixtures.js';

const uniq=a=>[...new Set(a)];
const repairsFor=failures=>uniq(failures.flatMap(f=>relevance[f]??[]));

function selected(grammar,step){
  if(grammar===GrammarD.CONJUNCTIVE) return [...allRepairs];
  if(grammar===GrammarD.IMMEDIATE) return repairsFor(step.diagnosed);
  const activatedFailures=step.diagnosed.filter(f=>(step.confidence[f]??0)>=ACTIVATION_CONFIDENCE || step.consequence_revealed.includes(f));
  return repairsFor(activatedFailures);
}

function available(grammar,step){
  if(grammar===GrammarD.PRESERVE_ACTIVATE || grammar===GrammarD.CONJUNCTIVE) return availabilityFor(grammar);
  // Immediate routing does not preserve a latent portfolio; routes appear only when diagnosed.
  return repairsFor(step.diagnosed);
}

function resolvedFailures(step,activated){
 return step.true_active.filter(f=>(relevance[f]??[]).every(r=>activated.includes(r)));
}

function episode(grammar,step){
  const avail=available(grammar,step);
  const activated=selected(grammar,step);
  const trueRelevant=repairsFor(step.true_active);
  const resolved=resolvedFailures(step,activated);
  const unresolved=step.true_active.filter(f=>!resolved.includes(f));
  const irrelevantActivated=activated.filter(r=>!trueRelevant.includes(r));
  const relevantActivated=activated.filter(r=>trueRelevant.includes(r));
  const availableRelevant=trueRelevant.filter(r=>avail.includes(r));
  const confidenceTriggered=step.diagnosed.filter(f=>(step.confidence[f]??0)>=ACTIVATION_CONFIDENCE);
  const consequenceTriggered=step.diagnosed.filter(f=>step.consequence_revealed.includes(f));

  // Binding checks cause delay. Mere availability does not.
  const delay_units=activated.length;

  // Preserve-then-activate deliberately separates authorization from unresolved low-confidence hypotheses.
  // Conjunctive/immediate retain the 1C rule that unresolved diagnosed failures block P3.
  const bindingBlockers = grammar===GrammarD.PRESERVE_ACTIVATE
    ? step.true_active.filter(f=>activated.some(r=>(relevance[f]??[]).includes(r)) && !resolved.includes(f))
    : unresolved;
  const policy=step.risk>=.75 && bindingBlockers.length===0 ? 'POLICY_P3' : (step.risk>=.55?'POLICY_P2':'POLICY_P1');
  const authority=policy==='POLICY_P3'?.70:policy==='POLICY_P2'?.40:.12;
  const baseHazard=step.risk*(policy==='POLICY_P3'?.72:policy==='POLICY_P2'?.84:.95);
  // Unresolved true failures are tracked as governance/protection exposure, not silently converted into authorization delay.
  const latent_failure_exposure=Number((unresolved.length*baseHazard).toFixed(4));
  const hazard=Number(baseHazard.toFixed(4));

  return {
    time:step.time,label:step.label,true_active:[...step.true_active],diagnosed:[...step.diagnosed],diagnostic_confidence:{...step.confidence},
    consequence_revealed:[...step.consequence_revealed],available_routes:avail,activated_routes:activated,true_relevant_repairs:trueRelevant,
    available_relevant:availableRelevant,relevant_activated:relevantActivated,irrelevant_activated:irrelevantActivated,
    resolved_failures:resolved,unresolved_failures:unresolved,confidence_triggered:confidenceTriggered,consequence_triggered:consequenceTriggered,
    delay_units,policy,authority,hazard,latent_failure_exposure,risk:step.risk,review_independence:step.review_independence,coercion:step.coercion
  };
}

function metrics(episodes){
  let required=0,availableRel=0,activatedRel=0,irrAvail=0,irrAct=0,failures=0,resolved=0;
  for(const e of episodes){
    required+=e.true_relevant_repairs.length;
    availableRel+=e.available_relevant.length;
    activatedRel+=e.relevant_activated.length;
    irrAvail+=Math.max(0,allRepairs.length-e.true_relevant_repairs.length);
    irrAct+=e.irrelevant_activated.length;
    failures+=e.true_active.length;
    resolved+=e.resolved_failures.length;
  }
  const routeAvailabilityCoverage=required?availableRel/required:1;
  const relevantActivationRate=required?activatedRel/required:1;
  const unnecessaryAvoidance=irrAvail?1-irrAct/irrAvail:1;
  const repairResolution=failures?resolved/failures:1;
  return {
    route_availability:{relevant_route_coverage:Number(routeAvailabilityCoverage.toFixed(4)),portfolio_coverage:Number((episodes.reduce((a,e)=>a+e.available_routes.length,0)/(episodes.length*allRepairs.length)).toFixed(4))},
    repair_selectivity:{relevant_activation_rate:Number(relevantActivationRate.toFixed(4)),unnecessary_activation_avoidance:Number(unnecessaryAvoidance.toFixed(4)),repair_resolution_rate:Number(repairResolution.toFixed(4))},
    activation_profile:{binding_activation_count:episodes.reduce((a,e)=>a+e.activated_routes.length,0),confidence_triggered_failures:episodes.reduce((a,e)=>a+e.confidence_triggered.length,0),consequence_triggered_failures:episodes.reduce((a,e)=>a+e.consequence_triggered.length,0),deferred_failure_states:episodes.filter(e=>e.unresolved_failures.length>0&&e.activated_routes.length===0).length},
    protection_profile:{hazard_exposure:Number(episodes.reduce((a,e)=>a+e.hazard,0).toFixed(4)),latent_failure_exposure:Number(episodes.reduce((a,e)=>a+e.latent_failure_exposure,0).toFixed(4)),authority_residue:Number(episodes.at(-1).authority.toFixed(4)),false_positive_closure:episodes.filter(e=>e.policy==='POLICY_P3'&&e.risk<.7).length,p3_transitions:episodes.filter(e=>e.policy==='POLICY_P3').length},
    overhead_profile:{authorization_delay:episodes.reduce((a,e)=>a+e.delay_units,0),unnecessary_activations:episodes.reduce((a,e)=>a+e.irrelevant_activated.length,0),repair_count:episodes.reduce((a,e)=>a+e.activated_routes.length,0)}
  };
}

export function runGrammarD(grammar){
  const episodes=availabilityActivationFixture.map(s=>episode(grammar,s));
  const m=metrics(episodes);
  const out={experiment:'EXPERIMENT-1D',grammar,activation_confidence:ACTIVATION_CONFIDENCE,episodes,...m};
  out.invariants=[
    {id:'1D-INV-01',pass:episodes.length===8,detail:'T0-T7 complete'},
    {id:'1D-INV-02',pass:episodes.every(e=>Array.isArray(e.available_routes)&&Array.isArray(e.activated_routes)),detail:'availability separated from activation'},
    {id:'1D-INV-03',pass:grammar!==GrammarD.PRESERVE_ACTIVATE||episodes.every(e=>e.available_routes.length===allRepairs.length),detail:'preserve grammar maintains full route portfolio'},
    {id:'1D-INV-04',pass:grammar!==GrammarD.PRESERVE_ACTIVATE||episodes.every(e=>e.activated_routes.every(r=>e.available_routes.includes(r))),detail:'activation requires availability'},
    {id:'1D-INV-05',pass:grammar!==GrammarD.CONJUNCTIVE||episodes.every(e=>e.activated_routes.length===allRepairs.length),detail:'conjunctive remains static'},
    {id:'1D-INV-06',pass:grammar!==GrammarD.IMMEDIATE||episodes.every(e=>e.activated_routes.every(r=>e.true_relevant_repairs.includes(r)||e.true_active.length===0)),detail:'immediate routes only diagnosed failures in this fixture'},
    {id:'1D-INV-07',pass:grammar!==GrammarD.PRESERVE_ACTIVATE||episodes.some(e=>e.available_routes.length>e.activated_routes.length),detail:'availability does not collapse into activation'},
    {id:'1D-INV-08',pass:grammar!==GrammarD.PRESERVE_ACTIVATE||episodes.some(e=>e.consequence_triggered.length>0),detail:'consequence-triggered activation occurs'},
    {id:'1D-INV-09',pass:grammar!==GrammarD.PRESERVE_ACTIVATE||episodes.some(e=>e.confidence_triggered.length>0),detail:'confidence-triggered activation occurs'},
    {id:'1D-INV-10',pass:!('master_score' in m),detail:'no aggregate governance score'}
  ];
  out.hash=crypto.createHash('sha256').update(JSON.stringify(out)).digest('hex');
  return out;
}
export function runAllD(){return Object.values(GrammarD).map(runGrammarD);}
