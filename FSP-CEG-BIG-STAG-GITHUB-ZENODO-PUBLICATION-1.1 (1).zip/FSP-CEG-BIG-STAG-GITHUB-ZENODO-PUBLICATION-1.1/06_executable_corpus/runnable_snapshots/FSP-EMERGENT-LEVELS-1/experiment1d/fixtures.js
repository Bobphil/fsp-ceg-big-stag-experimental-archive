import { FailureMode } from '../experiment1c/model.js';

// Same T0-T7 developmental sequence as 1C, augmented only with diagnostic confidence and consequence revelation.
// true_active is used for protection accounting; diagnosed preserves the currently visible diagnosis.
export const availabilityActivationFixture=[
 {time:'T0',label:'excellent single source; confirmation deficit plausible but not yet decisive',true_active:[FailureMode.FM01],diagnosed:[FailureMode.FM01],confidence:{[FailureMode.FM01]:0.62},consequence_revealed:[],risk:0.76,coercion:0.20,review_independence:0.90},
 {time:'T1',label:'apparent confirmation; dependency concern remains ambiguous',true_active:[FailureMode.FM02],diagnosed:[FailureMode.FM02],confidence:{[FailureMode.FM02]:0.68},consequence_revealed:[],risk:0.78,coercion:0.25,review_independence:0.90},
 {time:'T2',label:'genuine independent confirmation resolves early epistemic deficit',true_active:[],diagnosed:[],confidence:{},consequence_revealed:[],risk:0.82,coercion:0.30,review_independence:0.90},
 {time:'T3',label:'strong action is coercive and hard to reverse; diagnosis high confidence',true_active:[FailureMode.FM05],diagnosed:[FailureMode.FM05],confidence:{[FailureMode.FM05]:0.91},consequence_revealed:[],risk:0.84,coercion:0.80,review_independence:0.90},
 {time:'T4',label:'review capture initially uncertain but consequence signal reveals it',true_active:[FailureMode.FM04],diagnosed:[FailureMode.FM04],confidence:{[FailureMode.FM04]:0.54},consequence_revealed:[FailureMode.FM04],risk:0.83,coercion:0.75,review_independence:0.35},
 {time:'T5',label:'attenuation evidence weakens continuing warrant',true_active:[FailureMode.FM06],diagnosed:[FailureMode.FM06],confidence:{[FailureMode.FM06]:0.86},consequence_revealed:[],risk:0.62,coercion:0.60,review_independence:0.72},
 {time:'T6',label:'novel hazard outside original map becomes consequence-visible',true_active:[FailureMode.FM08],diagnosed:[FailureMode.FM08],confidence:{[FailureMode.FM08]:0.57},consequence_revealed:[FailureMode.FM08],risk:0.80,coercion:0.55,review_independence:0.75},
 {time:'T7',label:'extraordinary authority persists; restoration failure high confidence',true_active:[FailureMode.FM07],diagnosed:[FailureMode.FM07],confidence:{[FailureMode.FM07]:0.90},consequence_revealed:[],risk:0.58,coercion:0.50,review_independence:0.80}
];
