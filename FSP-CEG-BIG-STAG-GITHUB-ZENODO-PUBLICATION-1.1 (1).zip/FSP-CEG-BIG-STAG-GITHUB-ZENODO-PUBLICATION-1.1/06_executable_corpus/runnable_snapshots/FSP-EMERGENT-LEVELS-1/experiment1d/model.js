import { Repair, allRepairs } from '../experiment1c/model.js';
export { Repair, allRepairs };

export const GrammarD=Object.freeze({
  CONJUNCTIVE:'GRAMMAR_STATIC_CONJUNCTIVE',
  IMMEDIATE:'GRAMMAR_IMMEDIATE_ROUTING',
  PRESERVE_ACTIVATE:'GRAMMAR_PRESERVE_THEN_ACTIVATE'
});

export const ACTIVATION_CONFIDENCE=0.80;

export function availabilityFor(grammar){
  // Conjunctive routes are all binding; immediate routing makes the relevant route available on diagnosis;
  // preserve-then-activate keeps the full repair portfolio available without making it binding.
  if(grammar===GrammarD.PRESERVE_ACTIVATE || grammar===GrammarD.CONJUNCTIVE) return [...allRepairs];
  return [];
}
