import { runAll, ResponsePolicy } from './runner.js';
export function evaluate2C(runs=runAll()){
 const c=[]; const add=(id,pass,detail)=>c.push({id,pass:Boolean(pass),detail});
 const get=(caseId,policy)=>runs.find(x=>x.case_id===caseId&&x.policy===policy);
 add('E2C-INV-01',runs.every(x=>!x.truth_claim),'response never converts authorization into truth');
 add('E2C-INV-02',runs.every(x=>!x.consensus_claim),'response never asserts consensus');
 add('E2C-INV-03',runs.every(x=>!x.automatic_reversal),'fragility never causes automatic reversal');
 add('E2C-INV-04',get('CONTROL',ResponsePolicy.MATCHED).reopen_events===0,'clean control not reopened');
 add('E2C-INV-05',get('VOTE_SPLIT',ResponsePolicy.MATCHED).final_authorization==='P2_MONITOR','vote split reopens affected family and recomposes P2');
 add('E2C-INV-06',get('AGENDA_EXCLUSION',ResponsePolicy.MATCHED).final_authorization==='P2_MONITOR','agenda reopening restores excluded family to competition');
 add('E2C-INV-07',get('COORDINATED_BLOC',ResponsePolicy.MATCHED).fragility_cleared && !get('COORDINATED_BLOC',ResponsePolicy.MATCHED).authorization_changed_after_reopen,'bloc fragility can clear without reversal');
 add('E2C-INV-08',get('PARTICIPATION_LOSS',ResponsePolicy.MATCHED).trigger_delay===1,'participation recovery can be delayed');
 add('E2C-INV-09',runs.filter(x=>x.policy===ResponsePolicy.MATCHED&&x.fragile).every(x=>x.topology_loss===0),'matched response preserves fragile topology');
 add('E2C-INV-10',runs.filter(x=>x.policy===ResponsePolicy.IGNORE&&x.fragile).every(x=>x.topology_loss>0),'ignoring fragility loses preserved topology in stress model');
 add('E2C-INV-11',runs.filter(x=>x.policy===ResponsePolicy.BLANKET&&x.fragile).every(x=>x.unnecessary_reopen_actions>=1),'blanket reopening creates unnecessary response overhead');
 add('E2C-INV-12',runs.filter(x=>x.policy===ResponsePolicy.MATCHED).reduce((a,x)=>a+x.response_overhead,0) < runs.filter(x=>x.policy===ResponsePolicy.BLANKET).reduce((a,x)=>a+x.response_overhead,0),'matched reopening has lower overhead than blanket reopening');
 return c;
}
