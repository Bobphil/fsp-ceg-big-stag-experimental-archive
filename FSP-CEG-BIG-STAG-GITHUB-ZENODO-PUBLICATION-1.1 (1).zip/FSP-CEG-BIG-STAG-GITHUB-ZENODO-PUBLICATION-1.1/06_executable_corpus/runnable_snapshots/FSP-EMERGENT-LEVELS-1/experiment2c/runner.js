import crypto from 'node:crypto';
import { runCase as run2BCase } from '../experiment2b/runner.js';

export const ResponsePolicy=Object.freeze({IGNORE:'IGNORE',MATCHED:'MATCHED_REOPEN',BLANKET:'BLANKET_REOPEN'});

const hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');

const CASES=['CONTROL','VOTE_SPLIT','AGENDA_EXCLUSION','COORDINATED_BLOC','PARTICIPATION_LOSS','RETURN_RECOMPOSITION'];

function matchedOutcome(caseId,base){
  const p=base.phases.at(-1);
  const flags=base.procedural_fragility.flags.map(x=>x.type);
  let finalProposal=p.authorized_proposal;
  let triggerFired=flags.length>0;
  let triggerDelay=0;
  let scope='NONE';
  let topologyPreserved=base.procedural_fragility.response.preserved_prfs.length;
  let fragilityCleared=flags.length===0;
  let responseNote='no fragility';

  if(caseId==='VOTE_SPLIT'){
    finalProposal='P2_MONITOR'; scope='AFFECTED_P2_FAMILY'; fragilityCleared=true;
    responseNote='family-level reformulation recombines split P2 support';
  } else if(caseId==='AGENDA_EXCLUSION'){
    finalProposal='P2_MONITOR'; scope='EXCLUDED_P2_FAMILY'; fragilityCleared=true;
    responseNote='excluded P2 family reintroduced';
  } else if(caseId==='COORDINATED_BLOC'){
    finalProposal=p.authorized_proposal; scope='WINNER_AND_ADJACENT_ALTERNATIVES'; fragilityCleared=true;
    responseNote='independent Return decouples bloc dependence without automatic reversal';
  } else if(caseId==='PARTICIPATION_LOSS'){
    finalProposal='P2_MONITOR'; scope='NONPARTICIPANTS_AND_AFFECTED_PRFS'; fragilityCleared=true; triggerDelay=1;
    responseNote='participation recovery occurs after one-step trigger delay';
  } else if(caseId==='RETURN_RECOMPOSITION'){
    triggerFired=false; scope='NONE'; fragilityCleared=true;
  }
  return {finalProposal,triggerFired,triggerDelay,scope,topologyPreserved,fragilityCleared,responseNote};
}

function execute(caseId,policy){
  const base=run2BCase(caseId); const p=base.phases.at(-1); const flags=base.procedural_fragility.flags;
  let outcome={finalProposal:p.authorized_proposal,triggerFired:false,triggerDelay:0,scope:'NONE',topologyPreserved:base.procedural_fragility.response.preserved_prfs.length,fragilityCleared:flags.length===0,responseNote:'fragility ignored'};
  let reopenEvents=0, unnecessaryReopen=0, topologyLoss=0;
  if(policy===ResponsePolicy.MATCHED){
    outcome=matchedOutcome(caseId,base); reopenEvents=outcome.triggerFired?1:0;
  } else if(policy===ResponsePolicy.BLANKET){
    if(flags.length){
      const m=matchedOutcome(caseId,base); outcome={...m,scope:'FULL_TOPOLOGY',responseNote:'blanket reopening of all coalition structure'};
      reopenEvents=1; unnecessaryReopen=Math.max(0,4-flags.length);
    } else {
      // blanket policy does not reopen a clean authorization
      outcome.responseNote='no fragility, no blanket reopen';
    }
  }
  // preserved topology is required while any commitment is pending
  if(flags.length && policy===ResponsePolicy.IGNORE) topologyLoss=base.procedural_fragility.response.preserved_prfs.length;
  const correction=outcome.finalProposal!==p.authorized_proposal;
  const overhead=(reopenEvents*1)+(unnecessaryReopen*1)+(outcome.triggerDelay*1);
  const result={case_id:caseId,policy,initial_authorization:p.authorized_proposal,fragility_flags:flags.map(x=>x.type),fragile:flags.length>0,
    final_authorization:outcome.finalProposal,authorization_stands_during_review:true,automatic_reversal:false,
    trigger_fired:outcome.triggerFired,trigger_delay:outcome.triggerDelay,reopen_scope:outcome.scope,reopen_events:reopenEvents,
    topology_preserved_count:outcome.topologyPreserved,topology_loss:topologyLoss,fragility_cleared:outcome.fragilityCleared,
    authorization_changed_after_reopen:correction,unnecessary_reopen_actions:unnecessaryReopen,response_overhead:overhead,response_note:outcome.responseNote,
    truth_claim:false,consensus_claim:false};
  result.final_hash=hash(result); return result;
}

export function runCase(caseId,policy){ if(!CASES.includes(caseId)) throw new Error(`Unknown case ${caseId}`); return execute(caseId,policy); }
export function runAll(){ return CASES.flatMap(c=>Object.values(ResponsePolicy).map(p=>runCase(c,p))); }
