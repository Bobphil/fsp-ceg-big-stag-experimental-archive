import fs from 'node:fs'; import path from 'node:path'; import crypto from 'node:crypto';
import { runAll } from './runner.js'; import { evaluate2C } from './invariants.js'; import { summarize } from './metrics.js';
const root=process.argv[2]||'results2c'; fs.mkdirSync(root,{recursive:true}); const runs=runAll(); const manifest=[];
for(const r of runs){ const fn=`${r.case_id}__${r.policy}.json`; const fp=path.join(root,fn); fs.writeFileSync(fp,JSON.stringify(r,null,2)); manifest.push({case_id:r.case_id,policy:r.policy,file:fn,sha256:crypto.createHash('sha256').update(fs.readFileSync(fp)).digest('hex')}); }
const inv=evaluate2C(runs), summary=summarize(runs); fs.writeFileSync(path.join(root,'invariants.json'),JSON.stringify(inv,null,2)); fs.writeFileSync(path.join(root,'summary.json'),JSON.stringify(summary,null,2)); fs.writeFileSync(path.join(root,'FREEZE-MANIFEST.json'),JSON.stringify(manifest,null,2));
console.log(JSON.stringify({traces:runs.length,invariants_pass:inv.filter(x=>x.pass).length,invariants_total:inv.length,summary},null,2));
