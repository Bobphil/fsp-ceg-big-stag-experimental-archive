export function summarize(runs){
 const by={};
 for(const r of runs){ const x=by[r.policy]??={policy:r.policy,cases:0,fragile_cases:0,reopen_events:0,corrections:0,fragility_cleared:0,topology_loss:0,unnecessary_reopen_actions:0,response_overhead:0,trigger_delay:0}; x.cases++; if(r.fragile)x.fragile_cases++; x.reopen_events+=r.reopen_events; x.corrections+=r.authorization_changed_after_reopen?1:0; x.fragility_cleared+=r.fragility_cleared?1:0; x.topology_loss+=r.topology_loss; x.unnecessary_reopen_actions+=r.unnecessary_reopen_actions; x.response_overhead+=r.response_overhead; x.trigger_delay+=r.trigger_delay; }
 return Object.values(by);
}
