# Acceptance Record — UCP-XR-EXPERIMENT-2F

- Full regression: **269/269 PASS**
- 2F invariants: **13/13 PASS**
- Frozen traces: **32**
- Population: **12 PRFs fixed across every trace**
- Return event: **fixed across every trace**
- Stresses: capture, delay, distortion, information loss
- Architectural factors varied: independence, redundancy, persistence, receiver obligation, cross-triggering, termination authority
- Interpretation performed only after trace freeze.
