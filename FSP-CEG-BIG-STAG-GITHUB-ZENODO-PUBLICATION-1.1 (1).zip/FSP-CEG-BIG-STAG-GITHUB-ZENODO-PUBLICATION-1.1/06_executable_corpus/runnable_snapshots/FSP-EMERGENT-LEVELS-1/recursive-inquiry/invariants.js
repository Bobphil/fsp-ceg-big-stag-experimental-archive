import {scales,Grammar,familyResemblance,strictHomology} from './model.js';
export function evaluate(){const r=[]; const push=(n,p,d='')=>r.push({name:n,pass:!!p,detail:d});
push('RI-01 grammar has compression and decompression',Grammar.includes('COMPRESS')&&Grammar.includes('DECOMPRESS'));
push('RI-02 every scale names input complexity',scales.every(s=>s.input));
push('RI-03 every scale compresses',scales.every(s=>s.compression));
push('RI-04 every scale records omitted/lost distinctions',scales.every(s=>s.lost.length>0));
push('RI-05 every compression has bounded authorization',scales.every(s=>s.authorization));
push('RI-06 every scale preserves residue',scales.every(s=>s.residue.length>0));
push('RI-07 every scale has Return signal',scales.every(s=>s.returnSignal));
push('RI-08 every scale supports decompression',scales.every(s=>s.decompression));
push('RI-09 every scale supports recomposition',scales.every(s=>s.recomposition));
push('RI-10 scale-specific primitives remain explicit',scales.every(s=>s.specific.length>0));
push('RI-11 family resemblance holds',familyResemblance());
push('RI-12 strict formal identity is NOT claimed',strictHomology()===false);
push('RI-13 authorization is not encoded as truth',scales.every(s=>!String(s.authorization).toLowerCase().includes('truth')));
push('RI-14 decompression is selective not total',scales.every(s=>!String(s.decompression).toLowerCase().includes('everything')));
return r;}
