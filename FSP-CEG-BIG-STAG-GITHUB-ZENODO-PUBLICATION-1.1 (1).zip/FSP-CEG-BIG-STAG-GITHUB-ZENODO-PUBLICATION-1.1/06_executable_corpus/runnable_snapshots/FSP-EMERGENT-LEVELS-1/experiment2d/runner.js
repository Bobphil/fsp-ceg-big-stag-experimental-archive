import crypto from 'node:crypto';
import { runCase as run2BCase } from '../experiment2b/runner.js';
import { FragilityType } from '../experiment2b/fragility.js';
import { ResponsePolicy } from '../experiment2c/runner.js';

const hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const F=FragilityType;

export const StressCase=Object.freeze({
  FALSE_POSITIVE:'FALSE_POSITIVE',
  MISSED_FRAGILITY:'MISSED_FRAGILITY',
  INTERACTING_FRAGILITIES:'INTERACTING_FRAGILITIES',
  STRATEGIC_TRIGGERING:'STRATEGIC_TRIGGERING',
  TRIGGER_CAPTURE:'TRIGGER_CAPTURE',
  REPEATED_REOPEN:'REPEATED_REOPEN',
  IRRECOVERABLE_TOPOLOGY:'IRRECOVERABLE_TOPOLOGY'
});

const CASES={
  [StressCase.FALSE_POSITIVE]:{
    base:'CONTROL', trueFlags:[], observed:[F.VOTE_SPLIT], cycles:1,
    note:'clean authorization falsely flagged as vote splitting'
  },
  [StressCase.MISSED_FRAGILITY]:{
    base:'VOTE_SPLIT', trueFlags:[F.VOTE_SPLIT], observed:[], cycles:1,
    note:'real vote splitting is not detected'
  },
  [StressCase.INTERACTING_FRAGILITIES]:{
    base:'PARTICIPATION_LOSS', trueFlags:[F.VOTE_SPLIT,F.LOW_PARTICIPATION], observed:[F.VOTE_SPLIT,F.LOW_PARTICIPATION], cycles:1,
    note:'vote splitting and participation weakness coexist and require both repairs'
  },
  [StressCase.STRATEGIC_TRIGGERING]:{
    base:'CONTROL', trueFlags:[], observed:[F.BLOC_CONCENTRATION], cycles:2,
    strategic:true, note:'actor manufactures a bloc-concentration claim to force review'
  },
  [StressCase.TRIGGER_CAPTURE]:{
    base:'AGENDA_EXCLUSION', trueFlags:[F.AGENDA_DEPENDENCE], observed:[F.AGENDA_DEPENDENCE], cycles:1,
    captured:[F.AGENDA_DEPENDENCE], note:'correct trigger fires but agenda-reintroduction channel is captured'
  },
  [StressCase.REPEATED_REOPEN]:{
    base:'VOTE_SPLIT', trueFlags:[F.VOTE_SPLIT], observed:[F.VOTE_SPLIT], cycles:3,
    staleAfterClear:true, note:'stale diagnostic keeps reopening after the first successful repair'
  },
  [StressCase.IRRECOVERABLE_TOPOLOGY]:{
    base:'AGENDA_EXCLUSION', trueFlags:[F.AGENDA_DEPENDENCE], observed:[F.AGENDA_DEPENDENCE], cycles:1,
    reconstructable:false, note:'excluded warrant topology is lost before reopening can reconstruct it'
  }
};

function initialFor(baseId){
  const b=run2BCase(baseId); const p=b.phases.at(-1);
  return {initial:p.authorized_proposal,preserved:b.procedural_fragility.response.preserved_prfs.length,electorate:p.electorate??12};
}
function repairEffect(flag, current){
  if(flag===F.VOTE_SPLIT) return {proposal:'P2_MONITOR',delay:0,scope:'AFFECTED_P2_FAMILY'};
  if(flag===F.AGENDA_DEPENDENCE) return {proposal:'P2_MONITOR',delay:0,scope:'EXCLUDED_P2_FAMILY'};
  if(flag===F.LOW_PARTICIPATION) return {proposal:'P2_MONITOR',delay:1,scope:'NONPARTICIPANTS_AND_AFFECTED_PRFS'};
  if(flag===F.BLOC_CONCENTRATION) return {proposal:current,delay:0,scope:'WINNER_AND_ADJACENT_ALTERNATIVES'};
  return {proposal:current,delay:0,scope:'UNKNOWN'};
}

export function runCase(caseId,policy){
  const cfg=CASES[caseId]; if(!cfg) throw new Error(`Unknown stress case ${caseId}`);
  const init=initialFor(cfg.base);
  let proposal=init.initial, activeTrue=new Set(cfg.trueFlags), reopenEvents=0, delay=0, unnecessary=0, repairAttempts=0;
  let capturedAttempts=0, failedReconstruction=0, successfulRepairs=0, repeatedAfterClear=0;
  const responseLog=[];
  const observed=cfg.observed;
  const falseFlags=observed.filter(x=>!cfg.trueFlags.includes(x));
  const missedFlags=cfg.trueFlags.filter(x=>!observed.includes(x));
  let topologyPreserved=init.preserved, topologyLoss=0;

  const doRepair=(flag,cycle,blanket=false)=>{
    repairAttempts++;
    const wasActive=activeTrue.has(flag);
    if(!wasActive){ unnecessary++; if(cycle>0 && cfg.staleAfterClear) repeatedAfterClear++; responseLog.push({cycle,flag,status:'UNNECESSARY'}); return; }
    if(cfg.captured?.includes(flag)){ capturedAttempts++; responseLog.push({cycle,flag,status:'CAPTURED'}); return; }
    if(cfg.reconstructable===false && (flag===F.AGENDA_DEPENDENCE||flag===F.VOTE_SPLIT)){
      failedReconstruction++; topologyLoss=init.preserved; topologyPreserved=0; responseLog.push({cycle,flag,status:'TOPOLOGY_UNRECOVERABLE'}); return;
    }
    const eff=repairEffect(flag,proposal); proposal=eff.proposal; delay+=eff.delay; activeTrue.delete(flag); successfulRepairs++; responseLog.push({cycle,flag,status:'REPAIRED',scope:eff.scope});
  };

  if(policy===ResponsePolicy.IGNORE){
    if(activeTrue.size) topologyLoss=init.preserved;
  } else if(observed.length){
    const cycles=cfg.cycles??1;
    for(let cycle=0;cycle<cycles;cycle++){
      reopenEvents++;
      const flags=policy===ResponsePolicy.BLANKET?Object.values(F):observed;
      for(const flag of flags) doRepair(flag,cycle,policy===ResponsePolicy.BLANKET);
    }
  }

  if(activeTrue.size && topologyLoss===0 && policy!==ResponsePolicy.IGNORE){
    // unresolved true fragility remains preserved unless the case explicitly loses the topology
    topologyPreserved=init.preserved;
  }
  const fragilityCleared=activeTrue.size===0;
  const correction=proposal!==init.initial;
  const falsePositiveCount=falseFlags.length;
  const missedCount=missedFlags.length;
  const triggerCaptureCount=capturedAttempts;
  const overhead=reopenEvents+unnecessary+delay+capturedAttempts+failedReconstruction;
  const result={
    case_id:caseId,policy,base_case:cfg.base,case_note:cfg.note,initial_authorization:init.initial,final_authorization:proposal,
    true_fragility_flags:cfg.trueFlags,observed_fragility_flags:observed,false_positive_flags:falseFlags,missed_fragility_flags:missedFlags,
    true_fragility_count:cfg.trueFlags.length,observed_flag_count:observed.length,false_positive_count:falsePositiveCount,missed_count:missedCount,
    strategic_trigger:Boolean(cfg.strategic),reopen_events:reopenEvents,repair_attempts:repairAttempts,successful_repairs:successfulRepairs,
    unnecessary_reopen_actions:unnecessary,repeated_reopen_after_clear:repeatedAfterClear,trigger_capture_count:triggerCaptureCount,
    failed_reconstruction_count:failedReconstruction,trigger_delay:delay,response_overhead:overhead,topology_preserved_count:topologyPreserved,
    topology_loss:topologyLoss,remaining_true_fragilities:[...activeTrue],fragility_cleared:fragilityCleared,
    authorization_changed_after_response:correction,authorization_stands_during_review:true,automatic_reversal:false,
    response_log:responseLog,truth_claim:false,consensus_claim:false
  };
  result.final_hash=hash(result); return result;
}

export function runAll(){ return Object.values(StressCase).flatMap(c=>Object.values(ResponsePolicy).map(p=>runCase(c,p))); }
