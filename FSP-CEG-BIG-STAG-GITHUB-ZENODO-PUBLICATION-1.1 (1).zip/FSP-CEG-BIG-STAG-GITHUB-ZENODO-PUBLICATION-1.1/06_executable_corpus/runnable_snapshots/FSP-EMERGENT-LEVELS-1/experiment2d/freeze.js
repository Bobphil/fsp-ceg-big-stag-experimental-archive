import fs from 'node:fs'; import path from 'node:path'; import crypto from 'node:crypto';
import { runAll } from './runner.js'; import { evaluate2D } from './invariants.js'; import { summarize } from './metrics.js';
const dir=path.resolve('results2d'); fs.rmSync(dir,{recursive:true,force:true}); fs.mkdirSync(dir,{recursive:true});
const sha=s=>crypto.createHash('sha256').update(s).digest('hex');
const runs=runAll(); const manifest=[];
for(const r of runs){ const name=`${r.case_id}__${r.policy}.json`; const body=JSON.stringify(r,null,2)+'\n'; fs.writeFileSync(path.join(dir,name),body); manifest.push({file:name,sha256:sha(body),final_hash:r.final_hash}); }
const inv=evaluate2D(runs); const summary=summarize(runs);
for(const [name,obj] of [['invariants.json',inv],['summary.json',summary]]){const body=JSON.stringify(obj,null,2)+'\n';fs.writeFileSync(path.join(dir,name),body);manifest.push({file:name,sha256:sha(body)});}
const mbody=JSON.stringify({experiment:'UCP-XR-EXPERIMENT-2D',frozen_before_interpretation:true,trace_count:runs.length,all_invariants_pass:inv.every(x=>x.pass),files:manifest},null,2)+'\n'; fs.writeFileSync(path.join(dir,'FREEZE-MANIFEST.json'),mbody);
console.log(JSON.stringify({trace_count:runs.length,all_invariants_pass:inv.every(x=>x.pass),summary},null,2));
