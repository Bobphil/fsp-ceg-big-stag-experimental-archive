import { runAll } from './runner.js';
export function summarize(runs=runAll()){
  const policies=[...new Set(runs.map(x=>x.policy))];
  return policies.map(policy=>{
    const xs=runs.filter(x=>x.policy===policy); const sum=k=>xs.reduce((a,x)=>a+(x[k]||0),0);
    return {policy,cases:xs.length,fragilities_cleared:xs.filter(x=>x.fragility_cleared).length,reopen_events:sum('reopen_events'),successful_repairs:sum('successful_repairs'),
      unnecessary_reopen_actions:sum('unnecessary_reopen_actions'),false_positive_flags:sum('false_positive_count'),missed_fragility_flags:sum('missed_count'),
      trigger_capture:sum('trigger_capture_count'),failed_reconstruction:sum('failed_reconstruction_count'),repeated_reopen_after_clear:sum('repeated_reopen_after_clear'),
      topology_loss:sum('topology_loss'),response_overhead:sum('response_overhead'),authorization_changes:xs.filter(x=>x.authorization_changed_after_response).length};
  });
}
