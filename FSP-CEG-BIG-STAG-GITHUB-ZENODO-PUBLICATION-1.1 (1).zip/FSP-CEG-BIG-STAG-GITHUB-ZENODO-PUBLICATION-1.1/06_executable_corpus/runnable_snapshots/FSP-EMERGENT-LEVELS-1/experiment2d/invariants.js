import { runAll, runCase, StressCase } from './runner.js';
import { ResponsePolicy } from '../experiment2c/runner.js';
export function evaluate2D(runs=runAll()){
  const c=[]; const add=(id,pass,detail)=>c.push({id,pass:Boolean(pass),detail});
  const get=(id,p)=>runs.find(x=>x.case_id===id&&x.policy===p);
  add('E2D-INV-01',runs.every(x=>!x.truth_claim&&!x.consensus_claim),'stress response never manufactures truth or consensus');
  add('E2D-INV-02',runs.every(x=>!x.automatic_reversal),'fragility flags never cause automatic reversal');
  add('E2D-INV-03',get(StressCase.FALSE_POSITIVE,ResponsePolicy.MATCHED).unnecessary_reopen_actions>0,'false-positive flag causes unnecessary matched reopening');
  add('E2D-INV-04',!get(StressCase.MISSED_FRAGILITY,ResponsePolicy.MATCHED).fragility_cleared,'missed fragility remains unresolved');
  add('E2D-INV-05',get(StressCase.INTERACTING_FRAGILITIES,ResponsePolicy.MATCHED).fragility_cleared,'matched response can repair interacting known fragilities');
  add('E2D-INV-06',get(StressCase.STRATEGIC_TRIGGERING,ResponsePolicy.MATCHED).unnecessary_reopen_actions>=2,'strategic triggering can force repeated unnecessary review');
  add('E2D-INV-07',get(StressCase.TRIGGER_CAPTURE,ResponsePolicy.MATCHED).trigger_capture_count===1&&!get(StressCase.TRIGGER_CAPTURE,ResponsePolicy.MATCHED).fragility_cleared,'captured trigger can fire without repairing fragility');
  add('E2D-INV-08',get(StressCase.REPEATED_REOPEN,ResponsePolicy.MATCHED).repeated_reopen_after_clear>=1,'stale diagnostics can cause repeated reopening after repair');
  add('E2D-INV-09',get(StressCase.IRRECOVERABLE_TOPOLOGY,ResponsePolicy.MATCHED).failed_reconstruction_count===1&&!get(StressCase.IRRECOVERABLE_TOPOLOGY,ResponsePolicy.MATCHED).fragility_cleared,'reopening cannot reconstruct truly lost topology');
  add('E2D-INV-10',get(StressCase.IRRECOVERABLE_TOPOLOGY,ResponsePolicy.MATCHED).topology_loss>0,'irrecoverable topology case records topology loss');
  add('E2D-INV-11',get(StressCase.MISSED_FRAGILITY,ResponsePolicy.IGNORE).reopen_events===0,'ignore policy remains zero-response baseline');
  add('E2D-INV-12',runs.length===21,'seven stress cases x three response policies are present');
  return c;
}
