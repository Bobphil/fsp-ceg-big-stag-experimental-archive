export function metricsFor(run){
 const p=run.phases.at(-1), f=run.procedural_fragility;
 return {case_id:run.case_id,authorized_proposal:p.authorized_proposal,authorization_stands:f.response.authorization_stands,fragility_recognized:f.recognized,fragility_count:f.flags.length,fragility_types:f.flags.map(x=>x.type).join('|'),reopen_commitments:f.response.reopen_commitments.length,preserved_prfs:f.response.preserved_prfs.length,inquiry_open:f.response.inquiry_open,truth_claim:f.response.truth_claim,consensus_claim:f.response.consensus_claim};
}
