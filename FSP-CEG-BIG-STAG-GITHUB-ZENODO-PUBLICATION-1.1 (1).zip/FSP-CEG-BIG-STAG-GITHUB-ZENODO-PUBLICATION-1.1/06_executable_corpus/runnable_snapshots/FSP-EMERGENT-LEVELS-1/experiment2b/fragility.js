import { Policy } from '../experiment2/model.js';

export const FragilityType=Object.freeze({
  VOTE_SPLIT:'VOTE_SPLIT', AGENDA_DEPENDENCE:'AGENDA_DEPENDENCE', LOW_PARTICIPATION:'LOW_PARTICIPATION', BLOC_CONCENTRATION:'BLOC_CONCENTRATION'
});

export function diagnoseFragility(run){
  const p=run.phases.at(-1); const flags=[];
  if(p.proposal_family_mismatch || (p.largest_family_votes>p.winner_votes && p.largest_family!==p.authorized_family)) flags.push({type:FragilityType.VOTE_SPLIT,severity:'HIGH',basis:'largest substantive family differs from authorized proposal family'});
  if(run.control_winner && run.control_winner!==p.authorized_proposal) flags.push({type:FragilityType.AGENDA_DEPENDENCE,severity:'HIGH',basis:'authorized proposal changes under agenda exclusion'});
  const participation=p.electorate? p.votes_cast/p.electorate:1;
  if(participation<0.75) flags.push({type:FragilityType.LOW_PARTICIPATION,severity:participation<0.6?'HIGH':'MODERATE',basis:'authorization rests on low electorate participation'});
  if(p.coordinated_bloc_size>0 && p.coordinated_bloc_votes_for_winner===p.winner_votes && p.winner_votes>0) flags.push({type:FragilityType.BLOC_CONCENTRATION,severity:'HIGH',basis:'coordinated bloc supplies entire winning plurality'});
  return flags;
}

export function topologyResponse(run,flags){
  const p=run.phases.at(-1); const preserve=new Set(p.minority_archive.map(x=>x.prf_id));
  const reopen=[];
  for(const f of flags){
    if(f.type===FragilityType.VOTE_SPLIT) reopen.push({trigger:'PROPOSAL_FAMILY_RECOUNT_OR_REFORMULATION',scope:'affected action family',automatic_reversal:false});
    if(f.type===FragilityType.AGENDA_DEPENDENCE) reopen.push({trigger:'AGENDA_REINTRODUCTION_OR_ALTERNATIVE_PROPOSAL',scope:'excluded family and affected PRFs',automatic_reversal:false});
    if(f.type===FragilityType.LOW_PARTICIPATION) reopen.push({trigger:'PARTICIPATION_RECOVERY_OR_NEW_RETURN',scope:'nonparticipating and affected PRFs',automatic_reversal:false});
    if(f.type===FragilityType.BLOC_CONCENTRATION) reopen.push({trigger:'INDEPENDENT_RETURN_OR_BLOC_DECOUPLING',scope:'winner and adjacent alternatives',automatic_reversal:false});
  }
  return {authorization_stands:true,fragility_flags:flags,preserved_prfs:[...preserve],reopen_commitments:reopen,action_closure:true,inquiry_open:true,truth_claim:false,consensus_claim:false};
}
