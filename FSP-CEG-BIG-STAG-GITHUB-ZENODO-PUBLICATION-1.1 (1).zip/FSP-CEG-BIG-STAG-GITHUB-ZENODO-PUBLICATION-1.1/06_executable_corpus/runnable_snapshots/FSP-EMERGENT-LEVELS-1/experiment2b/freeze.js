import fs from 'node:fs'; import path from 'node:path'; import crypto from 'node:crypto';
import {runAll} from './runner.js'; import {metricsFor} from './metrics.js'; import {evaluate2B} from './invariants.js';
const outDir=new URL('../results2b/',import.meta.url); fs.mkdirSync(outDir,{recursive:true});
const sha=s=>crypto.createHash('sha256').update(s).digest('hex'); const runs=runAll(); const manifest=[];
for(const r of runs){const txt=JSON.stringify(r,null,2)+'\n'; const file=`${r.case_id}.json`; fs.writeFileSync(new URL(file,outDir),txt); manifest.push({file,sha256:sha(txt)});}
const metrics=runs.map(metricsFor); fs.writeFileSync(new URL('metrics.json',outDir),JSON.stringify(metrics,null,2)+'\n');
const inv=evaluate2B(runs); fs.writeFileSync(new URL('invariants.json',outDir),JSON.stringify(inv,null,2)+'\n');
fs.writeFileSync(new URL('FREEZE-MANIFEST.json',outDir),JSON.stringify({experiment:'2B',files:manifest,all_invariants_pass:inv.every(x=>x.pass)},null,2)+'\n');
console.log(JSON.stringify({runs:runs.length,all_invariants_pass:inv.every(x=>x.pass),metrics,manifest},null,2));
