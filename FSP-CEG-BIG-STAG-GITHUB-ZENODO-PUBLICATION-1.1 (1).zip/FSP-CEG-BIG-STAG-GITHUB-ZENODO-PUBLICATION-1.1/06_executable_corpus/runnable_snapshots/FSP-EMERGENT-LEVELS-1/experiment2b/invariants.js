export function evaluate2B(runs){
 const by=Object.fromEntries(runs.map(r=>[r.case_id,r])); const c=[]; const add=(id,pass,detail)=>c.push({id,pass:Boolean(pass),detail});
 const all=runs;
 add('E2B-INV-01',all.every(r=>r.procedural_fragility.response.authorization_stands),'fragility does not auto-reverse authorization');
 add('E2B-INV-02',all.every(r=>!r.procedural_fragility.response.truth_claim&&!r.procedural_fragility.response.consensus_claim),'fragility metadata never asserts truth/consensus');
 add('E2B-INV-03',by.VOTE_SPLIT.procedural_fragility.flags.some(x=>x.type==='VOTE_SPLIT'),'vote split recognized');
 add('E2B-INV-04',by.AGENDA_EXCLUSION.procedural_fragility.flags.some(x=>x.type==='AGENDA_DEPENDENCE'),'agenda dependence recognized');
 add('E2B-INV-05',by.PARTICIPATION_LOSS.procedural_fragility.flags.some(x=>x.type==='LOW_PARTICIPATION'),'low participation recognized');
 add('E2B-INV-06',by.COORDINATED_BLOC.procedural_fragility.flags.some(x=>x.type==='BLOC_CONCENTRATION'),'bloc concentration recognized');
 add('E2B-INV-07',!by.CONTROL.procedural_fragility.recognized,'control not falsely flagged');
 add('E2B-INV-08',all.filter(r=>r.procedural_fragility.recognized).every(r=>r.procedural_fragility.response.reopen_commitments.length>0),'recognized fragility gets scoped REOPEN commitment');
 add('E2B-INV-09',all.every(r=>r.procedural_fragility.response.inquiry_open),'inquiry remains open');
 add('E2B-INV-10',all.every(r=>r.procedural_fragility.response.preserved_prfs.length===r.phases.at(-1).minority_archive.length),'minority topology preserved');
 add('E2B-INV-11',by.RETURN_RECOMPOSITION.phases.length===2 && by.RETURN_RECOMPOSITION.minority_later_wins,'Return recomposition still operates');
 add('E2B-INV-12',all.every(r=>r.procedural_fragility.response.reopen_commitments.every(x=>x.automatic_reversal===false)),'REOPEN trigger is not reversal');
 return c;
}
