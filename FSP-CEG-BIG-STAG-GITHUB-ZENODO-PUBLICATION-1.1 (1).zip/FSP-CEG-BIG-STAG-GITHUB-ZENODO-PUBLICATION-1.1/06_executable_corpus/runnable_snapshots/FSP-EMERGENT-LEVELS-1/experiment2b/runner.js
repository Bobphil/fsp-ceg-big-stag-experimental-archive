import crypto from 'node:crypto';
import { runCase as run2ACase, runAll as run2AAll } from '../experiment2a/runner.js';
import { diagnoseFragility, topologyResponse } from './fragility.js';
const hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
export function runCase(caseId){
  const base=run2ACase(caseId); const flags=diagnoseFragility(base); const response=topologyResponse(base,flags);
  const out={...base,procedural_fragility:{recognized:flags.length>0,flags,response}}; out.final_hash=hash(out); return out;
}
export function runAll(){ return run2AAll().map(r=>runCase(r.case_id)); }
