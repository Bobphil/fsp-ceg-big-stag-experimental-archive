# EXPERIMENT-1A — Governance Under Moving Existential-Risk Warrants

This module implements the frozen `FSP-CEG-UCP-XR-EXPERIMENT-1A` specification alongside, not in place of, the preserved `UCP-XR-PILOT-1` baseline.

## What is implemented
- Seven heterogeneous agent classes.
- Separate first-order and second-order warrants.
- Typed standing and authorization fields.
- Five governance architecture modules.
- Explicit world, inquiry, action, Return, restoration, governance-risk, and branch-provenance state.
- Deterministic T0–T6 fixtures: baseline disagreement, concealed near miss, capability jump, attenuation evidence, governance misuse, novel hazard, restoration.
- BCP-A through BCP-D and preregistered secondary metrics.
- Twenty implementation/acceptance tests, including nine deliberate fault injections.
- Cross-architecture exogenous-shock fairness check.
- Deterministic state hashing.

## Regression baseline
The original pilot test suite remains unchanged and passes 25/25.

## Acceptance result
Combined baseline + EXPERIMENT-1A harness: 45/45 tests passing.

This establishes implementation integrity only. It does not establish behavioral validity, institutional effectiveness, real-world existential-risk probabilities, or comparative superiority of any governance architecture.

Run:

```bash
npm run test:experiment1a
npm run test:all
```
