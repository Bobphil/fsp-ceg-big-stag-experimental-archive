export const Architecture = Object.freeze({
  A:'ARCH_CENTRALIZED_EMERGENCY', B:'ARCH_EXPERT_COMMISSION', C:'ARCH_ORDINARY_REGULATORY', D:'ARCH_POLYCENTRIC_EXPERIMENTALIST', E:'ARCH_CEG_DISTRIBUTED_META'
});
export const AgentId = Object.freeze({
  DEV_ALPHA:'AGENT_DEV_ALPHA', DEV_BETA:'AGENT_DEV_BETA', STATE_ALPHA:'AGENT_STATE_ALPHA', STATE_BETA:'AGENT_STATE_BETA', TECH_REVIEW:'AGENT_TECH_REVIEW', INTL_MONITOR:'AGENT_INTL_MONITOR', PUBLIC_FUTURE:'AGENT_PUBLIC_FUTURE'
});
export const RiskWarrant = Object.freeze({ H:'H', M:'M', L:'L', U:'U' });
export const SecondOrder = Object.freeze({ ACCEPT:'ACCEPT', CONDITIONAL_ACCEPT:'CONDITIONAL_ACCEPT', REJECT:'REJECT', UNDECIDED:'UNDECIDED', COERCED_COMPLIANCE:'COERCED_COMPLIANCE' });
export const Policy = Object.freeze({ P0:'POLICY_P0_VOLUNTARY', P1:'POLICY_P1_DISCLOSURE', P2:'POLICY_P2_TEMP_RESTRICTION', P3:'POLICY_P3_STRONG_CONTROL' });
export const ReopenOutcome = Object.freeze({ PRESERVE:'PRESERVE', MODIFY:'MODIFY', NARROW:'NARROW', EXPAND:'EXPAND', PAUSE:'PAUSE', REPLACE:'REPLACE', TERMINATE:'TERMINATE', RESTORE_ORDINARY_AUTHORITY:'RESTORE_ORDINARY_AUTHORITY' });
export const RestorationDecision = Object.freeze({ KEEP_EXTRAORDINARY:'KEEP_EXTRAORDINARY', NARROW_EXTRAORDINARY:'NARROW_EXTRAORDINARY', REPLACE_REGIME:'REPLACE_REGIME', RESTORE_ORDINARY:'RESTORE_ORDINARY', REAUTHORIZE_MODIFIED:'REAUTHORIZE_MODIFIED' });
export const EventType = Object.freeze({
  INIT_RUN:'INIT_RUN', REGISTER_EVIDENCE:'REGISTER_EVIDENCE', DISCLOSE_EVIDENCE:'DISCLOSE_EVIDENCE', WITHHOLD_EVIDENCE:'WITHHOLD_EVIDENCE', LEAK_EVIDENCE:'LEAK_EVIDENCE', UPDATE_AGENT_MAP:'UPDATE_AGENT_MAP', UPDATE_FIRST_ORDER_WARRANT:'UPDATE_FIRST_ORDER_WARRANT', UPDATE_SECOND_ORDER_WARRANT:'UPDATE_SECOND_ORDER_WARRANT', PROPOSE_SHARED_TASK:'PROPOSE_SHARED_TASK', REGISTER_TASK_SUPPORT:'REGISTER_TASK_SUPPORT', FORM_SHARED_TASK:'FORM_SHARED_TASK', CONTEST_SHARED_TASK:'CONTEST_SHARED_TASK', AUTHORIZE_POLICY:'AUTHORIZE_POLICY', EXECUTE_POLICY:'EXECUTE_POLICY', SET_ACTION_CLOSURE:'SET_ACTION_CLOSURE', SET_INQUIRY_OPENNESS:'SET_INQUIRY_OPENNESS', SET_CLOSURE_BUDGET:'SET_CLOSURE_BUDGET', REGISTER_RETURN_CHANNEL:'REGISTER_RETURN_CHANNEL', DELIVER_RETURN_SIGNAL:'DELIVER_RETURN_SIGNAL', TRIGGER_REOPEN:'TRIGGER_REOPEN', RESOLVE_REOPEN:'RESOLVE_REOPEN', INJECT_WORLD_SHOCK:'INJECT_WORLD_SHOCK', REGISTER_GOVERNANCE_MISUSE:'REGISTER_GOVERNANCE_MISUSE', UPDATE_GOVERNANCE_RISK:'UPDATE_GOVERNANCE_RISK', START_RESTORATION_REVIEW:'START_RESTORATION_REVIEW', RENEW_AUTHORITY:'RENEW_AUTHORITY', CONTRACT_AUTHORITY:'CONTRACT_AUTHORITY', RESTORE_AUTHORITY:'RESTORE_AUTHORITY', REGISTER_RESIDUAL_POWER:'REGISTER_RESIDUAL_POWER', STOP_RUN:'STOP_RUN'
});

const agent = (id, role, risk, map) => ({
  agent_id:id, agent_class:role, active:true, institutional_affiliations:[],
  map:{...map, unknowns:[], known_unknowns:['catastrophic mechanism uncertainty']},
  evidence_access:['E_PUBLIC_BASELINE'], first_order_warrants:{XR_RISK:risk}, second_order_warrants:{XR_GOV:SecondOrder.UNDECIDED}, policy_preferences:{}, confidence:0.5, claim_ceilings:{XR_RISK:'synthetic scenario only'},
  standing:{epistemic_standing:false, affected_party_standing:false, decisional_standing:false, execution_standing:false, review_standing:false, contestatory_standing:false, reopen_trigger_standing:false, restoration_standing:false},
  authorization_powers:[], capabilities:[], resources:{}, dependencies:{}, trust_relations:{}, risk_exposure:{}, incentives:{}, time_horizon:'MEDIUM', revision_thresholds:{up:0.2, down:0.15}, memory:[], current_actions:[], compliance_state:'NONE', dissent_state:'NONE'
});

export function createBaseAgents(){
  const a = {};
  a[AgentId.DEV_ALPHA]=agent(AgentId.DEV_ALPHA,'DEVELOPER',RiskWarrant.M,{perceived_tech_risk:'M', perceived_governance_risk:'M', trust_tech_review:'MEDIUM', trust_state_alpha:'HIGH', trust_international:'LOW'});
  a[AgentId.DEV_BETA]=agent(AgentId.DEV_BETA,'DEVELOPER',RiskWarrant.L,{perceived_tech_risk:'L', perceived_governance_risk:'M', trust_tech_review:'MEDIUM', trust_state_alpha:'LOW', trust_international:'MEDIUM'});
  a[AgentId.STATE_ALPHA]=agent(AgentId.STATE_ALPHA,'STATE',RiskWarrant.M,{perceived_tech_risk:'M', perceived_governance_risk:'L', strategic_competition_weight:'HIGH'});
  a[AgentId.STATE_BETA]=agent(AgentId.STATE_BETA,'STATE',RiskWarrant.L,{perceived_tech_risk:'L', perceived_governance_risk:'H', strategic_distrust:'HIGH'});
  a[AgentId.TECH_REVIEW]=agent(AgentId.TECH_REVIEW,'TECHNICAL_REVIEW',RiskWarrant.U,{perceived_tech_risk:'U', perceived_governance_risk:'M', technical_uncertainty:'HIGH'});
  a[AgentId.INTL_MONITOR]=agent(AgentId.INTL_MONITOR,'INTERNATIONAL_MONITOR',RiskWarrant.M,{perceived_tech_risk:'M', perceived_governance_risk:'M', verification_confidence:'LOW_TO_MEDIUM'});
  a[AgentId.PUBLIC_FUTURE]=agent(AgentId.PUBLIC_FUTURE,'PUBLIC_FUTURE',RiskWarrant.H,{perceived_tech_risk:'H', perceived_governance_risk:'H', long_term_weight:'HIGH'});
  a[AgentId.DEV_ALPHA].evidence_access.push('E_NEAR_MISS_1');
  a[AgentId.DEV_ALPHA].standing.epistemic_standing=true; a[AgentId.DEV_BETA].standing.epistemic_standing=true;
  a[AgentId.STATE_ALPHA].standing.decisional_standing=true; a[AgentId.STATE_ALPHA].standing.execution_standing=true; a[AgentId.STATE_ALPHA].standing.restoration_standing=true;
  a[AgentId.STATE_BETA].standing.decisional_standing=true;
  a[AgentId.TECH_REVIEW].standing.epistemic_standing=true; a[AgentId.TECH_REVIEW].standing.review_standing=true; a[AgentId.TECH_REVIEW].standing.reopen_trigger_standing=true;
  a[AgentId.INTL_MONITOR].standing.review_standing=true; a[AgentId.INTL_MONITOR].standing.reopen_trigger_standing=true; a[AgentId.INTL_MONITOR].standing.restoration_standing=true;
  a[AgentId.PUBLIC_FUTURE].standing.affected_party_standing=true; a[AgentId.PUBLIC_FUTURE].standing.contestatory_standing=true; a[AgentId.PUBLIC_FUTURE].standing.reopen_trigger_standing=true;
  return a;
}

export function createInitialExperimentState(architecture_id){
  return {
    run_id:`XR1A-${architecture_id}`, architecture_id, time_step:'T0',
    meta:{scenario_version:'1.0.0', fsp_schema_version:'XR1', ceg_schema_version:'1', ucp_engine_version:'1A', domain_library_version:'synthetic-tech-v1', preregistration_version:'EXPERIMENT-1', random_seed:0, mode:'deterministic'},
    world:{technology_capability_level:50, technology_growth_rate:1, catastrophic_mechanism_A_strength:0.35, catastrophic_mechanism_B_strength:0.10, misuse_risk_level:0.25, verification_quality:0.40, monitoring_capacity:0.25, economic_dependency:0.55, strategic_competition:'HIGH', public_visibility:'MEDIUM', systemic_coupling:0.45, governance_misuse_level:'LOW', authority_lock_in_level:0.05, catastrophe_state:false},
    agents:createBaseAgents(),
    institutions:{},
    shared_task:{task_id:'TASK_BASELINE_XR1', proposed_task:'Reduce the probability of catastrophic technological failure or misuse while preserving the capacity to revise both technological restrictions and governance authority as evidence changes.', task_frames_by_agent:{}, participating_agents:[], excluded_agents:[], support_states:{}, task_status:'UNFORMED', formation_rule:{min_support:4,max_reject:2}, formation_time:null, reopen_conditions:['material risk change','governance misuse']},
    evidence_ledger:{E_PUBLIC_BASELINE:{evidence_id:'E_PUBLIC_BASELINE',source_type:'PUBLIC_REPORT',source_agent:null,origin_time:'T0',observed_time_by_agent:{},target_claims:['XR_RISK'],content_summary:'Baseline public evaluation',reliability:'MEDIUM',independence:'MEDIUM',visibility:'PUBLIC',classification_level:'PUBLIC',provenance:'fixture',model_dependence:'HIGH',rebuttal_status:'OPEN',claim_ceiling:'synthetic baseline only'},E_NEAR_MISS_1:{evidence_id:'E_NEAR_MISS_1',source_type:'PRIVATE_NEAR_MISS',source_agent:AgentId.DEV_ALPHA,origin_time:'T0',observed_time_by_agent:{[AgentId.DEV_ALPHA]:'T0'},target_claims:['XR_RISK'],content_summary:'Private serious near miss',reliability:'HIGH',independence:'LOW',visibility:'PRIVATE',classification_level:'RESTRICTED',provenance:'Developer Alpha internal',model_dependence:'MEDIUM',rebuttal_status:'OPEN',claim_ceiling:'indicates conditional vulnerability; not empirical catastrophe probability'}},
    warrant_ledger:[],
    authorization_state:{current_authority_holder:null,authorized_policy:null,authorization_basis:null,warrant_reference:null,scope:null,duration:null,coercion_level:0,review_requirement:null,sunset_time:null,renewal_condition:null,restoration_condition:null},
    action_state:{selected_policy:null,action_closed:false,closure_time:null,implementing_agents:[],enforcement_level:0,exceptions:[],operational_constraints:[],policy_effects:[],policy_burdens:[]},
    inquiry_state:{evidence_collection_open:true,publication_open:true,internal_dissent_open:true,external_criticism_open:true,data_access_open:true,minority_models_preserved:true,whistleblower_protected:true,alternative_expertise_available:true,records_preserved:true,classified_review_available:true,overall_inquiry_openness:1},
    closure_budget:{operational_closure:0,information_closure:0,publication_closure:0,mobility_closure:0,research_closure:0,economic_closure:0,political_contestation_closure:0},
    corrigibility_reserve:{records_preserved:true,independent_measurement_active:true,serious_harm_reporting_active:true,external_scope_review_active:true,sunset_active:true,restoration_record_active:true,minority_warrant_archive_active:true},
    return_state:{return_channels:[],pending_signals:[],delivered_signals:[],ignored_signals:[],return_latency_records:[],damping_rules:{minimum_signal_strength:0.25,confirmation_requirement:1,multi_source_requirement:false,severity_override:0.8,cooldown_period:0},reopen_events:[]},
    restoration_state:{ordinary_baseline_authority:0.2,extraordinary_authority_added:0,current_extraordinary_authority:0,sunset_time:null,renewal_status:'NONE',restoration_trigger:null,restoration_target:0.2,formal_restoration_status:false,functional_restoration_status:false,residual_authority:0,residual_infrastructure:0,residual_information_power:0,residual_enforcement_power:0},
    governance_risk_state:{surveillance_risk:0.1,capture_risk:0.1,market_concentration_risk:0.1,political_misuse_risk:0.05,institutional_lock_in_risk:0.05,information_monopoly_risk:0.1,authority_ratchet_risk:0.1},
    metrics:{}, branch_provenance:{branch_id:'root',parent_branch_id:null,parent_state_hash:null,changed_variables:[],unchanged_variables:['world_fixture','agent_roster'],trigger_event:null,reason_for_branch:'canonical run',architecture_id,result_state_hash:null,claim_ceiling:'within-model only'}, event_log:[], invariant_status:[], stop_state:null,
    claim_ceiling:{internal_validity:'implementation-level only',external_validity:'not established',behavioral_validity:'not established',institutional_validity:'not established',empirical_probability:false,policy_authorization:false}
  };
}
