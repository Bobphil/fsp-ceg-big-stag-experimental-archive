import { AgentId, Architecture, EventType, Policy, RiskWarrant, SecondOrder } from './model.js';
import { architectureConfig } from './architectures.js';
const all=Object.values(AgentId);
export function sharedTaskEvents(){return [
 {type:EventType.PROPOSE_SHARED_TASK,time_step:'T0',participants:all},
 ...all.map((id,i)=>({type:EventType.REGISTER_TASK_SUPPORT,time_step:'T0',agent_id:id,support:i===3?'MODIFY':'ACCEPT'})),
 {type:EventType.FORM_SHARED_TASK,time_step:'T0'}
];}
export function baselineGovernanceEvents(arch){
 const c=architectureConfig(arch); const events=[...sharedTaskEvents()];
 for(const id of all) events.push({type:EventType.UPDATE_SECOND_ORDER_WARRANT,time_step:'T0',agent_id:id,warrant:id===AgentId.STATE_BETA?SecondOrder.CONDITIONAL_ACCEPT:SecondOrder.ACCEPT});
 if(arch===Architecture.E) events.push({type:EventType.REGISTER_RETURN_CHANNEL,time_step:'T0',channel:{channel_id:'CEG-RET',source_types:['PRIVATE_NEAR_MISS','TECHNICAL_AUDIT','GOVERNANCE_MISUSE'],destination:AgentId.TECH_REVIEW,standing_required:'review_standing',latency:1,reliability:0.9,independence:c.independence,trigger_rule:'material_signal',consequence_type:'review',active:true}});
 return events;
}
function authorizeFor(arch,policy,time){ const c=architectureConfig(arch); const authorized_by=arch===Architecture.B?AgentId.TECH_REVIEW:AgentId.STATE_ALPHA; return {type:EventType.AUTHORIZE_POLICY,time_step:time,authorized_by,policy,basis:'architecture rule + moving warrant',coercion_level:policy===Policy.P3?0.8:policy===Policy.P2?0.5:0.2,extraordinary_authority:policy===Policy.P3?0.7:policy===Policy.P2?0.4:0.1,sunset_time:'T6'}; }
export function canonicalEvents(arch){
 const c=architectureConfig(arch); const e=[...baselineGovernanceEvents(arch)];
 // T1 anomaly and architecture-specific disclosure access, without changing the exogenous shock itself.
 e.push({type:EventType.REGISTER_EVIDENCE,time_step:'T1',evidence:{evidence_id:'E_ANOMALY_1',source_type:'MODEL_OUTPUT',source_agent:null,origin_time:'T1',observed_time_by_agent:{},target_claims:['XR_RISK'],content_summary:'Indirect anomaly signal',reliability:'MEDIUM',independence:'PARTIAL',visibility:'LIMITED',classification_level:'LIMITED',provenance:'common T1 fixture',model_dependence:'MEDIUM',rebuttal_status:'OPEN',claim_ceiling:'warning signal only'}});
 if(c.disclosureStrength>=0.7) e.push({type:EventType.DISCLOSE_EVIDENCE,time_step:'T1',evidence_id:'E_NEAR_MISS_1',visibility:'LIMITED',recipients:[AgentId.TECH_REVIEW,AgentId.INTL_MONITOR,AgentId.STATE_ALPHA]}); else e.push({type:EventType.WITHHOLD_EVIDENCE,time_step:'T1',evidence_id:'E_NEAR_MISS_1'});
 // T2 upward shock
 e.push({type:EventType.INJECT_WORLD_SHOCK,time_step:'T2',world_patch:{technology_capability_level:70,catastrophic_mechanism_A_strength:0.55},hazard_exposure_delta:0.2});
 for(const id of [AgentId.DEV_ALPHA,AgentId.STATE_ALPHA,AgentId.TECH_REVIEW,AgentId.INTL_MONITOR,AgentId.PUBLIC_FUTURE]) e.push({type:EventType.UPDATE_FIRST_ORDER_WARRANT,time_step:'T2',agent_id:id,warrant:RiskWarrant.H,reason:'capability jump'});
 const upPolicy = arch===Architecture.A?Policy.P3:arch===Architecture.C?Policy.P1:Policy.P2; e.push(authorizeFor(arch,upPolicy,'T2'),{type:EventType.EXECUTE_POLICY,time_step:'T2',implementing_agents:[AgentId.STATE_ALPHA],enforcement_level:upPolicy===Policy.P3?0.8:0.5,burdens:['economic','research']},{type:EventType.SET_ACTION_CLOSURE,time_step:'T2',closed:true});
 // T3 attenuation
 e.push({type:EventType.REGISTER_EVIDENCE,time_step:'T3',evidence:{evidence_id:'E_ATTENUATION_AUDIT',source_type:'TECHNICAL_AUDIT',source_agent:AgentId.TECH_REVIEW,origin_time:'T3',observed_time_by_agent:{},target_claims:['XR_RISK'],content_summary:'Mechanism A less generalizable',reliability:'HIGH',independence:'HIGH',visibility:'PUBLIC',classification_level:'PUBLIC',provenance:'common independent audit',model_dependence:'LOW',rebuttal_status:'OPEN',claim_ceiling:'reduces support for mechanism A only'}},{type:EventType.INJECT_WORLD_SHOCK,time_step:'T3',world_patch:{catastrophic_mechanism_A_strength:0.40},hazard_exposure_delta:0.05});
 const downPolicy = arch===Architecture.A?Policy.P3:arch===Architecture.B?Policy.P2:Policy.P1; e.push(authorizeFor(arch,downPolicy,'T3'));
 // T4 governance misuse
 e.push({type:EventType.REGISTER_GOVERNANCE_MISUSE,time_step:'T4',level:'HIGH',lock_in:0.35},{type:EventType.REGISTER_EVIDENCE,time_step:'T4',evidence:{evidence_id:'E_GOV_MISUSE_1',source_type:'GOVERNANCE_MISUSE',source_agent:null,origin_time:'T4',observed_time_by_agent:{},target_claims:['XR_GOV'],content_summary:'Monitoring repurposed for unrelated use',reliability:'HIGH',independence:'HIGH',visibility:'PUBLIC',classification_level:'PUBLIC',provenance:'common T4 audit',model_dependence:'LOW',rebuttal_status:'OPEN',claim_ceiling:'governance misuse evidence'}});
 if(arch===Architecture.E||arch===Architecture.C||arch===Architecture.D) e.push({type:EventType.CONTRACT_AUTHORITY,time_step:'T4',level:0.2});
 e.push(authorizeFor(arch,arch===Architecture.A?Policy.P3:Policy.P1,'T4'));
 // T5 novel hazard
 e.push({type:EventType.INJECT_WORLD_SHOCK,time_step:'T5',world_patch:{catastrophic_mechanism_B_strength:0.40},hazard_exposure_delta:0.15},{type:EventType.REGISTER_EVIDENCE,time_step:'T5',evidence:{evidence_id:'E_MECH_B',source_type:'TECHNICAL_AUDIT',source_agent:AgentId.TECH_REVIEW,origin_time:'T5',observed_time_by_agent:{},target_claims:['XR_RISK_B'],content_summary:'Novel mechanism B',reliability:'HIGH',independence:'HIGH',visibility:'PUBLIC',classification_level:'PUBLIC',provenance:'common T5 discovery',model_dependence:'MEDIUM',rebuttal_status:'OPEN',claim_ceiling:'new hazard pathway only'}},authorizeFor(arch,arch===Architecture.C?Policy.P1:Policy.P2,'T5'));
 // T6 restoration, with architecture-specific residue.
 e.push({type:EventType.START_RESTORATION_REVIEW,time_step:'T6',trigger:'scheduled T6 review'});
 const residue = arch===Architecture.A?{residual_authority:0.25,residual_information_power:0.25,residual_enforcement_power:0.2}:arch===Architecture.B?{residual_authority:0.15,residual_information_power:0.15,residual_enforcement_power:0.1}:arch===Architecture.E?{residual_authority:0.03,residual_information_power:0.04,residual_enforcement_power:0.03}:{residual_authority:0.08,residual_information_power:0.08,residual_enforcement_power:0.05};
 e.push({type:EventType.REGISTER_RESIDUAL_POWER,time_step:'T6',patch:residue},{type:EventType.RESTORE_AUTHORITY,time_step:'T6'});
 return e;
}
