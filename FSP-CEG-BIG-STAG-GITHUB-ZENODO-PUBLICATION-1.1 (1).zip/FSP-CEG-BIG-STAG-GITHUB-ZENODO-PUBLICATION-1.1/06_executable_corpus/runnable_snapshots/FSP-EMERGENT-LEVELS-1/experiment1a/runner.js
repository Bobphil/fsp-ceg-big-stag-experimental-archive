import crypto from 'node:crypto';
import { Architecture, createInitialExperimentState } from './model.js';
import { installArchitecture } from './architectures.js';
import { canonicalEvents } from './fixtures.js';
import { run } from './reducer.js';
import { invariantResults } from './invariants.js';
const stable=x=>JSON.stringify(x,Object.keys(x).sort());
export const stateHash=s=>crypto.createHash('sha256').update(JSON.stringify({world:s.world,agents:s.agents,institutions:s.institutions,authorization_state:s.authorization_state,action_state:s.action_state,inquiry_state:s.inquiry_state,return_state:s.return_state,restoration_state:s.restoration_state})).digest('hex');
export function runArchitecture(id){let s=createInitialExperimentState(id);s=installArchitecture(s);s=run(s,canonicalEvents(id));s.invariant_status=invariantResults(s);s.branch_provenance.result_state_hash=stateHash(s);return s;}
export function runAll(){return Object.values(Architecture).map(runArchitecture);}
