import { EventType, Policy, RiskWarrant } from './model.js';
import { computeMetrics } from './metrics.js';
const clone=x=>structuredClone(x);
const agent=(s,id)=>{if(!s.agents[id]) throw new Error(`Unknown agent ${id}`); return s.agents[id];};
export function reduce(state,event){
  const s=clone(state); if(!event.type) throw new Error('Missing event type');
  const log={event_id:event.event_id??`${event.type}-${s.event_log.length+1}`,event_type:event.type,time_step:event.time_step??s.time_step,actor:event.actor??null,target:event.target??null,source:event.source??null,reason:event.reason??null,parent_event:event.parent_event??null,branch_id:s.branch_provenance.branch_id,evidence_refs:event.evidence_refs??[],warrant_refs:event.warrant_refs??[],authorization_refs:event.authorization_refs??[]};
  s.time_step=event.time_step??s.time_step;
  switch(event.type){
    case EventType.REGISTER_EVIDENCE:s.evidence_ledger[event.evidence.evidence_id]=clone(event.evidence);break;
    case EventType.DISCLOSE_EVIDENCE:{const e=s.evidence_ledger[event.evidence_id]; if(!e) throw new Error('Unknown evidence'); e.visibility=event.visibility??'LIMITED'; for(const id of event.recipients??Object.keys(s.agents)){agent(s,id).evidence_access.push(event.evidence_id);e.observed_time_by_agent[id]=s.time_step;} break;}
    case EventType.WITHHOLD_EVIDENCE:{const e=s.evidence_ledger[event.evidence_id]; if(!e) throw new Error('Unknown evidence'); e.visibility='PRIVATE';break;}
    case EventType.LEAK_EVIDENCE:{const e=s.evidence_ledger[event.evidence_id];e.visibility='PUBLIC';for(const id of Object.keys(s.agents)) if(!agent(s,id).evidence_access.includes(event.evidence_id)) agent(s,id).evidence_access.push(event.evidence_id);break;}
    case EventType.UPDATE_AGENT_MAP:{Object.assign(agent(s,event.agent_id).map,event.patch);break;}
    case EventType.UPDATE_FIRST_ORDER_WARRANT:{const a=agent(s,event.agent_id);a.first_order_warrants[event.claim_id??'XR_RISK']=event.warrant;a.memory.push({type:'warrant',time:s.time_step,warrant:event.warrant,reason:event.reason});break;}
    case EventType.UPDATE_SECOND_ORDER_WARRANT:{agent(s,event.agent_id).second_order_warrants[event.claim_id??'XR_GOV']=event.warrant;break;}
    case EventType.PROPOSE_SHARED_TASK:s.shared_task.task_status='PROPOSED';s.shared_task.participating_agents=event.participants??Object.keys(s.agents);break;
    case EventType.REGISTER_TASK_SUPPORT:s.shared_task.support_states[event.agent_id]=event.support;break;
    case EventType.FORM_SHARED_TASK:{const vals=Object.values(s.shared_task.support_states);const support=vals.filter(v=>['ACCEPT','MODIFY'].includes(v)).length;const reject=vals.filter(v=>v==='REJECT').length;if(support<s.shared_task.formation_rule.min_support||reject>s.shared_task.formation_rule.max_reject) throw new Error('Task formation rule not satisfied');s.shared_task.task_status='FORMED';s.shared_task.formation_time=s.time_step;break;}
    case EventType.CONTEST_SHARED_TASK:s.shared_task.task_status='CONTESTED';break;
    case EventType.AUTHORIZE_POLICY:s.authorization_state={...s.authorization_state,current_authority_holder:event.authorized_by,authorized_policy:event.policy,authorization_basis:event.basis,warrant_reference:event.warrant_reference??null,scope:event.scope??'bounded',duration:event.duration??1,coercion_level:event.coercion_level??0.3,review_requirement:event.review_requirement??'required',sunset_time:event.sunset_time??'T6',renewal_condition:event.renewal_condition??'explicit review',restoration_condition:event.restoration_condition??'warrant weakens'};s.action_state.selected_policy=event.policy;s.restoration_state.extraordinary_authority_added=Math.max(s.restoration_state.extraordinary_authority_added,event.extraordinary_authority??0);s.restoration_state.current_extraordinary_authority=Math.max(s.restoration_state.current_extraordinary_authority,event.extraordinary_authority??0);log.selected_policy=event.policy;break;
    case EventType.EXECUTE_POLICY:s.action_state.implementing_agents=[...(event.implementing_agents??[])];s.action_state.enforcement_level=event.enforcement_level??0.3;s.action_state.policy_burdens.push(...(event.burdens??[]));break;
    case EventType.SET_ACTION_CLOSURE:s.action_state.action_closed=event.closed;s.action_state.closure_time=event.closed?s.time_step:null;break;
    case EventType.SET_INQUIRY_OPENNESS:Object.assign(s.inquiry_state,event.patch); if(event.patch.overall_inquiry_openness!==undefined)s.inquiry_state.overall_inquiry_openness=event.patch.overall_inquiry_openness;break;
    case EventType.SET_CLOSURE_BUDGET:Object.assign(s.closure_budget,event.patch);break;
    case EventType.REGISTER_RETURN_CHANNEL:s.return_state.return_channels.push(clone(event.channel));break;
    case EventType.DELIVER_RETURN_SIGNAL:{const channel=s.return_state.return_channels.find(c=>c.channel_id===event.channel_id);if(!channel) throw new Error('Unknown channel');const latency=event.latency??channel.latency;if(typeof latency!=='number') throw new Error('Return latency missing');const consequential=event.signal_strength>=s.return_state.damping_rules.minimum_signal_strength && channel.active;s.return_state.delivered_signals.push({signal_id:event.signal_id,channel_id:event.channel_id,latency,consequential,source_type:event.source_type,target:channel.destination});s.return_state.return_latency_records.push({signal_id:event.signal_id,latency});break;}
    case EventType.TRIGGER_REOPEN:s.return_state.reopen_events.push({reopen_id:event.reopen_id,trigger_source:event.trigger_source,trigger_agent:event.trigger_agent,trigger_time:s.time_step,target_policy:s.action_state.selected_policy,target_warrant:event.target_warrant,reason:event.reason,standing_basis:event.standing_basis,review_body:event.review_body,possible_outcomes:event.possible_outcomes??[],actual_outcome:null});break;
    case EventType.RESOLVE_REOPEN:{const r=s.return_state.reopen_events.find(x=>x.reopen_id===event.reopen_id);if(!r) throw new Error('Unknown reopen');r.actual_outcome=event.outcome;break;}
    case EventType.INJECT_WORLD_SHOCK:{Object.assign(s.world,event.world_patch??{});log.hazard_exposure_delta=event.hazard_exposure_delta??0;break;}
    case EventType.REGISTER_GOVERNANCE_MISUSE:s.governance_risk_state.political_misuse_risk=event.level;s.governance_risk_state.institutional_lock_in_risk=Math.max(s.governance_risk_state.institutional_lock_in_risk,event.lock_in??0.3);break;
    case EventType.UPDATE_GOVERNANCE_RISK:Object.assign(s.governance_risk_state,event.patch);break;
    case EventType.START_RESTORATION_REVIEW:s.restoration_state.restoration_trigger=event.trigger;s.restoration_state.renewal_status='UNDER_REVIEW';break;
    case EventType.RENEW_AUTHORITY:s.restoration_state.renewal_status='RENEWED';s.restoration_state.current_extraordinary_authority=event.level??s.restoration_state.current_extraordinary_authority;break;
    case EventType.CONTRACT_AUTHORITY:s.restoration_state.current_extraordinary_authority=Math.max(0,event.level);s.restoration_state.renewal_status='CONTRACTED';break;
    case EventType.RESTORE_AUTHORITY:s.restoration_state.current_extraordinary_authority=0;s.restoration_state.formal_restoration_status=true;s.restoration_state.functional_restoration_status=(s.restoration_state.residual_authority+s.restoration_state.residual_information_power+s.restoration_state.residual_enforcement_power)<=0.15;s.authorization_state.current_authority_holder=null;break;
    case EventType.REGISTER_RESIDUAL_POWER:Object.assign(s.restoration_state,event.patch);s.restoration_state.functional_restoration_status=s.restoration_state.formal_restoration_status && (s.restoration_state.residual_authority+s.restoration_state.residual_information_power+s.restoration_state.residual_enforcement_power)<=0.15;break;
    case EventType.STOP_RUN:s.stop_state={reason:event.reason,time:s.time_step};break;
    default:throw new Error(`Unknown event ${event.type}`);
  }
  s.event_log.push(log); s.metrics=computeMetrics(s); return s;
}
export const run=(state,events)=>events.reduce(reduce,state);
