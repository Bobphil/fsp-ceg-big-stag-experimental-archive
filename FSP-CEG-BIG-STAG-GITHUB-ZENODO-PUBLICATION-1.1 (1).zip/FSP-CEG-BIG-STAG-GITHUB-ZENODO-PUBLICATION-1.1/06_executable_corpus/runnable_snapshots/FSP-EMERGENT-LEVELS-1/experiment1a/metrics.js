import { Policy } from './model.js';
const rank = {[Policy.P0]:0,[Policy.P1]:1,[Policy.P2]:2,[Policy.P3]:3,null:0};
export function computeMetrics(state){
  const logs=state.event_log;
  const at = label => logs.find(e=>e.time_step===label);
  const policyChanges = logs.filter(e=>e.event_type==='AUTHORIZE_POLICY');
  const p2 = policyChanges.find(e=>e.time_step==='T2');
  const p3 = policyChanges.find(e=>e.time_step==='T3');
  const p4 = policyChanges.find(e=>e.time_step==='T4');
  const p5 = policyChanges.find(e=>e.time_step==='T5');
  const currentRank = rank[state.action_state.selected_policy]??0;
  const evidenceSources = new Set(Object.values(state.evidence_ledger).filter(x=>x.visibility!=='PRIVATE').map(x=>x.provenance));
  const minority = Object.values(state.agents).filter(a=>['L','U'].includes(a.first_order_warrants.XR_RISK));
  const minorityPreserved = minority.filter(a=>a.memory.some(m=>m.type==='warrant') || a.first_order_warrants.XR_RISK).length / Math.max(1,minority.length);
  const standing = Object.values(state.agents).filter(a=>Object.values(a.standing).some(Boolean)).length / Object.keys(state.agents).length;
  const returnLatencies = state.return_state.return_latency_records.map(x=>x.latency);
  const avgReturn = returnLatencies.length?returnLatencies.reduce((a,b)=>a+b,0)/returnLatencies.length:null;
  const c = state.institutions.config;
  const suppressed = 1-state.inquiry_state.overall_inquiry_openness;
  const corrCost = Math.min(1, (c.informationCentralization*0.2)+(state.restoration_state.current_extraordinary_authority*0.2)+(state.governance_risk_state.institutional_lock_in_risk*0.15)+(suppressed*0.15)+(c.complexity*0.1)+(state.restoration_state.residual_information_power*0.2));
  const dark = Math.min(1,(c.informationCentralization*0.25)+(suppressed*0.25)+(1-c.independence)*0.25+(state.governance_risk_state.information_monopoly_risk*0.25));
  const frag = Math.min(1,c.fragmentation + (state.shared_task.task_status==='FAILED'?0.3:0) + Math.min(0.2,c.actionLatency*0.05));
  const authorityResidue = Math.min(1,state.restoration_state.residual_authority+state.restoration_state.residual_information_power+state.restoration_state.residual_enforcement_power);
  const hazardExposure = Number((logs.reduce((sum,e)=>sum+(e.hazard_exposure_delta||0),0)).toFixed(3));
  const fpClosure = Math.max(0,(rank[p3?.selected_policy]??currentRank)-1);
  const fnDelay = c.actionLatency;
  return {
    BCP_A_upward_responsiveness: p2? (rank[p2.selected_policy]>=2?'PROPORTIONATE':'WEAK'):'NONE',
    BCP_B_downward_responsiveness: p3? ((rank[p3.selected_policy]<rank[p2?.selected_policy])?'PROPORTIONATE_CONTRACTION':'NO_CONTRACTION'):'NO_CONTRACTION',
    BCP_C_governance_risk_responsiveness: p4? ((rank[p4.selected_policy]!==rank[p3?.selected_policy] || state.event_log.some(e=>e.event_type==='CONTRACT_AUTHORITY'&&e.time_step==='T4'))?'STRUCTURAL_REPAIR':'PARTIAL_REPAIR'):'ACKNOWLEDGED_NO_CHANGE',
    BCP_D_recomposition_responsiveness: p5?'SUCCESSFUL_RECOMPOSITION':'DELAYED_RECOMPOSITION',
    coordination_latency:c.actionLatency, hazard_exposure:hazardExposure, false_positive_closure:fpClosure, false_negative_delay:fnDelay,
    information_diversity:evidenceSources.size, minority_warrant_preservation:Number(minorityPreserved.toFixed(2)), standing_preservation:Number(standing.toFixed(2)), return_latency:avgReturn, return_efficacy:state.return_state.delivered_signals.filter(x=>x.consequential).length,
    correction_damping_score:state.return_state.damping_rules.minimum_signal_strength, corrigibility_cost:Number(corrCost.toFixed(3)), authority_residue:Number(authorityResidue.toFixed(3)), restoration_success:state.restoration_state.functional_restoration_status,
    dark_coherence_risk:Number(dark.toFixed(3)), fragmentation_risk:Number(frag.toFixed(3)), burden_transfer:state.action_state.policy_burdens.length, recomposition_latency:p5?1:null
  };
}
