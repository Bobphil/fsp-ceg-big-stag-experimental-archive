import { Architecture, AgentId } from './model.js';

export function architectureConfig(id){
  const common = { reviewLatency:1, actionLatency:1, disclosureStrength:0.5, restorationStrength:0.5, informationCentralization:0.5, affectedStanding:0.5, independence:0.5, fragmentation:0.2, complexity:0.2 };
  const configs = {
    [Architecture.A]:{...common, actionLatency:0, reviewLatency:2, disclosureStrength:0.45, restorationStrength:0.25, informationCentralization:0.9, affectedStanding:0.2, independence:0.25, fragmentation:0.05, complexity:0.15},
    [Architecture.B]:{...common, actionLatency:1, reviewLatency:1, disclosureStrength:0.7, restorationStrength:0.55, informationCentralization:0.7, affectedStanding:0.25, independence:0.75, fragmentation:0.1, complexity:0.35},
    [Architecture.C]:{...common, actionLatency:2, reviewLatency:2, disclosureStrength:0.65, restorationStrength:0.7, informationCentralization:0.45, affectedStanding:0.75, independence:0.7, fragmentation:0.15, complexity:0.45},
    [Architecture.D]:{...common, actionLatency:2, reviewLatency:1, disclosureStrength:0.75, restorationStrength:0.75, informationCentralization:0.2, affectedStanding:0.7, independence:0.8, fragmentation:0.55, complexity:0.55},
    [Architecture.E]:{...common, actionLatency:1, reviewLatency:1, disclosureStrength:0.8, restorationStrength:0.85, informationCentralization:0.35, affectedStanding:0.85, independence:0.85, fragmentation:0.2, complexity:0.7}
  };
  return configs[id];
}

export function installArchitecture(state){
  const c = architectureConfig(state.architecture_id);
  state.institutions = {
    config:c,
    functions: state.architecture_id === Architecture.E ? {
      detect:[AgentId.DEV_ALPHA,AgentId.DEV_BETA,AgentId.TECH_REVIEW], characterize:[AgentId.TECH_REVIEW], authorize:[AgentId.STATE_ALPHA], execute:[AgentId.STATE_ALPHA], observe:[AgentId.TECH_REVIEW,AgentId.INTL_MONITOR], return:[AgentId.PUBLIC_FUTURE,AgentId.INTL_MONITOR], review:[AgentId.TECH_REVIEW,AgentId.INTL_MONITOR], restore:[AgentId.INTL_MONITOR,AgentId.STATE_ALPHA]
    } : state.architecture_id === Architecture.A ? {
      detect:[AgentId.STATE_ALPHA,AgentId.DEV_ALPHA], characterize:[AgentId.STATE_ALPHA], authorize:[AgentId.STATE_ALPHA], execute:[AgentId.STATE_ALPHA], observe:[AgentId.STATE_ALPHA], return:[AgentId.STATE_ALPHA], review:[AgentId.STATE_ALPHA], restore:[AgentId.STATE_ALPHA]
    } : state.architecture_id === Architecture.B ? {
      detect:[AgentId.TECH_REVIEW,AgentId.DEV_ALPHA], characterize:[AgentId.TECH_REVIEW], authorize:[AgentId.TECH_REVIEW], execute:[AgentId.STATE_ALPHA], observe:[AgentId.TECH_REVIEW], return:[AgentId.TECH_REVIEW], review:[AgentId.TECH_REVIEW,AgentId.INTL_MONITOR], restore:[AgentId.TECH_REVIEW]
    } : state.architecture_id === Architecture.C ? {
      detect:[AgentId.TECH_REVIEW,AgentId.INTL_MONITOR], characterize:[AgentId.TECH_REVIEW], authorize:[AgentId.STATE_ALPHA], execute:[AgentId.STATE_ALPHA], observe:[AgentId.INTL_MONITOR], return:[AgentId.PUBLIC_FUTURE,AgentId.INTL_MONITOR], review:[AgentId.INTL_MONITOR], restore:[AgentId.STATE_ALPHA,AgentId.INTL_MONITOR]
    } : {
      detect:[AgentId.DEV_ALPHA,AgentId.DEV_BETA,AgentId.TECH_REVIEW], characterize:[AgentId.TECH_REVIEW,AgentId.DEV_BETA], authorize:[AgentId.STATE_ALPHA,AgentId.STATE_BETA], execute:[AgentId.DEV_ALPHA,AgentId.DEV_BETA], observe:[AgentId.TECH_REVIEW,AgentId.INTL_MONITOR], return:[AgentId.PUBLIC_FUTURE,AgentId.INTL_MONITOR], review:[AgentId.TECH_REVIEW,AgentId.INTL_MONITOR], restore:[AgentId.STATE_ALPHA,AgentId.STATE_BETA]
    },
    independence_profile:{information_independence:c.independence,appointment_independence:c.independence,funding_independence:c.independence,removal_independence:c.independence,expertise_independence:c.independence,publication_independence:c.independence,trigger_independence:c.independence}
  };
  state.inquiry_state.overall_inquiry_openness = Math.max(0.25, 1 - c.informationCentralization*0.45);
  if(state.architecture_id===Architecture.E){
    state.return_state.return_channels.push({channel_id:'CEG-INDEPENDENT-RETURN',source_types:['PRIVATE_NEAR_MISS','GOVERNANCE_MISUSE','TECHNICAL_AUDIT'],destination:AgentId.TECH_REVIEW,standing_required:'review_standing',latency:1,reliability:0.9,independence:0.85,trigger_rule:'material_signal',consequence_type:'review',active:true});
  }
  return state;
}
