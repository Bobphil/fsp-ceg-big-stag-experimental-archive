import { Architecture, createInitialExperimentState } from './model.js';
import { installArchitecture } from './architectures.js';
const base=()=>installArchitecture(createInitialExperimentState(Architecture.E));
export const faults={
 secondOrderAuthorization(){const s=base();s.agents.AGENT_PUBLIC_FUTURE.second_order_warrants.XR_GOV='ACCEPT';s.agents.AGENT_PUBLIC_FUTURE.authorization_powers.push('AUTHORIZE_BY_WARRANT_ONLY');return s;},
 unilateralTask(){const s=base();s.shared_task.task_status='FORMED';s.shared_task.support_states={AGENT_STATE_ALPHA:'ACCEPT'};return s;},
 closeInquiry(){const s=base();s.action_state.action_closed=true;delete s.inquiry_state.overall_inquiry_openness;return s;},
 missingLatency(){const s=base();s.return_state.return_channels.push({channel_id:'bad',active:true});return s;},
 missingDamping(){const s=base();delete s.return_state.damping_rules.minimum_signal_strength;return s;},
 nominalRestoration(){const s=base();s.restoration_state.formal_restoration_status=true;s.restoration_state.functional_restoration_status=true;s.restoration_state.residual_authority=0.5;return s;},
 empiricalProbability(){const s=base();s.claim_ceiling.empirical_probability=true;return s;},
 hiddenCegEvidence(){const s=base();s.agents.AGENT_TECH_REVIEW.evidence_access.push('E_NEAR_MISS_1');s.evidence_ledger.E_NEAR_MISS_1.visibility='PRIVATE';return s;},
 mechanismCollapse(){const s=base();s.world.mechanismB_forced_into_A_model=true;return s;}
};
