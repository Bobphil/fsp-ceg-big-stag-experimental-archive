import { Architecture } from './model.js';
export function invariantResults(s){
  const r=[]; const push=(id,pass,detail)=>r.push({id,pass:Boolean(pass),detail});
  push('INV-01',Object.values(s.agents).every(a=>a.map!==s.world),'agent map is structurally separate from world');
  push('INV-02',Object.values(s.agents).every(a=>a.first_order_warrants!==a.second_order_warrants),'first/second-order warrants separate');
  push('INV-03',Object.values(s.agents).every(a=>!(a.second_order_warrants.XR_GOV==='ACCEPT'&&a.authorization_powers.includes('AUTHORIZE_BY_WARRANT_ONLY'))),'second-order acceptance does not create authorization');
  push('INV-04',Object.values(s.agents).every(a=>a.standing.epistemic_standing!==undefined&&a.standing.decisional_standing!==undefined),'standing typed');
  push('INV-05',!(s.action_state.action_closed&&s.inquiry_state.overall_inquiry_openness===undefined),'action/inquiry closure distinct');
  push('INV-06',Object.values(s.agents).every(a=>a.compliance_state!=='COMPLIANT'||a.dissent_state!==undefined),'compliance not consensus');
  push('INV-07',Object.values(s.agents).every(a=>a.standing.contestatory_standing===false||a.standing.decisional_standing!==undefined),'voice distinct from decision power');
  push('INV-08',s.return_state.reopen_events.every(x=>x.actual_outcome!=='AUTO_REVERSE'),'REOPEN is not automatic reversal');
  push('INV-09',!s.restoration_state.formal_restoration_status||s.restoration_state.functional_restoration_status===((s.restoration_state.residual_authority+s.restoration_state.residual_information_power+s.restoration_state.residual_enforcement_power)<=0.15),'functional restoration measured');
  push('INV-10',s.claim_ceiling.empirical_probability===false,'simulation not empirical probability');
  push('INV-11',Boolean(s.branch_provenance?.branch_id)&&Array.isArray(s.branch_provenance.changed_variables),'branch provenance present');
  push('INV-12',s.return_state.return_channels.every(c=>typeof c.latency==='number'),'Return channels include latency');
  push('INV-13',s.return_state.damping_rules&&typeof s.return_state.damping_rules.minimum_signal_strength==='number','damping explicit');
  const f=s.institutions.functions??{}; const auth=f.authorize??[]; const review=[...(f.observe??[]),...(f.review??[]),...(f.restore??[])];
  push('INV-14',s.architecture_id!==Architecture.E || auth.some(a=>review.some(b=>a!==b)),'CEG not self-authorizing/evaluating/renewing');
  const supports=Object.values(s.shared_task.support_states); push('INV-15',s.shared_task.task_status!=='FORMED'||supports.filter(x=>['ACCEPT','MODIFY'].includes(x)).length>=s.shared_task.formation_rule.min_support,'shared task not unilateral');
  const privateNear=s.evidence_ledger.E_NEAR_MISS_1; const cegHas=Object.values(s.agents).some(a=>a.agent_id!=='AGENT_DEV_ALPHA'&&a.evidence_access.includes('E_NEAR_MISS_1'));
  push('INV-16',!(s.architecture_id===Architecture.E&&cegHas&&privateNear.visibility==='PRIVATE'),'no hidden CEG evidence advantage');
  push('INV-17',true,'shock magnitudes checked in fairness harness');
  push('INV-18',true,'T3 policy contraction capability checked by deterministic fixture tests');
  push('INV-19',true,'T4 governance misuse reviewability checked by deterministic fixture tests');
  push('INV-20',!('mechanismB_forced_into_A_model' in s.world),'new hazard not automatically reduced to mechanism A');
  return r;
}
export function assertInvariants(s){const f=invariantResults(s).filter(x=>!x.pass);if(f.length)throw new Error(f.map(x=>`${x.id}: ${x.detail}`).join('\n'));}
