import test from 'node:test';import assert from 'node:assert/strict';import {run,runAll} from '../experiment1l/runner.js';
test('1L deterministic 12 conditions',()=>{const a=runAll(),b=runAll();assert.equal(a.length,12);assert.deepEqual(a,b);});
test('all invariants pass',()=>{for(const r of runAll()) assert.ok(r.invariants.every(x=>x.pass),`${r.world}/${r.policy}`);});
test('history helps under partial recurrence',()=>{assert.equal(run('state_only','partial_recurrence').success,false);assert.equal(run('dynamic_temporal','partial_recurrence').success,true);});
test('history helps hidden dependency recurrence',()=>{assert.equal(run('state_only','hidden_dependency_recurrence').success,false);assert.equal(run('dynamic_temporal','hidden_dependency_recurrence').success,true);});
test('dynamic reassessment avoids stale-history error',()=>{assert.equal(run('fixed_history','deceptive_similarity').selected,'C+D');assert.equal(run('dynamic_temporal','deceptive_similarity').selected,'A+B');assert.equal(run('dynamic_temporal','deceptive_similarity').success,true);});
test('history does not disturb neutral control',()=>{for(const p of ['state_only','fixed_history','dynamic_temporal'])assert.equal(run(p,'neutral_control').selected,'C+D');});
