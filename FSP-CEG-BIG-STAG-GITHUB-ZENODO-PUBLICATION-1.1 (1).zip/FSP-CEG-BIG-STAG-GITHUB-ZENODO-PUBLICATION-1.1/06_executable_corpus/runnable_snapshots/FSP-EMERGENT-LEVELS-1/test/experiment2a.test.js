import test from 'node:test'; import assert from 'node:assert/strict';
import { runAll, runCase } from '../experiment2a/runner.js'; import { metricsFor } from '../experiment2a/metrics.js'; import { evaluate2A } from '../experiment2a/invariants.js';

test('2A deterministic cases',()=>{assert.deepEqual(runAll(),runAll());});
test('2A all invariants pass',()=>{const inv=evaluate2A(runAll()); assert.equal(inv.filter(x=>x.pass).length,inv.length);});
test('vote split exposes action-family mismatch',()=>{const m=metricsFor(runCase('VOTE_SPLIT')); assert.equal(m.proposal_family_mismatch,true); assert.equal(m.largest_family,'POLICY_P2_TEMP_RESTRICTION');});
test('agenda exclusion changes winner',()=>{assert.equal(metricsFor(runCase('AGENDA_EXCLUSION')).agenda_changed_winner,true);});
test('coordinated bloc can supply plurality',()=>{const r=runCase('COORDINATED_BLOC').phases[0]; assert.equal(r.coordinated_bloc_votes_for_winner,4); assert.equal(r.winner_votes,4);});
test('participation loss separates cast share from electorate share',()=>{const m=metricsFor(runCase('PARTICIPATION_LOSS')); assert.ok(m.plurality_share_cast>0.5); assert.ok(m.plurality_share_electorate<0.5);});
test('Return can recompose plurality',()=>{const r=runCase('RETURN_RECOMPOSITION'); assert.notEqual(r.phases[0].authorized_proposal,r.phases[1].authorized_proposal); assert.equal(r.minority_later_wins,true);});
test('all losing records remain preserved',()=>{for(const r of runAll()) for(const p of r.phases) assert.ok(p.minority_archive.every(x=>x.preserved));});
test('no stress case manufactures truth',()=>{for(const r of runAll()) for(const p of r.phases){assert.equal(p.truth_claim,false);assert.equal(p.consensus_claim,false);}});
test('electorate remains twelve PRFs',()=>{for(const r of runAll()) for(const p of r.phases) assert.equal(p.electorate,12);});
