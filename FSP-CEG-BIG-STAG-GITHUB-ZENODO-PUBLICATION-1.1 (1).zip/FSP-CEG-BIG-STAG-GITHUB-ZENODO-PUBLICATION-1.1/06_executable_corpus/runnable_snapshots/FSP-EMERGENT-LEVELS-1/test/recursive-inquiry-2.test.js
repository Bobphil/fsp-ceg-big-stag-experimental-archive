import test from 'node:test';
import assert from 'node:assert/strict';
import {
 CandidateSharedInvariants,decompositionLedger,strictDecompositionWithoutRemainder,decompositionWithExplicitRemainder,
 strictFailureIsomorphism,recurrentFailureCore,ablateInvariant,sufficientDecompression,informationBridge,
 informationMetricsAuthorize,informationMetricsAssignStanding
} from '../recursive-inquiry-2/model.js';
import {evaluate} from '../recursive-inquiry-2/invariants.js';

test('recursive inquiry 2 invariants pass',()=>{const f=evaluate().filter(x=>!x.pass);assert.equal(f.length,0,JSON.stringify(f,null,2));});
test('strict decomposition without remainder is falsified',()=>{assert.equal(strictDecompositionWithoutRemainder(),false);assert.equal(decompositionWithExplicitRemainder(),true);});
test('all five scales have explicit decomposition remainder',()=>assert.equal(decompositionLedger.filter(x=>x.scaleSpecificRemainder.length>0).length,5));
test('failure recurrence is partial rather than strict isomorphism',()=>{assert.equal(strictFailureIsomorphism(),false);assert.deepEqual(recurrentFailureCore().sort(),['PREMATURE_CLOSURE','REPRESENTATION_SUBSTITUTION','RESIDUE_LOSS']);});
for(const inv of CandidateSharedInvariants){test(`ablation of ${inv} destroys admissibility`,()=>assert.equal(ablateInvariant(inv).admissible,false));}
test('sufficient decompression stops when action-sensitive distinctions are resolved',()=>{const x=sufficientDecompression({triggerAddressed:true,relevantDistinctionsRecovered:true,affectedStandingIncluded:true,authorizationReassessmentPossible:true,actionSensitiveOpen:0,residualUncertaintyRecorded:true,futureReopenRoutePreserved:true});assert.equal(x.outcome,'SUFFICIENT_DECOMPRESSION');});
test('total decompression is not required by stopping rule',()=>{const x=sufficientDecompression({triggerAddressed:true,relevantDistinctionsRecovered:true,affectedStandingIncluded:true,authorizationReassessmentPossible:true,actionSensitiveOpen:0,residualUncertaintyRecorded:true,futureReopenRoutePreserved:true,unrecoveredNonActionSensitive:999});assert.equal(x.stop,true);});
test('irrecoverable distinction escalates instead of infinite local recursion',()=>{const x=sufficientDecompression({triggerAddressed:true,relevantDistinctionsIrrecoverable:true,affectedStandingIncluded:true,authorizationReassessmentPossible:false,actionSensitiveOpen:2,residualUncertaintyRecorded:true,futureReopenRoutePreserved:true,escalationAvailable:true});assert.equal(x.outcome,'ESCALATE_AND_RECOMPOSE');});
test('information bridge separates descriptive and normative fields',()=>{const x=informationBridge({inputStates:64,activeStates:8,residueStates:32,returnSignals:4,normative:{standing:'review',authorization:'conditional',legitimacy:'contested'}});assert.equal(x.descriptive.compressionRatio,0.125);assert.equal(x.normative.source,'EXTERNAL_NORMATIVE_GOVERNANCE');});
test('information metrics cannot assign standing or authorization',()=>{assert.equal(informationMetricsAssignStanding(),false);assert.equal(informationMetricsAuthorize(),false);});
