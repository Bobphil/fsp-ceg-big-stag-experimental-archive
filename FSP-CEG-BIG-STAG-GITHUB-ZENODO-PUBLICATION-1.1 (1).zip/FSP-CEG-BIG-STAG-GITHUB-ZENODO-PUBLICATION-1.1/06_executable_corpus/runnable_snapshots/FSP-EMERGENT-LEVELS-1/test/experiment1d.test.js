import test from 'node:test';
import assert from 'node:assert/strict';
import { GrammarD, allRepairs, ACTIVATION_CONFIDENCE } from '../experiment1d/model.js';
import { runGrammarD, runAllD } from '../experiment1d/runner.js';

test('1D deterministic across all three grammars',()=>{
 for(const g of Object.values(GrammarD)) assert.equal(runGrammarD(g).hash,runGrammarD(g).hash);
});
test('1D all invariants pass',()=>{for(const r of runAllD()) assert.ok(r.invariants.every(x=>x.pass),JSON.stringify(r.invariants));});
test('conjunctive makes every available route binding',()=>{const r=runGrammarD(GrammarD.CONJUNCTIVE); assert.ok(r.episodes.every(e=>e.activated_routes.length===allRepairs.length));});
test('immediate routing activates on diagnosis regardless confidence',()=>{const r=runGrammarD(GrammarD.IMMEDIATE); assert.ok(r.episodes[0].activated_routes.length>0); assert.ok(r.episodes[1].activated_routes.length>0);});
test('preserve grammar maintains routes without automatically activating them',()=>{const r=runGrammarD(GrammarD.PRESERVE_ACTIVATE); assert.equal(r.route_availability.portfolio_coverage,1); assert.equal(r.episodes[0].activated_routes.length,0); assert.equal(r.episodes[1].activated_routes.length,0);});
test('preserve grammar activates high-confidence route',()=>{const r=runGrammarD(GrammarD.PRESERVE_ACTIVATE); assert.ok(r.episodes[3].diagnostic_confidence[r.episodes[3].true_active[0]]>=ACTIVATION_CONFIDENCE); assert.ok(r.episodes[3].activated_routes.length>0);});
test('preserve grammar activates on consequence revelation below confidence threshold',()=>{const r=runGrammarD(GrammarD.PRESERVE_ACTIVATE); assert.ok(r.episodes[4].diagnostic_confidence[r.episodes[4].true_active[0]]<ACTIVATION_CONFIDENCE); assert.ok(r.episodes[4].consequence_triggered.length>0); assert.ok(r.episodes[4].activated_routes.length>0);});
test('availability coverage and activation rate are distinct',()=>{const r=runGrammarD(GrammarD.PRESERVE_ACTIVATE); assert.equal(r.route_availability.relevant_route_coverage,1); assert.ok(r.repair_selectivity.relevant_activation_rate<1);});
test('preserve grammar records latent failure exposure for deferred low-confidence failures',()=>{const r=runGrammarD(GrammarD.PRESERVE_ACTIVATE); assert.ok(r.protection_profile.latent_failure_exposure>0);});
test('no master score introduced',()=>{for(const r of runAllD()) assert.equal('master_score' in r,false);});
