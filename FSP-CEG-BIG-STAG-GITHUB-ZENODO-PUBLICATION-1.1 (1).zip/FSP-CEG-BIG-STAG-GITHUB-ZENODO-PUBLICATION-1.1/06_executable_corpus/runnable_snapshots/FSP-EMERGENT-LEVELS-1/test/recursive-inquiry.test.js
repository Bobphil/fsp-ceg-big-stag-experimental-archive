import test from 'node:test';import assert from 'node:assert/strict';import {scales,Grammar} from '../recursive-inquiry/model.js';import {evaluate} from '../recursive-inquiry/invariants.js';
test('recursive inquiry has five scales',()=>assert.equal(scales.length,5));
test('recursive grammar has eight operations',()=>assert.equal(Grammar.length,8));
test('recursive inquiry invariants pass',()=>{const f=evaluate().filter(x=>!x.pass);assert.equal(f.length,0,JSON.stringify(f,null,2));});
test('higher scales retain lower-level residue',()=>assert.ok(scales.slice(1).every(s=>s.residue.length>=3)));
