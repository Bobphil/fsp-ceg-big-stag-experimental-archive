import test from 'node:test';import assert from 'node:assert/strict';
import { temporalWorlds } from '../experiment1k/fixtures.js';import { WEIGHT_POLICIES } from '../experiment1k/model.js';import { runTemporalMemory } from '../experiment1k/runner.js';
test('1K worlds include recurrence',()=>assert.ok(temporalWorlds.false_composability_recurrence.length===6));
test('1K permanent weighted records are retained',()=>{const r=runTemporalMemory('dynamic_full','false_composability_recurrence');assert.ok(r.metrics.memory.records_retained>0);assert.ok(r.episodes.at(-1).records.length>0);});
test('1K dynamic memory changes weights',()=>{const r=runTemporalMemory('dynamic_full','false_composability_recurrence');assert.ok(r.metrics.memory.reassessment_events>0);});
test('1K fixed caution has no decay/reassessment',()=>{const r=runTemporalMemory('fixed_caution','false_composability');assert.equal(r.metrics.memory.decay_events,0);assert.equal(r.metrics.memory.reassessment_events,0);});
test('1K state-sensitive has no historical records',()=>{const r=runTemporalMemory('state_sensitive_only','path_dependency');assert.equal(r.metrics.memory.records_retained,0);});
test('1K all nondelegated outputs avoid master score',()=>{for(const w of Object.keys(temporalWorlds))for(const p of Object.keys(WEIGHT_POLICIES)){if(p==='reopen_delete_baseline')continue;const r=runTemporalMemory(p,w);assert.ok(!('master_score'in r.metrics));}});
