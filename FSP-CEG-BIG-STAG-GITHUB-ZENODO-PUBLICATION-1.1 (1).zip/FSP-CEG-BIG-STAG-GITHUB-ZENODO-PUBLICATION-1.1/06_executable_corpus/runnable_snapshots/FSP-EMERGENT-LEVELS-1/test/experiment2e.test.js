import test from 'node:test'; import assert from 'node:assert/strict'; import { runAll, runCase, ReturnCase } from '../experiment2e/runner.js'; import { evaluate2E } from '../experiment2e/invariants.js';
test('2E has eight deterministic cases',()=>assert.equal(runAll().length,8));
test('2E all invariants pass',()=>{const inv=evaluate2E(); assert.equal(inv.filter(x=>!x.pass).length,0,JSON.stringify(inv.filter(x=>!x.pass),null,2));});
test('2E control reaches consequence and termination',()=>{const r=runCase(ReturnCase.CONTROL_SUCCESS); assert.equal(r.reopen_consequence,true); assert.equal(r.terminated,true);});
test('2E detection failure is isolated',()=>{const r=runCase(ReturnCase.DETECTION_FAILURE); assert.equal(r.failures.detection,1); assert.equal(r.message_count,0);});
test('2E reception failure received but not credited',()=>{const r=runCase(ReturnCase.RECEPTION_FAILURE); assert.equal(r.messages[0].received,true); assert.equal(r.review_uptake,false);});
test('2E standing failure follows detection',()=>{const r=runCase(ReturnCase.STANDING_FAILURE); assert.equal(r.detected,true); assert.equal(r.failures.standing,1);});
test('2E reconstruction failure follows uptake',()=>{const r=runCase(ReturnCase.RECONSTRUCTION_FAILURE); assert.equal(r.review_uptake,true); assert.equal(r.warrant_reconstructed,false);});
test('2E termination failure leaves review open after repair',()=>{const r=runCase(ReturnCase.TERMINATION_FAILURE); assert.equal(r.repair_completed,true); assert.equal(r.review_open,true);});
