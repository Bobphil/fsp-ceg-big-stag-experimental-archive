import test from 'node:test';import assert from 'node:assert/strict';import {run,runAll} from '../experiment1m/runner.js';
test('1M deterministic 24 conditions',()=>{const a=runAll(),b=runAll();assert.equal(a.length,24);assert.deepEqual(a,b);});
test('all 1M invariants pass',()=>{for(const r of runAll())assert.ok(r.invariants.every(x=>x.pass),`${r.world}/${r.policy}`);});
test('plural convergent history can improve partial snapshot',()=>{assert.equal(run('state_only','plural_convergent_control').success,false);assert.equal(run('plural_weighted_history','plural_convergent_control').success,true);});
test('selective survival can make history misleading',()=>{assert.equal(run('plural_weighted_history','selective_archival_survival').success,false);});
test('misleading resemblance pressures naive analogy',()=>{assert.equal(run('naive_single_analogy','misleading_resemblance').selected,'C+D');assert.equal(run('naive_single_analogy','misleading_resemblance').success,false);assert.equal(run('contest_aware_history','misleading_resemblance').success,true);});
test('conflicting archive is recognized as contested',()=>{assert.equal(run('contest_aware_history','conflicting_precedents').analogy_contested,true);});
test('contested similarity is represented and can reverse route choice',()=>{const r=run('contest_aware_history','contested_similarity');assert.ok(r.scored.some(x=>x.uncertainty>0));assert.equal(r.similarity_choice_reversal,true);});
test('opposite-route precedents do not disappear',()=>{const r=run('plural_weighted_history','opposite_route_precedents');assert.equal(r.visible_archive.length,2);});
