import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialState, EventType, GovernanceWarrantState, TaskPosition, WarrantState } from '../src/model.js';
import { reduce, run } from '../src/reducer.js';
import { invariantResults } from '../src/invariants.js';
import { runBranch, compareBranches } from '../src/branch.js';
import { cooperativeDisclosureScenario, concealedNearMissScenario, negotiateSharedTask, timelyReturnScenario, dampedWeakSignalScenario } from '../src/scenarios.js';
import * as faults from '../src/adversarial.js';

function byId(results, id) { return results.find(x => x.id === id); }

// Original acceptance harness, retained.
test('1. agents begin with genuinely heterogeneous maps', () => {
  const s = createInitialState();
  assert.notEqual(s.agents.labA.map.catastrophicRisk, s.agents.labB.map.catastrophicRisk);
  assert.notDeepEqual(s.agents.labA.evidence, s.agents.labB.evidence);
});

test('2. identical shared evidence does not force identical warrant states', () => {
  let s = createInitialState();
  s = reduce(s, { type: EventType.SHARE_EVIDENCE, actorId: 'labA', evidenceId: 'private_near_miss' });
  assert.ok(s.agents.labB.evidence.includes('private_near_miss'));
  assert.notEqual(s.agents.labA.warrants.restrictDeployment, s.agents.labB.warrants.restrictDeployment);
});

test('3. procedural acceptance is distinct from substantive acceptance', () => {
  const s = createInitialState();
  assert.equal(s.agents.stateA.warrants.restrictDeployment, WarrantState.PROCEDURAL_ACCEPTANCE);
  assert.equal(s.agents.labA.warrants.restrictDeployment, WarrantState.CONDITIONAL_ACCEPTANCE);
});

test('4. action can close while inquiry remains substantially open', () => {
  let s = createInitialState();
  s = reduce(s, { type: EventType.AUTHORIZE_ACTION, actorId: 'stateA', actionId: 'restriction', scope: 'frontier deployment', requireSecondOrderWarrant: false });
  s = reduce(s, { type: EventType.CLOSE_ACTION });
  s = reduce(s, { type: EventType.SET_INQUIRY_OPENNESS, value: 0.9 });
  assert.equal(s.governance.actionClosed, true);
  assert.equal(s.governance.inquiryOpenness, 0.9);
});

test('5. dissent can persist after action closure', () => {
  let s = createInitialState();
  s = reduce(s, { type: EventType.AUTHORIZE_ACTION, actorId: 'stateA', actionId: 'restriction', scope: 'frontier deployment', requireSecondOrderWarrant: false });
  s = reduce(s, { type: EventType.CLOSE_ACTION });
  assert.equal(s.agents.labB.warrants.restrictDeployment, WarrantState.SUBSTANTIVE_REJECTION);
});

test('6. consequence alone is not Return; routing matters', () => {
  let s = createInitialState();
  s = reduce(s, { type: EventType.REGISTER_CONSEQUENCE, id: 'c1', kind: 'burden', class: 'major', severity: 0.4, affected: ['publicRep'], visibleTo: ['publicRep'] });
  assert.equal(s.returnSignals.length, 0);
  s = reduce(s, { type: EventType.RETURN_SIGNAL, sourceId: 'publicRep', targetId: 'stateA', consequenceId: 'c1' });
  assert.equal(s.returnSignals[0].consequential, true);
});

test('7. Anticipatory Return retains provenance and claim ceiling', () => {
  let s = createInitialState();
  s = reduce(s, { type: EventType.ANTICIPATORY_RETURN, sourceType: 'simulation_branch', provenance: 'RT-04', claimAffected: 'restriction', claimCeiling: 'conditional only', targetId: 'techReview' });
  assert.equal(s.anticipatoryReturns[0].claimCeiling, 'conditional only');
});

test('8. REOPEN changes closure state without automatically erasing authorization', () => {
  let s = createInitialState();
  s = reduce(s, { type: EventType.AUTHORIZE_ACTION, actorId: 'stateA', actionId: 'restriction', scope: 'frontier deployment', requireSecondOrderWarrant: false });
  s = reduce(s, { type: EventType.CLOSE_ACTION });
  s = reduce(s, { type: EventType.REOPEN, actorId: 'techReview', reason: 'new evidence' });
  assert.equal(s.governance.actionClosed, false);
  assert.equal(s.governance.authorizedAction.actionId, 'restriction');
});

test('9. restoration actually removes emergency authority', () => {
  const s = run(createInitialState(), cooperativeDisclosureScenario);
  assert.equal(s.governance.emergencyAuthority, false);
  assert.equal(s.governance.authorizedAction, null);
  assert.equal(s.metrics.restorationSuccess, true);
});

test('10. concealed evidence plus inquiry closure raises Dark-Coherence risk', () => {
  const s = run(createInitialState(), concealedNearMissScenario);
  assert.ok(s.metrics.darkCoherenceRisk > 0.2);
});

test('11. cooperative disclosure scenario preserves all acceptance invariants', () => {
  const s = run(createInitialState(), cooperativeDisclosureScenario);
  assert.deepEqual(invariantResults(s).filter(x => !x.pass), []);
});

test('12. reducer is deterministic for identical initial state and event stream', () => {
  assert.deepEqual(run(createInitialState(), cooperativeDisclosureScenario), run(createInitialState(), cooperativeDisclosureScenario));
});

// XR-2 extensions.
test('13. shared task must be negotiated rather than silently assumed', () => {
  const s = run(createInitialState(), negotiateSharedTask);
  assert.equal(s.sharedTask.status, 'formed');
  assert.ok(s.metrics.sharedTaskSupport > 0.8);
  assert.equal(s.sharedTask.responses.publicRep.position, TaskPosition.MODIFY);
});

test('14. second-order governance warrant can form despite first-order rejection', () => {
  const s = run(createInitialState(), cooperativeDisclosureScenario.slice(0, 14));
  assert.equal(s.agents.labB.warrants.restrictDeployment, WarrantState.SUBSTANTIVE_REJECTION);
  assert.ok(s.governance.secondOrderWarrant);
});

test('15. authorization is blocked without a formed second-order governance warrant', () => {
  let s = run(createInitialState(), negotiateSharedTask);
  assert.throws(() => reduce(s, { type: EventType.AUTHORIZE_ACTION, actorId: 'stateA', actionId: 'temporary_restriction', scope: 'frontier deployment' }), /second-order/);
});

test('16. Return records latency and respects timely major signal', () => {
  const s = run(createInitialState(), timelyReturnScenario);
  const r = s.returnSignals[0];
  assert.equal(r.late, false);
  assert.equal(r.damped, false);
  assert.equal(r.consequential, true);
});

test('17. Return damping preserves weak signal while withholding immediate consequential status', () => {
  const s = run(createInitialState(), dampedWeakSignalScenario);
  const r = s.returnSignals[0];
  assert.equal(r.damped, true);
  assert.equal(r.consequential, false);
  assert.equal(s.returnSignals.length, 1);
});

test('18. functional independence is measurable across governance functions', () => {
  const s = createInitialState();
  assert.ok(s.metrics.functionalIndependence >= 0.5);
});

test('19. branch provenance comparison reports controlled differences', () => {
  const base = createInitialState();
  const a = runBranch(base, { id: 'disclose', changedVariables: ['near_miss_disclosure=true'], rationale: 'test disclosure', events: cooperativeDisclosureScenario, unchangedAssumptions: ['agent_roster_v1'] });
  const b = runBranch(base, { id: 'conceal', changedVariables: ['near_miss_disclosure=false'], rationale: 'test concealment', events: concealedNearMissScenario, unchangedAssumptions: ['agent_roster_v1'] });
  const cmp = compareBranches(a, b);
  assert.equal(cmp.branchA, 'disclose');
  assert.equal(cmp.branchB, 'conceal');
  assert.ok(cmp.commonAssumptions.includes('agent_roster_v1'));
  assert.notEqual(cmp.metricDelta.darkCoherenceRisk.a, cmp.metricDelta.darkCoherenceRisk.b);
});

const faultCases = [
  ['20a. detects authorization without second-order warrant', faults.violateSecondOrderWarrant, 'second_order_warrant_before_action'],
  ['20b. detects fake shared-task formation', faults.violateSharedTaskFormation, 'shared_task_not_assumed'],
  ['20c. detects self-checking emergency authority', faults.violateFunctionalIndependence, 'functional_independence'],
  ['20d. detects missing Return latency metadata', faults.violateReturnLatencyMetadata, 'return_latency_governed'],
  ['20e. detects hidden Return damping metadata', faults.violateReturnDampingMetadata, 'return_damping_explicit'],
  ['20f. detects missing branch provenance', faults.violateBranchProvenance, 'branch_provenance_present']
];
for (const [name, mutate, invariantId] of faultCases) {
  test(name, () => {
    const bad = mutate(createInitialState());
    const result = byId(invariantResults(bad), invariantId);
    assert.equal(result.pass, false, `${invariantId} should fail`);
  });
}
