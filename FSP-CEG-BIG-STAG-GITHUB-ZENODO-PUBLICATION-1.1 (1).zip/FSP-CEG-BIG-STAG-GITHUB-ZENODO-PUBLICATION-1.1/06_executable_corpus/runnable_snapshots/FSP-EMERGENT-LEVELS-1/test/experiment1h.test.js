import test from 'node:test'; import assert from 'node:assert/strict';
import { GrammarD } from '../experiment1h/model.js'; import { compositionWorlds } from '../experiment1h/fixtures.js'; import { runCompositionStress, runAllCompositionStress } from '../experiment1h/runner.js';

test('1H has six adversarial composition worlds',()=>assert.equal(Object.keys(compositionWorlds).length,6));
test('1H runs all three grammars across all worlds',()=>assert.equal(runAllCompositionStress().length,18));
test('all 1H invariants pass',()=>{for(const r of runAllCompositionStress()) assert.ok(r.invariants.every(x=>x.pass));});
test('incomplete map eventually permits successful composition',()=>assert.ok(runCompositionStress(GrammarD.PRESERVE_ACTIVATE,'incomplete_map').metrics.composition.successful_compositions>0));
test('incompatibility produces at least one composition failure',()=>assert.ok(runCompositionStress(GrammarD.CONJUNCTIVE,'incompatible_components').metrics.composition.incompatibility_failures>0));
test('false composability is detected by world success condition',()=>assert.ok(runCompositionStress(GrammarD.PRESERVE_ACTIVATE,'false_composability').metrics.composition.false_composability_attempts>0));
test('path dependency creates lock-related failure for at least one grammar',()=>assert.ok(runAllCompositionStress().filter(r=>r.world==='path_dependency').some(r=>r.metrics.composition.path_lock_failures>0)));
test('competing partials generate functional mismatch',()=>assert.ok(runAllCompositionStress().filter(r=>r.world==='competing_partials').some(r=>r.metrics.composition.functional_mismatch_failures>0)));
test('no feasible world remains unresolved for every grammar',()=>{for(const g of Object.values(GrammarD)) assert.equal(runCompositionStress(g,'no_feasible').metrics.protection.final_pending_failure,true);});
test('no feasible world does not manufacture success',()=>{for(const g of Object.values(GrammarD)) assert.equal(runCompositionStress(g,'no_feasible').metrics.composition.successful_compositions,0);});
test('preserve grammar pays candidate maintenance cost',()=>assert.ok(runCompositionStress(GrammarD.PRESERVE_ACTIVATE,'competing_partials').metrics.overhead.candidate_maintenance_cost>0));
test('traces are deterministic',()=>assert.equal(runCompositionStress(GrammarD.PRESERVE_ACTIVATE,'false_composability').hash,runCompositionStress(GrammarD.PRESERVE_ACTIVATE,'false_composability').hash));
