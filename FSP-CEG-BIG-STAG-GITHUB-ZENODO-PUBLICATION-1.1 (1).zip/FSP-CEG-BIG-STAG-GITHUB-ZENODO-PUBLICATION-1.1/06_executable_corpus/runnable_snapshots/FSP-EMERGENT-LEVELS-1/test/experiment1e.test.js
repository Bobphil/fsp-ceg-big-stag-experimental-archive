import test from 'node:test';
import assert from 'node:assert/strict';
import { GrammarD, StressScenario } from '../experiment1e/model.js';
import { runStress, runAllStress } from '../experiment1e/runner.js';

test('1E deterministic across stress matrix',()=>{for(const r of runAllStress()) assert.equal(r.hash,runStress(r.grammar,r.scenario).hash);});
test('1E invariants pass',()=>{for(const r of runAllStress()) assert.ok(r.invariants.every(x=>x.pass),`${r.scenario}/${r.grammar} ${JSON.stringify(r.invariants)}`);});
test('1E baseline preserve reproduces zero compounding',()=>{const r=runStress(GrammarD.PRESERVE_ACTIVATE,StressScenario.BASELINE);assert.equal(r.metrics.protection.deferred_compounding_hazard,0);});
test('1E stressed preserve accumulates deferred hazard',()=>{const r=runStress(GrammarD.PRESERVE_ACTIVATE,StressScenario.MODERATE);assert.ok(r.metrics.protection.deferred_compounding_hazard>0);});
test('1E conjunctive continually maintains route quality',()=>{const r=runStress(GrammarD.CONJUNCTIVE,StressScenario.SEVERE);assert.equal(r.metrics.route_survival.relevant_availability_rate,1);assert.equal(r.metrics.route_survival.mean_quality_at_need,1);});
test('1E preserve route quality degrades under severe waiting',()=>{const r=runStress(GrammarD.PRESERVE_ACTIVATE,StressScenario.SEVERE);assert.ok(r.metrics.route_survival.mean_quality_at_need<1);});
test('1E idle capture can make preserved review route unavailable',()=>{const r=runStress(GrammarD.PRESERVE_ACTIVATE,StressScenario.CAPTURE);const t4=r.episodes.find(e=>e.time==='T4');assert.ok(t4.failed_activations.some(x=>x.route==='REPAIR_REVIEW_INDEPENDENCE'));});
test('1E expiry can leave late preserved routes unavailable',()=>{const r=runStress(GrammarD.PRESERVE_ACTIVATE,StressScenario.EXPIRY);assert.ok(r.metrics.route_survival.failed_activation_count>0);});
test('1E immediate routing has no latent decay but pays instantiation quality/latency',()=>{const r=runStress(GrammarD.IMMEDIATE,StressScenario.MODERATE);assert.ok(r.metrics.route_survival.mean_quality_at_need<1);assert.ok(r.metrics.overhead.activation_delay>r.metrics.overhead.repair_activations);});
test('1E no master score',()=>{for(const r of runAllStress()) assert.equal('master_score' in r.metrics,false);});
