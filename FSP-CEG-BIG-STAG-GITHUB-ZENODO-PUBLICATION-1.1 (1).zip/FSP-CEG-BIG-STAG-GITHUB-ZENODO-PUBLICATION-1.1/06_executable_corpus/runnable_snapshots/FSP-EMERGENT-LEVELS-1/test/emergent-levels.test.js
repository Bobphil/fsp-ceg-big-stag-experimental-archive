import test from 'node:test';
import assert from 'node:assert/strict';
import { Scale } from '../recursive-inquiry/model.js';
import {
 EmergenceStatus,modeledBaseLevel,emergenceProfiles,realizations,macroState,ablateOrganization,organizationDependence,
 multipleRealizability,emergentVocabularyIsNovel,independentMacroIndicators,autonomyProbe,applyDownwardConstraint,
 recursiveWithoutReduction,strongEmergenceEstablished,currentEmergenceThesis
} from '../emergent-levels/model.js';
import {evaluateEmergentLevels} from '../emergent-levels/invariants.js';

const emergentScales=[Scale.COALITION,Scale.INSTITUTIONAL,Scale.RETURN_NETWORK,Scale.CONSTITUTIONAL];

test('emergent-level invariants pass',()=>{const f=evaluateEmergentLevels().filter(x=>!x.pass);assert.equal(f.length,0,JSON.stringify(f,null,2));});
test('individual PRF remains explicit modeled base boundary',()=>assert.equal(modeledBaseLevel.scale,Scale.INDIVIDUAL));
test('organization is constitutive for every modeled emergent macrostate',()=>{for(const s of emergentScales){const x=realizations(s)[0];assert.notEqual(macroState(s,x),macroState(s,ablateOrganization(s,x)));}});
test('higher-level primitive vocabulary is not merely component inventory vocabulary',()=>{for(const s of emergentScales)assert.equal(emergentVocabularyIsNovel(s),true);});
test('different lower-level realizations instantiate the same higher-level state',()=>{for(const s of emergentScales)assert.equal(multipleRealizability(s).realized,true);});
test('macro states are robustly identified by multiple indicators',()=>{for(const s of emergentScales)for(const x of realizations(s))assert.equal(independentMacroIndicators(s,x).robust,true);});
test('organization-aware predictor beats inventory-only predictor on organization intervention',()=>{for(const s of emergentScales)assert.equal(autonomyProbe(s).organizationAddsLeverage,true);});
test('downward constraint changes available action without magically rewriting belief',()=>{const base={beliefs:{risk:.7},warrants:{P2:'conditional'},availableActions:['P1','P2','P3']};const x=applyDownwardConstraint(Scale.INSTITUTIONAL,base,{prohibit:['P3']});assert.deepEqual(x.after.availableActions,['P1','P2']);assert.equal(x.intrinsicStateUnchanged,true);});
test('recursion and nonreduction coexist',()=>{const xs=recursiveWithoutReduction();assert.equal(xs.length,4);assert.ok(xs.every(x=>x.reductionClaim==='REJECTED'&&x.sharedGrammar.length>=6));});
test('strong ontological emergence remains outside established claim',()=>{assert.equal(strongEmergenceEstablished(),false);assert.equal(EmergenceStatus.STRONG_ONTOLOGICAL,'NOT_ESTABLISHED');});
test('current emergence thesis is bounded organizational/explanatory thesis',()=>assert.match(currentEmergenceThesis(),/ORGANIZATIONAL_AND_EXPLANATORY/));
test('scale profiles preserve novel downward constraints',()=>assert.ok(emergenceProfiles.every(x=>x.downwardConstraints.length>0)));
