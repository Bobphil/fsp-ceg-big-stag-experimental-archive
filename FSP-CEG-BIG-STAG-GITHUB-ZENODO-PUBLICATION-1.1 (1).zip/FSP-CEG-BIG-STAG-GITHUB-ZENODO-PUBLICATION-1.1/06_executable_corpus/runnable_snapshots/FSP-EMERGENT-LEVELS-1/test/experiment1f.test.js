import test from 'node:test';
import assert from 'node:assert/strict';
import { GrammarD, EMERGENT_REVIEW } from '../experiment1f/model.js';
import { runSituated, runAllSituated } from '../experiment1f/runner.js';

test('1F deterministic',()=>{for(const r of runAllSituated()) assert.equal(r.hash,runSituated(r.grammar).hash);});
test('1F invariants pass',()=>{for(const r of runAllSituated()) assert.ok(r.invariants.every(x=>x.pass),`${r.grammar} ${JSON.stringify(r.invariants)}`);});
test('1F old route is stale before belief catches up',()=>{const r=runSituated(GrammarD.IMMEDIATE);assert.ok(r.episodes.find(e=>e.time==='T3').situational_map.stale.length>0);});
test('1F emergent route is truly feasible before conventional recognition',()=>{const r=runSituated(GrammarD.CONJUNCTIVE);assert.equal(r.metrics.situated_agency.new_route_feasible_time,'T4');assert.equal(r.metrics.situated_agency.new_route_recognition_time,'T6');});
test('1F preserve grammar discovers emergent candidate before conventional map',()=>{const r=runSituated(GrammarD.PRESERVE_ACTIVATE);const t4=r.episodes.find(e=>e.time==='T4');assert.ok(t4.preserved_portfolio.includes(EMERGENT_REVIEW));});
test('1F preserve grammar consequence-recomposes to emergent route at T5',()=>{const r=runSituated(GrammarD.PRESERVE_ACTIVATE);assert.ok(r.episodes.find(e=>e.time==='T5').successful_routes.includes(EMERGENT_REVIEW));});
test('1F immediate waits until conventional recognition to switch',()=>{const r=runSituated(GrammarD.IMMEDIATE);assert.equal(r.metrics.situated_agency.new_route_activation_time,'T6');});
test('1F conjunction also cannot bind unrecognized emergent route',()=>{const r=runSituated(GrammarD.CONJUNCTIVE);assert.equal(r.metrics.situated_agency.new_route_activation_time,'T6');});
test('1F stale legacy attempts are counted for grammars that act on the conventional stale map',()=>{for(const g of [GrammarD.CONJUNCTIVE,GrammarD.IMMEDIATE]) assert.ok(runSituated(g).metrics.situated_agency.obsolete_route_persistence>=1);});
test('1F deferred compounding activates when failure unresolved',()=>{const r=runSituated(GrammarD.IMMEDIATE);assert.ok(r.metrics.protection.deferred_failure_compounding>0);});
test('1F preserve recomposition latency is shorter than immediate',()=>{const p=runSituated(GrammarD.PRESERVE_ACTIVATE),i=runSituated(GrammarD.IMMEDIATE);assert.ok(p.metrics.situated_agency.recomposition_latency<i.metrics.situated_agency.recomposition_latency);});
test('1F no master score',()=>{for(const r of runAllSituated()) assert.equal('master_score' in r.metrics,false);});
