import test from 'node:test'; import assert from 'node:assert/strict'; import {runAll,runOne,Architecture,Stress} from '../experiment2f/runner.js'; import {evaluate2F} from '../experiment2f/invariants.js';
test('2F has 32 deterministic architecture x stress traces',()=>assert.equal(runAll().length,32));
test('2F invariants pass',()=>{const f=evaluate2F();assert.equal(f.filter(x=>!x.pass).length,0,JSON.stringify(f.filter(x=>!x.pass),null,2));});
test('2F fixed population and Return event',()=>assert.ok(runAll().every(x=>x.prf_population===12&&x.return_event==='SAME_FIXED_PROCEDURAL_FRAGILITY_RETURN')));
test('2F reference survives capture',()=>assert.equal(runOne(Architecture.DISTRIBUTED_REFERENCE,Stress.CAPTURE).success,true));
test('2F no cross trigger fails capture',()=>assert.equal(runOne(Architecture.NO_CROSS_TRIGGER,Stress.CAPTURE).success,false));
test('2F no persistence fails information loss',()=>assert.equal(runOne(Architecture.NO_PERSISTENCE,Stress.INFORMATION_LOSS).success,false));
test('2F self termination can be premature',()=>assert.equal(runOne(Architecture.SELF_TERMINATION,Stress.DISTORTION).premature_termination,true));
test('2F no redundancy alone survives simple delay',()=>assert.equal(runOne(Architecture.NO_REDUNDANCY,Stress.DELAY).success,true));
