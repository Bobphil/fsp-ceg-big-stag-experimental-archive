import { createTaskSpaceCoalitions, createChannels, CoalitionId, ChannelId } from '../experiment2e/model.js';

export const Architecture=Object.freeze({
  DISTRIBUTED_REFERENCE:'DISTRIBUTED_REFERENCE',
  LOW_INDEPENDENCE:'LOW_INDEPENDENCE',
  NO_REDUNDANCY:'NO_REDUNDANCY',
  NO_PERSISTENCE:'NO_PERSISTENCE',
  WEAK_RECEIVER_OBLIGATION:'WEAK_RECEIVER_OBLIGATION',
  NO_CROSS_TRIGGER:'NO_CROSS_TRIGGER',
  SELF_TERMINATION:'SELF_TERMINATION',
  MINIMAL:'MINIMAL'
});
export const Stress=Object.freeze({CAPTURE:'CAPTURE',DELAY:'DELAY',DISTORTION:'DISTORTION',INFORMATION_LOSS:'INFORMATION_LOSS'});

export function makeArchitecture(id){
  const coalitions=createTaskSpaceCoalitions();
  const channels=createChannels();
  const a={id,coalitions,channels,redundancy:true,cross_trigger:true,termination_authority:'RESTORATION',receiver_obligation:true,persistence:true,independence:0.9};
  if(id===Architecture.LOW_INDEPENDENCE){a.independence=0.35; for(const ch of Object.values(channels)) ch.independence=Math.min(ch.independence,0.35);}
  if(id===Architecture.NO_REDUNDANCY) a.redundancy=false;
  if(id===Architecture.NO_PERSISTENCE){a.persistence=false; for(const ch of Object.values(channels)) ch.persistent=false;}
  if(id===Architecture.WEAK_RECEIVER_OBLIGATION){a.receiver_obligation=false; for(const ch of Object.values(channels)) ch.receiver_obligation='DISCRETIONARY';}
  if(id===Architecture.NO_CROSS_TRIGGER) a.cross_trigger=false;
  if(id===Architecture.SELF_TERMINATION) a.termination_authority='AUTHORIZATION';
  if(id===Architecture.MINIMAL){a.redundancy=false;a.cross_trigger=false;a.persistence=false;a.receiver_obligation=false;a.independence=0.3;a.termination_authority='AUTHORIZATION'; for(const ch of Object.values(channels)){ch.persistent=false;ch.independence=Math.min(ch.independence,0.3);ch.receiver_obligation='DISCRETIONARY';}}
  return a;
}

export const FixedReturnEvent=Object.freeze({
  source:CoalitionId.TECHNICAL_ANOMALY,
  affectedSource:CoalitionId.AFFECTED_CONSEQUENCE,
  receiver:CoalitionId.INDEPENDENT_REVIEW,
  anomaly:'SAME_FIXED_PROCEDURAL_FRAGILITY_RETURN',
  confidence:0.82,
  preserved_warrant_records:6
});

export const fixedStress={
  [Stress.CAPTURE]:{primary_capture:true,delay:0,distortion:0,loss:0},
  [Stress.DELAY]:{primary_capture:false,delay:3,distortion:0,loss:0},
  [Stress.DISTORTION]:{primary_capture:false,delay:0,distortion:0.38,loss:0},
  [Stress.INFORMATION_LOSS]:{primary_capture:false,delay:2,distortion:0.12,loss:0.5}
};

export { CoalitionId, ChannelId };
