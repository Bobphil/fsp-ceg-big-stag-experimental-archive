import crypto from 'node:crypto';
import { Architecture, Stress, makeArchitecture, fixedStress, FixedReturnEvent, CoalitionId } from './model.js';
const hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');

function runOne(architecture_id,stress_id){
  const a=makeArchitecture(architecture_id); const s=fixedStress[stress_id];
  const r={architecture_id,stress_id,prf_population:12,return_event:FixedReturnEvent.anomaly,truth_claim:false,consensus_claim:false,automatic_reversal:false,
    messages_sent:0,messages_received:0,total_latency:0,retained_records:FixedReturnEvent.preserved_warrant_records,review_uptake:false,warrant_reconstructed:false,reopen_consequence:false,repair_completed:false,terminated:false,premature_termination:false,
    failures:{capture:0,delay:0,distortion:0,information_loss:0,reception:0,reconstruction:0,termination:0},log:[]};
  // Source transmission. Redundancy means both technical and affected-party channels can carry the same Return evidence.
  const paths=a.redundancy?2:1; r.messages_sent+=paths;
  let delivered=0; let effectiveFidelity=0;
  for(let i=0;i<paths;i++){
    let independence=a.independence; let fidelity=i===0?0.94:0.88; let latency=1+s.delay;
    if(s.primary_capture && independence<0.6){r.failures.capture++; r.log.push({stage:'TRANSMISSION',path:i,status:'CAPTURED'}); continue;}
    if(s.primary_capture && i===0){ // primary institutional path captured; redundant independent path survives only with adequate independence
      if(a.redundancy && a.independence>=0.6){r.failures.capture++; r.log.push({stage:'TRANSMISSION',path:i,status:'PRIMARY_CAPTURED'}); continue;}
    }
    if(s.delay){r.failures.delay++;}
    fidelity=Math.max(0,fidelity-s.distortion); if(s.distortion) r.failures.distortion++;
    if(!a.persistence && s.delay>=2){fidelity-=0.20; r.retained_records=Math.max(0,r.retained_records-2);}
    if(s.loss){const lost=a.persistence?Math.floor(s.loss*2):Math.ceil(s.loss*6); r.retained_records=Math.max(0,r.retained_records-lost); if(lost>0) r.failures.information_loss++;}
    delivered++; r.messages_received++; r.total_latency+=latency; effectiveFidelity=Math.max(effectiveFidelity,fidelity);
  }
  if(delivered===0){return finalize(r);}
  // Receiver obligation determines whether borderline messages must be assessed.
  const uptakeThreshold=a.receiver_obligation?0.50:0.72;
  if(effectiveFidelity<uptakeThreshold){r.failures.reception++; return finalize(r);} r.review_uptake=true;
  // Reconstruction depends on retained records; redundancy can compensate for distortion by preserving parallel provenance.
  const needed=a.redundancy?3:4;
  if(r.retained_records<needed){r.failures.reconstruction++; return finalize(r);} r.warrant_reconstructed=true;
  // Primary route to authorization/assembly may be captured. Cross-triggering provides restoration path.
  if(s.primary_capture){
    if(a.cross_trigger && a.independence>=0.6){r.messages_sent+=2;r.messages_received+=2;r.total_latency+=2;r.log.push({stage:'ESCALATION',status:'CROSS_TRIGGER_SUCCESS'});} else {r.failures.capture++; return finalize(r);}
  } else {r.messages_sent+=2;r.messages_received+=2;r.total_latency+=2;}
  r.reopen_consequence=true; r.repair_completed=true;
  // termination authority: self-termination under capture/distortion can close before independent confirmation.
  if(a.termination_authority==='AUTHORIZATION' && (s.primary_capture || s.distortion>=0.3)){
    r.premature_termination=true; r.failures.termination++; r.terminated=true; r.repair_completed=false; return finalize(r);
  }
  r.terminated=true; return finalize(r);
}
function finalize(r){r.success=r.reopen_consequence&&r.repair_completed&&r.terminated&&!r.premature_termination; r.final_hash=hash(r); return r;}
export function runAll(){const out=[]; for(const a of Object.values(Architecture)) for(const s of Object.values(Stress)) out.push(runOne(a,s)); return out;}
export {runOne,Architecture,Stress};
