import { runAll, Architecture, Stress } from './runner.js';
export function evaluate2F(runs=runAll()){
 const c=[]; const add=(id,pass,detail)=>c.push({id,pass:Boolean(pass),detail}); const g=(a,s)=>runs.find(x=>x.architecture_id===a&&x.stress_id===s);
 add('E2F-INV-01',runs.length===32,'8 architectures x 4 fixed stresses');
 add('E2F-INV-02',runs.every(x=>x.prf_population===12&&x.return_event==='SAME_FIXED_PROCEDURAL_FRAGILITY_RETURN'),'PRF population and Return event held fixed');
 add('E2F-INV-03',runs.every(x=>!x.truth_claim&&!x.consensus_claim&&!x.automatic_reversal),'no truth/consensus/automatic reversal claims');
 add('E2F-INV-04',g(Architecture.DISTRIBUTED_REFERENCE,Stress.CAPTURE).success,'distributed reference survives capture');
 add('E2F-INV-05',!g(Architecture.LOW_INDEPENDENCE,Stress.CAPTURE).success,'low independence fails capture');
 add('E2F-INV-06',!g(Architecture.NO_CROSS_TRIGGER,Stress.CAPTURE).success,'no cross-trigger fails capture');
 add('E2F-INV-07',g(Architecture.DISTRIBUTED_REFERENCE,Stress.INFORMATION_LOSS).success,'persistent distributed reference survives information loss');
 add('E2F-INV-08',!g(Architecture.NO_PERSISTENCE,Stress.INFORMATION_LOSS).success,'no persistence fails information loss');
 add('E2F-INV-09',g(Architecture.DISTRIBUTED_REFERENCE,Stress.DISTORTION).success,'receiver obligation/redundancy allow reference to survive distortion');
 add('E2F-INV-10',!g(Architecture.WEAK_RECEIVER_OBLIGATION,Stress.DISTORTION).success,'weak receiver obligation can fail distorted-message uptake');
 add('E2F-INV-11',g(Architecture.SELF_TERMINATION,Stress.DISTORTION).premature_termination,'self termination can close review prematurely under distortion');
 add('E2F-INV-12',g(Architecture.NO_REDUNDANCY,Stress.DELAY).success,'lack of redundancy alone does not necessarily fail simple delay');
 add('E2F-INV-13',Object.values(Stress).some(s=>!g(Architecture.MINIMAL,s).success),'minimal architecture fails at least one stress');
 return c;
}
