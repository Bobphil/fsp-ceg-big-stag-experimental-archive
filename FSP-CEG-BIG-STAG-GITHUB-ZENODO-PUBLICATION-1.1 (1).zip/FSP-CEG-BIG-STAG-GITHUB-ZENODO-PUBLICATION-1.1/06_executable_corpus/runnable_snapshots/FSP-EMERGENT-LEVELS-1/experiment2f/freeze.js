import fs from 'node:fs'; import crypto from 'node:crypto'; import {runAll} from './runner.js'; import {evaluate2F} from './invariants.js';
const dir='frozen-traces-2f'; fs.mkdirSync(dir,{recursive:true}); const runs=runAll();
for(const r of runs) fs.writeFileSync(`${dir}/${r.architecture_id}__${r.stress_id}.json`,JSON.stringify(r,null,2)+'\n');
const inv=evaluate2F(runs); fs.writeFileSync('results2f/invariants.json',JSON.stringify(inv,null,2)+'\n');
const files=fs.readdirSync(dir).sort(); const lines=files.map(f=>`${crypto.createHash('sha256').update(fs.readFileSync(`${dir}/${f}`)).digest('hex')}  ${f}`); fs.writeFileSync('frozen-traces-2f.sha256',lines.join('\n')+'\n');
console.log(`froze ${runs.length} traces; invariants ${inv.filter(x=>x.pass).length}/${inv.length}`);
