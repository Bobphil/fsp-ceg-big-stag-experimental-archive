import { Scale } from '../recursive-inquiry/model.js';
import { CandidateSharedInvariants } from '../recursive-inquiry-2/model.js';

export const EmergenceStatus = Object.freeze({
  ORGANIZATIONAL: 'SUPPORTED_IN_MODEL',
  EXPLANATORY_AUTONOMY: 'SUPPORTED_IN_BOUNDED_MODEL',
  WEAK_SIMULATION_SENSITIVITY: 'COMPATIBLE_NOT_PROVEN',
  STRONG_ONTOLOGICAL: 'NOT_ESTABLISHED'
});

export const modeledBaseLevel = Object.freeze({
  scale: Scale.INDIVIDUAL,
  role: 'MODELED_BASE_PRF',
  boundary: 'Cognitive/neural emergence below the PRF is outside the present model.'
});

export const emergenceProfiles = Object.freeze([
  {
    scale: Scale.COALITION,
    lowerLevel: Scale.INDIVIDUAL,
    components: ['PRF states','individual evidence assessments','individual warrants','action preferences'],
    organizingRelations: ['warrant compatibility','shared-task relation','conditional joint commitment'],
    emergentPrimitives: ['membership relation','alternative-warrant convergence','joint commitment','coalition proposal'],
    downwardConstraints: ['joint-action feasibility','coalition message eligibility','membership-conditioned commitment'],
    macroState: 'TASK_SPACE_COALITION'
  },
  {
    scale: Scale.INSTITUTIONAL,
    lowerLevel: Scale.COALITION,
    components: ['task-space coalitions','coalition warrants','coalition proposals'],
    organizingRelations: ['standing allocation','agenda relation','plurality procedure','bounded authorization rule'],
    emergentPrimitives: ['institutional standing','authorized proposal','action closure','coercive authority'],
    downwardConstraints: ['available institutional actions','recognized trigger standing','binding action conditions'],
    macroState: 'BOUNDED_AUTHORIZATION'
  },
  {
    scale: Scale.RETURN_NETWORK,
    lowerLevel: Scale.INSTITUTIONAL,
    components: ['source coalitions','review coalitions','authorization coalitions','messages'],
    organizingRelations: ['channel topology','routing obligation','independence relation','persistence relation','escalation relation'],
    emergentPrimitives: ['network reachability','REOPEN uptake','cross-trigger capacity','reconstruction capacity'],
    downwardConstraints: ['message opportunity set','receiver obligations','escalation availability','termination pathway'],
    macroState: 'REOPEN_UPTAKE'
  },
  {
    scale: Scale.CONSTITUTIONAL,
    lowerLevel: Scale.RETURN_NETWORK,
    components: ['institutional failures','Return traces','review outcomes','authorization histories'],
    organizingRelations: ['meta-standing','counter-authority','rule-revision procedure','constitutional escalation relation'],
    emergentPrimitives: ['meta-warrant','constitutional REOPEN','authority reallocation','rule revision'],
    downwardConstraints: ['institutional competence set','review independence','termination authority','future authorization rules'],
    macroState: 'META_REOPEN'
  }
]);

const fixtures = Object.freeze({
  [Scale.COALITION]: [
    {id:'C-A', components:['a','b','c','d'], reasons:['hazard','precaution','monitoring','governance'], relations:{compatibility:true,sharedTask:true,jointCommitment:true}, indicators:{sharedTask:true,coordinatedProposal:true,persistence:true}},
    {id:'C-B', components:['e','f','g','h','i'], reasons:['future-interest','technical','public-standing','reversibility','uncertainty'], relations:{compatibility:true,sharedTask:true,jointCommitment:true}, indicators:{sharedTask:true,coordinatedProposal:true,persistence:true}},
  ],
  [Scale.INSTITUTIONAL]: [
    {id:'I-A', components:['coalition-p2a','coalition-p2b','coalition-p1'], support:{P2:6,P1:4,P3:2}, relations:{standing:true,agenda:true,procedure:true,boundedRule:true}, indicators:{validProcedure:true,standingRecorded:true,actionExecuted:true}},
    {id:'I-B', components:['coalition-p2x','coalition-p3','coalition-p1x','coalition-p1y'], support:{P2:5,P1:4,P3:3}, relations:{standing:true,agenda:true,procedure:true,boundedRule:true}, indicators:{validProcedure:true,standingRecorded:true,actionExecuted:true}},
  ],
  [Scale.RETURN_NETWORK]: [
    {id:'R-A', components:['affected','review','authorization'], paths:['affected>review','review>authorization'], relations:{topology:true,routingObligation:true,independence:true,persistence:true,escalation:true}, indicators:{reviewReceipt:true,warrantUpdated:true,escalationAvailable:true}},
    {id:'R-B', components:['technical','restoration','assembly'], paths:['technical>restoration','restoration>assembly'], relations:{topology:true,routingObligation:true,independence:true,persistence:true,escalation:true}, indicators:{reviewReceipt:true,warrantUpdated:true,escalationAvailable:true}},
  ],
  [Scale.CONSTITUTIONAL]: [
    {id:'K-A', components:['capture','premature-closure','topology-loss'], failures:3, relations:{metaStanding:true,counterAuthority:true,revisionProcedure:true,constitutionalEscalation:true}, indicators:{crossCasePattern:true,counterAuthorityActivated:true,ruleRevisionOpened:true}},
    {id:'K-B', components:['standing-failure','termination-failure','authority-lockin'], failures:3, relations:{metaStanding:true,counterAuthority:true,revisionProcedure:true,constitutionalEscalation:true}, indicators:{crossCasePattern:true,counterAuthorityActivated:true,ruleRevisionOpened:true}},
  ]
});

export function profile(scale){
  const p=emergenceProfiles.find(x=>x.scale===scale);
  if(!p) throw new Error(`unknown emergent scale ${scale}`);
  return p;
}

export function realizations(scale){ return fixtures[scale].map(x=>structuredClone(x)); }

export function macroState(scale, state){
  if(scale===Scale.COALITION){
    const r=state.relations;
    return r.compatibility && r.sharedTask && r.jointCommitment ? 'TASK_SPACE_COALITION' : 'FRAGMENTED_PRFS';
  }
  if(scale===Scale.INSTITUTIONAL){
    const r=state.relations;
    if(!(r.standing && r.agenda && r.procedure && r.boundedRule)) return 'NO_VALID_AUTHORIZATION';
    const entries=Object.entries(state.support).sort((a,b)=>b[1]-a[1] || a[0].localeCompare(b[0]));
    return `AUTHORIZED_${entries[0][0]}`;
  }
  if(scale===Scale.RETURN_NETWORK){
    const r=state.relations;
    return r.topology && r.routingObligation && r.independence && r.persistence && r.escalation ? 'REOPEN_UPTAKE' : 'RETURN_PATH_DEGRADED';
  }
  if(scale===Scale.CONSTITUTIONAL){
    const r=state.relations;
    return state.failures>=2 && r.metaStanding && r.counterAuthority && r.revisionProcedure && r.constitutionalEscalation ? 'META_REOPEN' : 'CONSTITUTIONAL_STASIS';
  }
  throw new Error(`unknown emergent scale ${scale}`);
}

export function ablateOrganization(scale, state){
  const x=structuredClone(state);
  if(scale===Scale.COALITION) x.relations.sharedTask=false;
  if(scale===Scale.INSTITUTIONAL) x.relations.procedure=false;
  if(scale===Scale.RETURN_NETWORK) x.relations.topology=false;
  if(scale===Scale.CONSTITUTIONAL) x.relations.counterAuthority=false;
  return x;
}

export function organizationDependence(scale){
  const x=realizations(scale)[0];
  return {organized:macroState(scale,x),disorganized:macroState(scale,ablateOrganization(scale,x))};
}

export function multipleRealizability(scale){
  const rs=realizations(scale);
  const signatures=new Set(rs.map(r=>JSON.stringify({components:r.components,reasons:r.reasons??null,paths:r.paths??null,support:r.support??null})));
  const macros=new Set(rs.map(r=>macroState(scale,r)));
  return {distinctMicrostates:signatures.size,macroStates:[...macros],realized:signatures.size>=2 && macros.size===1};
}

export function emergentVocabularyIsNovel(scale){
  const p=profile(scale);
  const lowerVocabulary=new Set(p.components.flatMap(s=>s.toLowerCase().split(/[^a-z]+/).filter(Boolean)));
  return p.emergentPrimitives.every(term=>{
    const words=term.toLowerCase().split(/[^a-z]+/).filter(Boolean);
    return !words.every(w=>lowerVocabulary.has(w));
  });
}

export function independentMacroIndicators(scale,state){
  const vals=Object.values(state.indicators??{});
  return {count:vals.length,positive:vals.filter(Boolean).length,robust:vals.length>=3 && vals.every(Boolean)};
}

export function componentInventoryPredictor(scale,state){
  // Deliberately organization-blind: it sees how many components are present, not how they are related.
  const n=state.components?.length ?? 0;
  if(scale===Scale.COALITION) return n>=3?'TASK_SPACE_COALITION':'FRAGMENTED_PRFS';
  if(scale===Scale.INSTITUTIONAL) return n>=3?'AUTHORIZED_P2':'NO_VALID_AUTHORIZATION';
  if(scale===Scale.RETURN_NETWORK) return n>=3?'REOPEN_UPTAKE':'RETURN_PATH_DEGRADED';
  if(scale===Scale.CONSTITUTIONAL) return n>=2?'META_REOPEN':'CONSTITUTIONAL_STASIS';
}

export function organizationAwarePredictor(scale,state){ return macroState(scale,state); }

export function autonomyProbe(scale){
  const organized=realizations(scale)[0];
  const disorganized=ablateOrganization(scale,organized);
  const truth=[macroState(scale,organized),macroState(scale,disorganized)];
  const inventory=[componentInventoryPredictor(scale,organized),componentInventoryPredictor(scale,disorganized)];
  const organization=[organizationAwarePredictor(scale,organized),organizationAwarePredictor(scale,disorganized)];
  const score=pred=>pred.filter((x,i)=>x===truth[i]).length;
  return {truth,inventory,organization,inventoryScore:score(inventory),organizationScore:score(organization),organizationAddsLeverage:score(organization)>score(inventory)};
}

export function applyDownwardConstraint(scale, prfState, rule){
  const before=structuredClone(prfState);
  const after=structuredClone(prfState);
  const available=new Set(after.availableActions??[]);
  if(rule?.prohibit) for(const a of rule.prohibit) available.delete(a);
  if(rule?.permit) for(const a of rule.permit) available.add(a);
  after.availableActions=[...available].sort();
  return {
    scale,
    mechanism:'OPPORTUNITY_SET_CONSTRAINT',
    intrinsicStateUnchanged:JSON.stringify(before.beliefs)===JSON.stringify(after.beliefs) && JSON.stringify(before.warrants)===JSON.stringify(after.warrants),
    before,after
  };
}

export function recursiveWithoutReduction(){
  return emergenceProfiles.map(p=>({
    scale:p.scale,
    sharedGrammar:[...CandidateSharedInvariants],
    emergentPrimitives:[...p.emergentPrimitives],
    reductionClaim:'REJECTED',
    dependenceClaim:'SUPPORTED_IN_MODEL'
  }));
}

export function strongEmergenceEstablished(){ return false; }
export function currentEmergenceThesis(){
  return 'ORGANIZATIONAL_AND_EXPLANATORY_EMERGENCE_WITH_DEPENDENCE_AND_SCALE_SPECIFIC_PRIMITIVES';
}
