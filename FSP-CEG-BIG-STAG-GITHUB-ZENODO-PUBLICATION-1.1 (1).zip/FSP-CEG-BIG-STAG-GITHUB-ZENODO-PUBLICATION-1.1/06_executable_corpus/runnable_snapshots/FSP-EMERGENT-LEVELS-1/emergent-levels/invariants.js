import { Scale } from '../recursive-inquiry/model.js';
import {
 emergenceProfiles,organizationDependence,multipleRealizability,emergentVocabularyIsNovel,independentMacroIndicators,
 realizations,autonomyProbe,applyDownwardConstraint,recursiveWithoutReduction,strongEmergenceEstablished,currentEmergenceThesis,modeledBaseLevel
} from './model.js';

export function evaluateEmergentLevels(){
  const r=[]; const p=(name,pass,detail='')=>r.push({name,pass:!!pass,detail});
  const scales=[Scale.COALITION,Scale.INSTITUTIONAL,Scale.RETURN_NETWORK,Scale.CONSTITUTIONAL];
  p('EL-01 individual PRF is explicit modeled base rather than silently reduced',modeledBaseLevel.role==='MODELED_BASE_PRF');
  p('EL-02 every modeled higher level has explicit organizing relations and emergent primitives',emergenceProfiles.every(x=>x.organizingRelations.length>0&&x.emergentPrimitives.length>0));
  p('EL-03 organizational dependence holds across emergent levels',scales.every(s=>{const x=organizationDependence(s);return x.organized!==x.disorganized;}));
  p('EL-04 novelty test: each higher level introduces vocabulary not predicable of isolated component inventory',scales.every(emergentVocabularyIsNovel));
  p('EL-05 multiple realizability holds across modeled emergent levels',scales.every(s=>multipleRealizability(s).realized));
  p('EL-06 robust macro identification uses at least three independent positive indicators',scales.every(s=>realizations(s).every(x=>independentMacroIndicators(s,x).robust)));
  p('EL-07 organization-aware variables add predictive/explanatory leverage over component inventory alone',scales.every(s=>autonomyProbe(s).organizationAddsLeverage));
  const base={beliefs:{hazard:'high',governance:'concerned'},warrants:{P2:'conditional'},availableActions:['P1','P2','P3']};
  const dc=applyDownwardConstraint(Scale.INSTITUTIONAL,base,{prohibit:['P3']});
  p('EL-08 downward influence is represented as opportunity-set constraint',dc.mechanism==='OPPORTUNITY_SET_CONSTRAINT'&&dc.after.availableActions.length===2);
  p('EL-09 downward constraint leaves intrinsic PRF beliefs/warrants unchanged unless separately updated',dc.intrinsicStateUnchanged===true);
  p('EL-10 higher-level organization is dependent yet not eliminated from explanation',recursiveWithoutReduction().every(x=>x.dependenceClaim==='SUPPORTED_IN_MODEL'&&x.reductionClaim==='REJECTED'));
  p('EL-11 recursive grammar coexists with scale-specific primitives',recursiveWithoutReduction().every(x=>x.sharedGrammar.length>=6&&x.emergentPrimitives.length>0));
  p('EL-12 strong ontological emergence is not claimed',strongEmergenceEstablished()===false);
  p('EL-13 current thesis is organizational/explanatory emergence rather than strict reduction or strong emergence',currentEmergenceThesis().includes('ORGANIZATIONAL_AND_EXPLANATORY'));
  p('EL-14 autonomy probe is counterfactual: same component inventory can differ when organization changes',scales.every(s=>{const a=autonomyProbe(s);return a.truth[0]!==a.truth[1]&&a.inventory[0]===a.inventory[1];}));
  p('EL-15 multiple realization does not imply microstate identity',scales.every(s=>multipleRealizability(s).distinctMicrostates>=2));
  p('EL-16 emergence is tested above, not below, the modeled PRF boundary',!emergenceProfiles.some(x=>x.scale===Scale.INDIVIDUAL));
  return r;
}
