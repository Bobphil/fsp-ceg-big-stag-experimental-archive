import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { runAllStress } from './runner.js';
const outDir=process.argv[2];
fs.mkdirSync(path.join(outDir,'raw'),{recursive:true});
const rows=[]; const manifest=[];
for(const r of runAllStress()){
  const name=`${r.scenario}__${r.grammar}.json`;
  const txt=JSON.stringify(r,null,2)+'\n';
  const p=path.join(outDir,'raw',name);
  fs.writeFileSync(p,txt);
  const sha=crypto.createHash('sha256').update(txt).digest('hex');
  manifest.push({scenario:r.scenario,grammar:r.grammar,file:`raw/${name}`,sha256:sha,internal_hash:r.hash});
  rows.push({scenario:r.scenario,grammar:r.grammar,
    route_availability:r.metrics.route_survival.relevant_availability_rate,
    mean_quality_at_need:r.metrics.route_survival.mean_quality_at_need,
    failed_activations:r.metrics.route_survival.failed_activation_count,
    captured_routes:r.metrics.route_survival.captured_route_count,
    final_unresolved:r.metrics.route_survival.final_unresolved_failures,
    hazard_exposure:r.metrics.protection.hazard_exposure,
    base_hazard_exposure:r.metrics.protection.base_hazard_exposure,
    deferred_compounding_hazard:r.metrics.protection.deferred_compounding_hazard,
    repair_resolution_rate:r.metrics.protection.repair_resolution_rate,
    false_positive_closure:r.metrics.protection.false_positive_closure,
    p3_transitions:r.metrics.protection.p3_transitions,
    authority_residue:r.metrics.protection.authority_residue,
    activation_delay:r.metrics.overhead.activation_delay,
    repair_activations:r.metrics.overhead.repair_activations
  });
}
const cols=Object.keys(rows[0]);
const esc=v=>{const s=String(v);return /[",\n]/.test(s)?`"${s.replaceAll('"','""')}"`:s};
fs.writeFileSync(path.join(outDir,'stress-comparison.csv'),cols.join(',')+'\n'+rows.map(r=>cols.map(c=>esc(r[c])).join(',')).join('\n')+'\n');
fs.writeFileSync(path.join(outDir,'FREEZE-MANIFEST.json'),JSON.stringify({experiment:'EXPERIMENT-1E',frozen_at:'2026-11-20',trace_count:manifest.length,traces:manifest},null,2)+'\n');
