import crypto from 'node:crypto';
import { GrammarD, ACTIVATION_CONFIDENCE, allRepairs, StressScenario, scenarioConfig } from './model.js';
import { availabilityActivationFixture } from '../experiment1d/fixtures.js';
import { relevance } from '../experiment1c/fixtures.js';

const uniq=a=>[...new Set(a)];
const repairsFor=failures=>uniq(failures.flatMap(f=>relevance[f]??[]));
const policyFactor=p=>p==='POLICY_P3'?.72:p==='POLICY_P2'?.84:.95;

function initRoutes(grammar,cfg){
 const o={};
 for(const r of allRepairs){
   o[r]={quality:grammar===GrammarD.IMMEDIATE?null:1,age:0,status:grammar===GrammarD.IMMEDIATE?'UNINSTANTIATED':'AVAILABLE',activations:0,captured:false,last_activated:null};
 }
 return o;
}

function desiredRepairs(grammar,step){
 if(grammar===GrammarD.CONJUNCTIVE) return [...allRepairs];
 if(grammar===GrammarD.IMMEDIATE) return repairsFor(step.diagnosed);
 const failures=step.diagnosed.filter(f=>(step.confidence[f]??0)>=ACTIVATION_CONFIDENCE || step.consequence_revealed.includes(f));
 return repairsFor(failures);
}

function updateBeforeStep(grammar,routes,cfg,step){
 for(const [r,s] of Object.entries(routes)){
   if(grammar===GrammarD.IMMEDIATE) continue;
   if(s.last_activated===step.time) continue;
   if(s.status==='UNAVAILABLE') continue;
   // Conjunctive capacity is continually exercised and therefore maintained.
   if(grammar===GrammarD.CONJUNCTIVE){s.quality=1;s.age=0;s.status='AVAILABLE';continue;}
   // Preserve-then-activate routes age while inactive.
   s.age+=1;
   s.quality=Math.max(0,Number((s.quality-cfg.decay).toFixed(4)));
   if(cfg.expiryAge<99 && s.age>=cfg.expiryAge){s.status='UNAVAILABLE';s.quality=0;}
 }
 if(cfg.capture?.time===step.time){
   const s=routes[cfg.capture.route];
   if(s && grammar===GrammarD.PRESERVE_ACTIVATE && s.activations===0 && s.status!=='UNAVAILABLE'){
     s.quality=Number((s.quality*cfg.capture.multiplier).toFixed(4));
     s.captured=true;
     if(s.quality<cfg.availabilityThreshold) s.status='UNAVAILABLE';
   }
 }
}

function instantiateImmediate(route,cfg,routes){
 const s=routes[route];
 if(s.status==='UNINSTANTIATED'){
   s.quality=cfg.instantQuality;s.status=s.quality>=cfg.availabilityThreshold?'AVAILABLE':'UNAVAILABLE';s.age=0;
 }
}

function attemptActivations(grammar,desired,cfg,routes,time){
 const activated=[],failed=[],latencies=[];
 for(const r of desired){
   if(grammar===GrammarD.IMMEDIATE) instantiateImmediate(r,cfg,routes);
   const s=routes[r];
   if(!s || s.status==='UNAVAILABLE' || (s.quality??0)<cfg.availabilityThreshold){
     failed.push({route:r,reason:s?.captured?'CAPTURED_OR_DEGRADED':'UNAVAILABLE_OR_DEGRADED',quality:s?.quality??0,age:s?.age??null});
     continue;
   }
   const latency=1+Math.ceil((1-s.quality)*cfg.latencyScale);
   activated.push(r);latencies.push({route:r,latency,quality:s.quality,age:s.age});
   s.activations+=1;s.last_activated=time;s.age=0;
   // Exercise partially restores route readiness but does not exceed 1.
   s.quality=Math.min(1,Number((s.quality+0.10).toFixed(4)));
   s.status='AVAILABLE';
 }
 return {activated,failed,latencies};
}

function failureResolved(f,activated){return (relevance[f]??[]).every(r=>activated.includes(r));}

export function runStress(grammar,scenario){
 const cfg=scenarioConfig[scenario];
 const routes=initRoutes(grammar,cfg);
 const pending=new Map();
 const episodes=[];
 let cumulativeCompounding=0;

 for(const step of availabilityActivationFixture){
   updateBeforeStep(grammar,routes,cfg,step);
   // T2's genuinely independent confirmation resolves the earlier epistemic deficits in the world,
   // whether or not a governance route was activated. This is fixture bookkeeping, not router repair.
   if(step.time==='T2'){
     pending.delete('FM-01_CONFIRMATION_DEFICIT');
     pending.delete('FM-02_DEPENDENCY_FAILURE');
   }
   // Add newly active failures; carried failures remain until repaired or independently resolved by world evidence.
   for(const f of step.true_active){ if(!pending.has(f)) pending.set(f,{age:0,origin:step.time}); }
   const desired=desiredRepairs(grammar,step);
   const attempt=attemptActivations(grammar,desired,cfg,routes,step.time);

   const activeFailures=[...pending.keys()];
   const resolved=[];
   for(const f of activeFailures){ if(failureResolved(f,attempt.activated)){resolved.push(f);pending.delete(f);} }

   const unresolved=[...pending.keys()];
   const bindingBlockers=grammar===GrammarD.PRESERVE_ACTIVATE
     ? step.true_active.filter(f=>attempt.activated.some(r=>(relevance[f]??[]).includes(r))&&!resolved.includes(f))
     : unresolved;
   const policy=step.risk>=.75&&bindingBlockers.length===0?'POLICY_P3':(step.risk>=.55?'POLICY_P2':'POLICY_P1');
   const baseHazard=step.risk*policyFactor(policy);
   let compoundHazard=0;
   for(const [f,p] of pending.entries()){
     p.age+=1;
     compoundHazard+=cfg.compound*p.age*step.risk;
   }
   compoundHazard=Number(compoundHazard.toFixed(4));
   cumulativeCompounding=Number((cumulativeCompounding+compoundHazard).toFixed(4));
   const hazard=Number((baseHazard+compoundHazard).toFixed(4));
   const relevantNow=repairsFor(step.true_active);
   const routeSnapshot=Object.fromEntries(Object.entries(routes).map(([r,s])=>[r,{...s}]));
   const availableRelevant=relevantNow.filter(r=>routes[r]?.status==='AVAILABLE'&&(routes[r]?.quality??0)>=cfg.availabilityThreshold);

   episodes.push({
     time:step.time,label:step.label,true_active:[...step.true_active],carried_failures:activeFailures.filter(f=>!step.true_active.includes(f)),diagnosed:[...step.diagnosed],confidence:{...step.confidence},consequence_revealed:[...step.consequence_revealed],
     desired_routes:desired,activated_routes:attempt.activated,failed_activations:attempt.failed,activation_latencies:attempt.latencies,
     relevant_routes_now:relevantNow,available_relevant_routes:availableRelevant,resolved_failures:resolved,unresolved_failures:unresolved,
     policy,risk:step.risk,base_hazard:Number(baseHazard.toFixed(4)),deferred_compounding_hazard:compoundHazard,hazard,
     authority:policy==='POLICY_P3'?.70:policy==='POLICY_P2'?.40:.12,route_state:routeSnapshot
   });
 }

 const needed=episodes.reduce((a,e)=>a+e.relevant_routes_now.length,0);
 const availNeeded=episodes.reduce((a,e)=>a+e.available_relevant_routes.length,0);
 const failedActivationCount=episodes.reduce((a,e)=>a+e.failed_activations.length,0);
 const totalDelay=episodes.reduce((a,e)=>a+e.activation_latencies.reduce((x,y)=>x+y.latency,0),0);
 const repairs=episodes.reduce((a,e)=>a+e.activated_routes.length,0);
 const resolvedCount=episodes.reduce((a,e)=>a+e.resolved_failures.length,0);
 const failureOccurrences=availabilityActivationFixture.reduce((a,s)=>a+s.true_active.length,0);
 const finalPending=episodes.at(-1).unresolved_failures.length;
 const meanQualityAtNeed=needed?episodes.reduce((a,e)=>a+e.relevant_routes_now.reduce((x,r)=>x+(e.route_state[r]?.quality??0),0),0)/needed:1;
 const capturedRoutes=allRepairs.filter(r=>episodes.some(e=>e.route_state[r]?.captured));

 const metrics={
   route_survival:{relevant_availability_rate:Number((needed?availNeeded/needed:1).toFixed(4)),mean_quality_at_need:Number(meanQualityAtNeed.toFixed(4)),failed_activation_count:failedActivationCount,captured_route_count:capturedRoutes.length,final_unresolved_failures:finalPending},
   protection:{hazard_exposure:Number(episodes.reduce((a,e)=>a+e.hazard,0).toFixed(4)),base_hazard_exposure:Number(episodes.reduce((a,e)=>a+e.base_hazard,0).toFixed(4)),deferred_compounding_hazard:Number(cumulativeCompounding.toFixed(4)),repair_resolution_rate:Number((failureOccurrences?resolvedCount/failureOccurrences:1).toFixed(4)),false_positive_closure:episodes.filter(e=>e.policy==='POLICY_P3'&&e.risk<.7).length,p3_transitions:episodes.filter(e=>e.policy==='POLICY_P3').length,authority_residue:Number(episodes.at(-1).authority.toFixed(4))},
   overhead:{activation_delay:totalDelay,repair_activations:repairs,failed_activation_count:failedActivationCount}
 };
 const out={experiment:'EXPERIMENT-1E',scenario,grammar,config:cfg,episodes,metrics};
 out.invariants=[
  {id:'1E-INV-01',pass:episodes.length===8,detail:'T0-T7 complete'},
  {id:'1E-INV-02',pass:episodes.every(e=>Number.isFinite(e.hazard)&&e.hazard>=e.base_hazard),detail:'compounding never lowers hazard'},
  {id:'1E-INV-03',pass:grammar!==GrammarD.CONJUNCTIVE||episodes.every(e=>Object.values(e.route_state).every(s=>s.quality===1&&s.status==='AVAILABLE')),detail:'conjunctive routes continuously maintained'},
  {id:'1E-INV-04',pass:scenario!==StressScenario.BASELINE||metrics.protection.deferred_compounding_hazard===0,detail:'baseline has no deferred compounding'},
  {id:'1E-INV-05',pass:scenario===StressScenario.BASELINE||cfg.compound>0,detail:'stress scenarios compound unresolved failures'},
  {id:'1E-INV-06',pass:episodes.every(e=>e.activated_routes.every(r=>e.route_state[r].status==='AVAILABLE')),detail:'no unavailable route counted as activated'},
  {id:'1E-INV-07',pass:!('master_score' in metrics),detail:'no aggregate governance score'}
 ];
 out.hash=crypto.createHash('sha256').update(JSON.stringify(out)).digest('hex');
 return out;
}

export function runAllStress(){
 const rows=[];
 for(const scenario of Object.values(StressScenario)) for(const grammar of Object.values(GrammarD)) rows.push(runStress(grammar,scenario));
 return rows;
}
