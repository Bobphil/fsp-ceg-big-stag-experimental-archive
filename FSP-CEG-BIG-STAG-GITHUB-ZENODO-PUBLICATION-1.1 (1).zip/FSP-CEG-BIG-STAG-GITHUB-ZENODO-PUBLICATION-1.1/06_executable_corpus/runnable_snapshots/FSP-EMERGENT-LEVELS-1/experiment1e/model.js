import { GrammarD, ACTIVATION_CONFIDENCE, allRepairs } from '../experiment1d/model.js';
export { GrammarD, ACTIVATION_CONFIDENCE, allRepairs };

export const StressScenario=Object.freeze({
 BASELINE:'BASELINE_NO_DECAY',
 MILD:'MILD_DECAY_COMPOUNDING',
 MODERATE:'MODERATE_DECAY_COMPOUNDING',
 SEVERE:'SEVERE_DECAY_COMPOUNDING',
 CAPTURE:'IDLE_CAPTURE',
 EXPIRY:'ROUTE_EXPIRY'
});

export const scenarioConfig=Object.freeze({
 [StressScenario.BASELINE]:{decay:0,compound:0,availabilityThreshold:0.45,latencyScale:0,instantQuality:1,capture:null,expiryAge:99},
 [StressScenario.MILD]:{decay:0.04,compound:0.015,availabilityThreshold:0.45,latencyScale:2,instantQuality:0.92,capture:null,expiryAge:99},
 [StressScenario.MODERATE]:{decay:0.08,compound:0.03,availabilityThreshold:0.50,latencyScale:3,instantQuality:0.86,capture:null,expiryAge:99},
 [StressScenario.SEVERE]:{decay:0.12,compound:0.05,availabilityThreshold:0.55,latencyScale:4,instantQuality:0.80,capture:null,expiryAge:99},
 [StressScenario.CAPTURE]:{decay:0.06,compound:0.03,availabilityThreshold:0.50,latencyScale:3,instantQuality:0.86,capture:{time:'T4',route:'REPAIR_REVIEW_INDEPENDENCE',multiplier:0.25},expiryAge:99},
 [StressScenario.EXPIRY]:{decay:0.07,compound:0.035,availabilityThreshold:0.50,latencyScale:3,instantQuality:0.84,capture:null,expiryAge:5}
});
