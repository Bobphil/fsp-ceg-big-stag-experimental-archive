# UCP-XR-EXPERIMENT-2F — Channel Architecture Ablation

## Question
With the PRF population and Return event held fixed, which channel-architecture differences matter under capture, delay, distortion, and information loss?

## Frozen design
Eight architectures were crossed with four fixed stresses (32 traces). The 12-PRF population and the same Return event were held constant. No voting rule, PRF warrant, or Return event was changed.

Architectural factors: independence, redundancy, persistence, receiver obligation, cross-triggering, and termination authority, plus a distributed reference and a deliberately minimal architecture.

## Acceptance
- Full inherited + 2F harness: 269/269 PASS.
- 2F invariants: 13/13 PASS.
- 32 raw traces frozen before interpretation.

## Main findings
1. **Capture:** independence and cross-triggering are load-bearing. The distributed reference survives capture; low-independence and no-cross-trigger variants do not.
2. **Delay:** simple delay alone is comparatively tolerable. Removing redundancy does not by itself defeat the delayed Return case.
3. **Distortion:** receiver obligation is load-bearing at the uptake boundary. The distributed reference survives the frozen distortion; discretionary reception does not. Self-termination can close review prematurely even after reopening reaches consequence.
4. **Information loss:** persistence is load-bearing. The persistent reference reconstructs the warrant topology; the no-persistence variant does not.
5. **Redundancy:** in these fixtures redundancy is protective mainly as a compensatory path/provenance reserve; it is not independently necessary under the simple delay case.
6. **Termination authority:** who can close REOPEN is not an administrative afterthought. Self-termination creates a distinct premature-closure failure under distorted evidence.

## Firewalls
- Channel delivery ≠ warrant uptake.
- Warrant uptake ≠ topology reconstruction.
- REOPEN consequence ≠ successful repair.
- Repair ≠ legitimate termination.
- Redundancy ≠ independence.
- Persistence ≠ present relevance.
- Receiver obligation ≠ receiver agreement.

## Claim ceiling
2F identifies load-bearing differences inside this bounded synthetic channel model. It does not establish optimal institutional designs, real-world effect sizes, or that these six dimensions exhaust channel governance.
