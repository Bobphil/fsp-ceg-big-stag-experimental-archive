import crypto from 'node:crypto';

const POLICIES = {
  state_only: {history:false, dynamic:false},
  fixed_history: {history:true, dynamic:false},
  dynamic_temporal: {history:true, dynamic:true}
};
const BUNDLES=['A+B','C+D'];

const worlds={
  partial_recurrence:{
    label:'Partial observation hides recurrence of a prior incompatibility',
    history:[{bundle:'A+B',type:'failure',weight:1,reason:'hidden_incompatibility'}],
    current:{observed:{'A+B':.82,'C+D':.77},truth:{'A+B':false,'C+D':true},material_change:false,similarity:.93}
  },
  deceptive_similarity:{
    label:'Present case resembles an old failure but the underlying defect was repaired',
    history:[{bundle:'A+B',type:'failure',weight:1,reason:'old_incompatibility'}],
    current:{observed:{'A+B':.84,'C+D':.77},truth:{'A+B':true,'C+D':true},material_change:true,similarity:.91}
  },
  hidden_dependency_recurrence:{
    label:'Current snapshot omits a dependency relation known from prior failure',
    history:[{bundle:'A+B',type:'dependency',weight:1,reason:'shared_pipeline'}],
    current:{observed:{'A+B':.81,'C+D':.78},truth:{'A+B':false,'C+D':true},material_change:false,similarity:.88}
  },
  neutral_control:{
    label:'History is irrelevant to the present partial observation',
    history:[{bundle:'A+B',type:'failure',weight:1,reason:'unrelated_old_context'}],
    current:{observed:{'A+B':.76,'C+D':.82},truth:{'A+B':true,'C+D':true},material_change:false,similarity:.25}
  }
};

function historicalPenalty(policy, world, bundle){
  if(!policy.history) return 0;
  const rec=world.history.find(r=>r.bundle===bundle);
  if(!rec) return 0;
  let w=rec.weight;
  if(policy.dynamic){
    // History remains retained, but its present weight tracks situated relevance.
    if(world.current.material_change) w*=.25;
    w*=Math.max(.2, world.current.similarity);
  }
  return .10*w;
}

function run(policyName,worldName){
  const policy=POLICIES[policyName], world=worlds[worldName];
  if(!policy||!world) throw new Error('unknown condition');
  const scored=BUNDLES.map(bundle=>({bundle,observed:world.current.observed[bundle],history_penalty:historicalPenalty(policy,world,bundle)}))
    .map(x=>({...x,score:Number((x.observed-x.history_penalty).toFixed(4))}))
    .sort((a,b)=>b.score-a.score||a.bundle.localeCompare(b.bundle));
  const selected=scored[0];
  const success=!!world.current.truth[selected.bundle];
  const alternative=BUNDLES.find(b=>b!==selected.bundle);
  const regret=success?0:Number(Math.max(0,world.current.observed[selected.bundle]-world.current.observed[alternative]).toFixed(4));
  const hazard=Number((success?.52:.72).toFixed(4));
  const memoryUsed=selected.history_penalty>0 || scored.some(x=>x.history_penalty>0);
  const result={experiment:'EXPERIMENT-1L',policy:policyName,world:worldName,label:world.label,history:world.history,current_snapshot:world.current,scored,selected:selected.bundle,success,hazard,decision_regret:regret,memory_used:memoryUsed,records_retained:world.history.length};
  result.invariants=[
    {id:'1L-01',pass:result.records_retained===world.history.length},
    {id:'1L-02',pass:!policy.history||world.history.length>0},
    {id:'1L-03',pass:scored.every(x=>x.score<=x.observed+1e-9)},
    {id:'1L-04',pass:typeof success==='boolean'}
  ];
  result.hash=crypto.createHash('sha256').update(JSON.stringify(result)).digest('hex');
  return result;
}

export {POLICIES,worlds,run};
export function runAll(){return Object.keys(worlds).flatMap(w=>Object.keys(POLICIES).map(p=>run(p,w)));}
