import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import {runAll} from './runner.js';
const outDir=new URL('../../frozen-traces-1l/',import.meta.url);fs.rmSync(outDir,{recursive:true,force:true});fs.mkdirSync(outDir,{recursive:true});
const manifest=[];for(const r of runAll()){const fn=`${r.world}__${r.policy}.json`;const s=JSON.stringify(r,null,2)+'\n';fs.writeFileSync(new URL(fn,outDir),s);manifest.push({file:fn,sha256:crypto.createHash('sha256').update(s).digest('hex'),run_hash:r.hash});}
const m={experiment:'EXPERIMENT-1L',count:manifest.length,files:manifest};fs.writeFileSync(new URL('FREEZE-MANIFEST.json',outDir),JSON.stringify(m,null,2)+'\n');console.log(JSON.stringify(m));
