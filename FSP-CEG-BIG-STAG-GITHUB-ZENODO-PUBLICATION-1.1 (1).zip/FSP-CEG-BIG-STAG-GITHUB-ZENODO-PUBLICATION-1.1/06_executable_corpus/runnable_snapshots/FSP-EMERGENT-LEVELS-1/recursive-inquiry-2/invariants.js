import {scales} from '../recursive-inquiry/model.js';
import {
 CandidateSharedInvariants,decompositionLedger,failureFamilies,strictDecompositionWithoutRemainder,decompositionWithExplicitRemainder,
 strictFailureIsomorphism,recurrentFailureCore,allSharedInvariantsHold,ablateInvariant,sufficientDecompression,
 informationBridge,informationMetricsAuthorize,informationMetricsAssignStanding
} from './model.js';

export function evaluate(){
 const r=[];const p=(name,pass,detail='')=>r.push({name,pass:!!pass,detail});
 p('R2-01 strict decomposition without remainder is rejected', strictDecompositionWithoutRemainder()===false);
 p('R2-02 every scale decomposes with explicit scale-specific remainder',decompositionWithExplicitRemainder());
 p('R2-03 decomposition ledger covers every scale',decompositionLedger.length===scales.length);
 p('R2-04 strict failure isomorphism is rejected',strictFailureIsomorphism()===false);
 p('R2-05 recurrent failure core is nonempty',recurrentFailureCore().length>=3,recurrentFailureCore().join(','));
 p('R2-06 scale-specific failure families remain',Object.values(failureFamilies).some(xs=>xs.length===1));
 p('R2-07 all candidate shared invariants hold across scales',allSharedInvariantsHold());
 p('R2-08 each shared invariant is independently necessary in the admissibility model',CandidateSharedInvariants.every(k=>ablateInvariant(k).admissible===false));
 p('R2-09 minimal invariant set contains no authorization-as-truth rule',!CandidateSharedInvariants.some(k=>k.includes('TRUTH')));
 const early=sufficientDecompression({triggerAddressed:true,relevantDistinctionsRecovered:false,affectedStandingIncluded:true,authorizationReassessmentPossible:true,actionSensitiveOpen:1,residualUncertaintyRecorded:true,futureReopenRoutePreserved:true});
 p('R2-10 non-regress rule rejects premature stopping',early.stop===false && early.outcome==='CONTINUE_DECOMPRESSION');
 const enough=sufficientDecompression({triggerAddressed:true,relevantDistinctionsRecovered:true,affectedStandingIncluded:true,authorizationReassessmentPossible:true,actionSensitiveOpen:0,residualUncertaintyRecorded:true,futureReopenRoutePreserved:true});
 p('R2-11 sufficient decompression permits stopping before total detail recovery',enough.stop===true && enough.outcome==='SUFFICIENT_DECOMPRESSION');
 const irrecoverable=sufficientDecompression({triggerAddressed:true,relevantDistinctionsIrrecoverable:true,affectedStandingIncluded:true,authorizationReassessmentPossible:false,actionSensitiveOpen:1,residualUncertaintyRecorded:true,futureReopenRoutePreserved:true,escalationAvailable:true});
 p('R2-12 irrecoverability routes upward rather than recursing locally forever',irrecoverable.stop===true && irrecoverable.outcome==='ESCALATE_AND_RECOMPOSE');
 const bridge=informationBridge({inputStates:100,activeStates:20,residueStates:50,returnSignals:10,normative:{standing:'affected-party',authorization:'bounded'}});
 p('R2-13 information bridge reports descriptive compression metrics',bridge.descriptive.compressionRatio===0.2 && bridge.descriptive.residueRatio===0.5);
 p('R2-14 normative fields remain externally supplied',bridge.normative.source==='EXTERNAL_NORMATIVE_GOVERNANCE' && bridge.normative.standing==='affected-party');
 p('R2-15 information metrics cannot assign standing',informationMetricsAssignStanding()===false);
 p('R2-16 information metrics cannot authorize action',informationMetricsAuthorize()===false);
 return r;
}
