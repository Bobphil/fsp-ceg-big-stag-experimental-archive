import { Scale, scales } from '../recursive-inquiry/model.js';

export const CandidateSharedInvariants = Object.freeze([
  'SITUATED_INPUT',
  'LOSS_AWARE_COMPRESSION',
  'BOUNDED_AUTHORIZATION',
  'PRESERVED_RESIDUE',
  'RETURN_DETECTABILITY',
  'SELECTIVE_DECOMPRESSION_RECOMPOSITION'
]);

export const decompositionLedger = [
  {
    scale: Scale.INDIVIDUAL,
    decomposesInto: ['situated attention','evidence differentiation','partial-map construction','bounded judgment','action','consequence-monitoring','map revision'],
    scaleSpecificRemainder: ['embodied access','first-person attention'],
  },
  {
    scale: Scale.COALITION,
    decomposesInto: ['member PRF inquiries','compatibility comparison','shared-task compression','conditional commitment','joint proposal','member Return','coalition recomposition'],
    scaleSpecificRemainder: ['membership relation','alternative-warrant convergence','joint commitment'],
  },
  {
    scale: Scale.INSTITUTIONAL,
    decomposesInto: ['coalition warrant comparison','proposal compression','procedural selection','bounded authorization','institutional action','consequence Return','authorization REOPEN'],
    scaleSpecificRemainder: ['standing allocation','plurality procedure','coercive authority'],
  },
  {
    scale: Scale.RETURN_NETWORK,
    decomposesInto: ['source inquiry','claim encoding','channel selection','message transmission','receiver interpretation','warrant update','escalation/reconstruction','termination assessment'],
    scaleSpecificRemainder: ['channel topology','latency/fidelity','receiver obligation','termination authority'],
  },
  {
    scale: Scale.CONSTITUTIONAL,
    decomposesInto: ['cross-case inquiry','failure aggregation','rule compression','meta-authorization','institutional redesign','systemic Return','meta-REOPEN'],
    scaleSpecificRemainder: ['meta-warrant','counter-authority','constitutional amendment/reallocation'],
  }
];

export const failureFamilies = Object.freeze({
  REPRESENTATION_SUBSTITUTION: [Scale.INDIVIDUAL,Scale.COALITION,Scale.INSTITUTIONAL,Scale.RETURN_NETWORK,Scale.CONSTITUTIONAL],
  RESIDUE_LOSS: [Scale.INDIVIDUAL,Scale.COALITION,Scale.INSTITUTIONAL,Scale.RETURN_NETWORK,Scale.CONSTITUTIONAL],
  PREMATURE_CLOSURE: [Scale.INDIVIDUAL,Scale.COALITION,Scale.INSTITUTIONAL,Scale.RETURN_NETWORK,Scale.CONSTITUTIONAL],
  STANDING_FAILURE: [Scale.COALITION,Scale.INSTITUTIONAL,Scale.RETURN_NETWORK,Scale.CONSTITUTIONAL],
  CHANNEL_FAILURE: [Scale.COALITION,Scale.INSTITUTIONAL,Scale.RETURN_NETWORK,Scale.CONSTITUTIONAL],
  CAPTURE: [Scale.INSTITUTIONAL,Scale.RETURN_NETWORK,Scale.CONSTITUTIONAL],
  STALE_REOPENING: [Scale.COALITION,Scale.INSTITUTIONAL,Scale.RETURN_NETWORK,Scale.CONSTITUTIONAL],
  EMBODIED_ACCESS_FAILURE: [Scale.INDIVIDUAL],
  MEMBERSHIP_FRAGMENTATION: [Scale.COALITION],
  COERCIVE_AUTHORITY_MISALLOCATION: [Scale.INSTITUTIONAL],
  ROUTING_LATENCY_FAILURE: [Scale.RETURN_NETWORK],
  META_AUTHORITY_LOCK_IN: [Scale.CONSTITUTIONAL]
});

export function strictDecompositionWithoutRemainder(){
  return decompositionLedger.every(x => x.scaleSpecificRemainder.length === 0);
}
export function decompositionWithExplicitRemainder(){
  return decompositionLedger.every(x => x.decomposesInto.length > 0 && x.scaleSpecificRemainder.length > 0);
}

export function strictFailureIsomorphism(){
  const n=scales.length;
  return Object.values(failureFamilies).every(xs => xs.length===n);
}
export function recurrentFailureCore(){
  return Object.entries(failureFamilies)
    .filter(([,xs])=>xs.length===scales.length)
    .map(([k])=>k);
}

export function invariantProfile(scale){
  const s=scales.find(x=>x.scale===scale);
  if(!s) throw new Error(`unknown scale ${scale}`);
  return {
    SITUATED_INPUT: !!s.input,
    LOSS_AWARE_COMPRESSION: !!s.compression && s.lost.length>0,
    BOUNDED_AUTHORIZATION: !!s.authorization,
    PRESERVED_RESIDUE: s.residue.length>0,
    RETURN_DETECTABILITY: !!s.returnSignal,
    SELECTIVE_DECOMPRESSION_RECOMPOSITION: !!s.decompression && !!s.recomposition,
  };
}

export function allSharedInvariantsHold(){
  return scales.every(s=>Object.values(invariantProfile(s.scale)).every(Boolean));
}

export function ablateInvariant(name){
  if(!CandidateSharedInvariants.includes(name)) throw new Error(`unknown invariant ${name}`);
  const profile=Object.fromEntries(CandidateSharedInvariants.map(k=>[k,true]));
  profile[name]=false;
  return assessCorrigibility(profile);
}

export function assessCorrigibility(profile){
  const required=CandidateSharedInvariants;
  const missing=required.filter(k=>!profile[k]);
  return {
    admissible: missing.length===0,
    missing,
    failure:
      missing.includes('SITUATED_INPUT') ? 'UNSITUATED_GENERALIZATION' :
      missing.includes('LOSS_AWARE_COMPRESSION') ? 'MAP_SUBSTITUTION_RISK' :
      missing.includes('BOUNDED_AUTHORIZATION') ? 'UNLICENSED_ACTION' :
      missing.includes('PRESERVED_RESIDUE') ? 'IRRECOVERABLE_COMPRESSION' :
      missing.includes('RETURN_DETECTABILITY') ? 'NO_ERROR_SIGNAL' :
      missing.includes('SELECTIVE_DECOMPRESSION_RECOMPOSITION') ? 'NO_CORRECTION_PATH' : null
  };
}

export function sufficientDecompression(state){
  const triggerAddressed=state.triggerAddressed===true;
  const relevantRecovered=state.relevantDistinctionsRecovered===true || state.relevantDistinctionsIrrecoverable===true;
  const standingIncluded=state.affectedStandingIncluded===true;
  const reassessmentPossible=state.authorizationReassessmentPossible===true;
  const actionSensitiveOpen=Number(state.actionSensitiveOpen ?? 0);
  const residuePreserved=state.residualUncertaintyRecorded===true && state.futureReopenRoutePreserved===true;
  const irrecoverable=state.relevantDistinctionsIrrecoverable===true;
  if(irrecoverable && state.escalationAvailable!==true){
    return {stop:false, outcome:'META_REOPEN_REQUIRED', reason:'relevant distinctions irrecoverable and no escalation path'};
  }
  if(irrecoverable && state.escalationAvailable===true){
    return {stop:true, outcome:'ESCALATE_AND_RECOMPOSE', reason:'local decompression exhausted; meta-level route available'};
  }
  if(triggerAddressed && relevantRecovered && standingIncluded && reassessmentPossible && actionSensitiveOpen===0 && residuePreserved){
    return {stop:true, outcome:'SUFFICIENT_DECOMPRESSION', reason:'all currently action-sensitive distinctions recovered; residual uncertainty preserved'};
  }
  return {stop:false, outcome:'CONTINUE_DECOMPRESSION', reason:'one or more action-sensitive requirements remain open'};
}

export function informationBridge({inputStates,activeStates,residueStates,returnSignals,normative}){
  if([inputStates,activeStates,residueStates,returnSignals].some(x=>!Number.isFinite(x)||x<0)) throw new Error('information metrics must be nonnegative finite numbers');
  const compressionRatio=inputStates===0?1:activeStates/inputStates;
  const residueRatio=inputStates===0?1:residueStates/inputStates;
  const returnSensitivity=inputStates===0?0:returnSignals/inputStates;
  return {
    descriptive:{compressionRatio,residueRatio,returnSensitivity},
    normative:{
      standing:normative?.standing ?? null,
      authorization:normative?.authorization ?? null,
      legitimacy:normative?.legitimacy ?? null,
      source:'EXTERNAL_NORMATIVE_GOVERNANCE'
    }
  };
}

export function informationMetricsAuthorize(){return false;}
export function informationMetricsAssignStanding(){return false;}
