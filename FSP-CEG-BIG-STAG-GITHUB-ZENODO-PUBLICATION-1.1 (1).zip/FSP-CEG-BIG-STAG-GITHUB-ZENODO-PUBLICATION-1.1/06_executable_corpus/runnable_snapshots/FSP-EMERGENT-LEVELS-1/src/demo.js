import { createInitialState } from './model.js';
import { run } from './reducer.js';
import { invariantResults } from './invariants.js';
import { runBranch, compareBranches } from './branch.js';
import { cooperativeDisclosureScenario, concealedNearMissScenario } from './scenarios.js';

const base = createInitialState();
const disclose = runBranch(base, { id: 'disclose', parentId: 'root', changedVariables: ['near_miss_disclosure=true'], unchangedAssumptions: ['agent_roster_v1', 'public_eval_v1'], rationale: 'cooperative disclosure + bounded restoration', events: cooperativeDisclosureScenario });
const conceal = runBranch(base, { id: 'conceal', parentId: 'root', changedVariables: ['near_miss_disclosure=false'], unchangedAssumptions: ['agent_roster_v1', 'public_eval_v1'], rationale: 'concealed near miss + lower inquiry openness', events: concealedNearMissScenario });

for (const s of [disclose, conceal]) {
  console.log(`\n=== ${s.branch.id} ===`);
  console.log(JSON.stringify({
    tick: s.tick,
    sharedTask: s.sharedTask,
    secondOrderWarrant: s.governance.secondOrderWarrant,
    metrics: s.metrics,
    returnSignals: s.returnSignals,
    branch: s.branch,
    invariants: invariantResults(s)
  }, null, 2));
}
console.log('\n=== branch comparison ===');
console.log(JSON.stringify(compareBranches(disclose, conceal), null, 2));
