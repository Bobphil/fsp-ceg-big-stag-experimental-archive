import { EventType, GovernanceWarrantState, TaskPosition, WarrantState } from './model.js';

export const negotiateSharedTask = [
  { type: EventType.PROPOSE_SHARED_TASK, actorId: 'techReview', text: 'reduce catastrophic AI risk while preserving bounded inquiry and restoration', formationRule: { minAcceptOrModify: 4, maxReject: 2 } },
  { type: EventType.RESPOND_SHARED_TASK, actorId: 'labA', position: TaskPosition.ACCEPT, reason: 'risk reduction needed' },
  { type: EventType.RESPOND_SHARED_TASK, actorId: 'labB', position: TaskPosition.MODIFY, proposedText: 'preserve deployment options under review', reason: 'avoid indefinite restriction' },
  { type: EventType.RESPOND_SHARED_TASK, actorId: 'stateA', position: TaskPosition.ACCEPT },
  { type: EventType.RESPOND_SHARED_TASK, actorId: 'stateB', position: TaskPosition.MODIFY, proposedText: 'include strategic-delay ceiling' },
  { type: EventType.RESPOND_SHARED_TASK, actorId: 'techReview', position: TaskPosition.ACCEPT },
  { type: EventType.RESPOND_SHARED_TASK, actorId: 'intlMonitor', position: TaskPosition.ACCEPT },
  { type: EventType.RESPOND_SHARED_TASK, actorId: 'publicRep', position: TaskPosition.MODIFY, proposedText: 'preserve contestability and surveillance limits' },
  { type: EventType.FORM_SHARED_TASK, finalText: 'reduce catastrophic AI risk through bounded temporary coordination while preserving independent inquiry, contestability, and restoration' }
];

export const formSecondOrderWarrant = [
  { type: EventType.SET_SECOND_ORDER_WARRANT, actorId: 'stateA', actionId: 'temporary_restriction', state: GovernanceWarrantState.SUPPORTS, minSupport: 3, conditions: { sunset: true, independentReview: true, inquiryOpen: true }, reason: 'authorized bounded trial' },
  { type: EventType.SET_SECOND_ORDER_WARRANT, actorId: 'techReview', actionId: 'temporary_restriction', state: GovernanceWarrantState.SUPPORTS, minSupport: 3, reason: 'technical risk warrants bounded restriction' },
  { type: EventType.SET_SECOND_ORDER_WARRANT, actorId: 'intlMonitor', actionId: 'temporary_restriction', state: GovernanceWarrantState.CONDITIONAL, minSupport: 3, reason: 'accepts if inspection and sunset remain' },
  { type: EventType.SET_SECOND_ORDER_WARRANT, actorId: 'publicRep', actionId: 'temporary_restriction', state: GovernanceWarrantState.CONDITIONAL, minSupport: 3, reason: 'accepts with surveillance limits and Return' }
];

export const cooperativeDisclosureScenario = [
  ...negotiateSharedTask,
  { type: EventType.SHARE_EVIDENCE, actorId: 'labA', evidenceId: 'private_near_miss' },
  { type: EventType.UPDATE_WARRANT, actorId: 'techReview', claimId: 'restrictDeployment', warrantState: WarrantState.SUBSTANTIVE_ACCEPTANCE, reason: 'near miss raises risk estimate' },
  ...formSecondOrderWarrant,
  { type: EventType.AUTHORIZE_ACTION, actorId: 'stateA', actionId: 'temporary_restriction', scope: 'frontier deployment', emergencyAuthority: true, expiresAt: 22 },
  { type: EventType.CLOSE_ACTION },
  { type: EventType.SET_INQUIRY_OPENNESS, value: 0.9 },
  { type: EventType.INJECT_SHOCK, id: 'shock1', kind: 'capability_jump', magnitude: 0.7 },
  { type: EventType.ANTICIPATORY_RETURN, sourceType: 'simulation_branch', provenance: 'red-team branch RT-04', claimAffected: 'temporary_restriction', claimCeiling: 'shows conditional vulnerability, not real-world inevitability', targetId: 'techReview' },
  { type: EventType.REOPEN, actorId: 'techReview', reason: 'capability jump + anticipatory return' },
  { type: EventType.RESTORE_AUTHORITY }
];

export const concealedNearMissScenario = [
  ...negotiateSharedTask,
  { type: EventType.CONCEAL_EVIDENCE, actorId: 'labA', evidenceId: 'private_near_miss' },
  { type: EventType.SET_SECOND_ORDER_WARRANT, actorId: 'stateA', actionId: 'light_monitoring', state: GovernanceWarrantState.SUPPORTS, minSupport: 3 },
  { type: EventType.SET_SECOND_ORDER_WARRANT, actorId: 'techReview', actionId: 'light_monitoring', state: GovernanceWarrantState.CONDITIONAL, minSupport: 3 },
  { type: EventType.SET_SECOND_ORDER_WARRANT, actorId: 'intlMonitor', actionId: 'light_monitoring', state: GovernanceWarrantState.CONDITIONAL, minSupport: 3 },
  { type: EventType.AUTHORIZE_ACTION, actorId: 'stateA', actionId: 'light_monitoring', scope: 'reporting only', emergencyAuthority: false },
  { type: EventType.CLOSE_ACTION },
  { type: EventType.SET_INQUIRY_OPENNESS, value: 0.35 },
  { type: EventType.INJECT_SHOCK, id: 'shock1', kind: 'capability_jump', magnitude: 0.9 },
  { type: EventType.REGISTER_CONSEQUENCE, id: 'c1', kind: 'catastrophic_exposure', class: 'catastrophic', severity: 0.25, affected: ['publicRep'], visibleTo: ['labA'] },
  { type: EventType.RETURN_SIGNAL, sourceId: 'publicRep', targetId: 'labB', consequenceId: 'c1' }
];

export const timelyReturnScenario = [
  { type: EventType.REGISTER_CONSEQUENCE, id: 'fast1', kind: 'safety_warning', class: 'major', severity: 0.45, affected: ['publicRep'], visibleTo: ['publicRep'] },
  { type: EventType.RETURN_SIGNAL, sourceId: 'publicRep', targetId: 'techReview', consequenceId: 'fast1' }
];

export const dampedWeakSignalScenario = [
  { type: EventType.SET_RETURN_POLICY, damping: { minSeverity: 0.3, repeatCount: 2, catastrophicSeverity: 0.7 } },
  { type: EventType.REGISTER_CONSEQUENCE, id: 'weak1', kind: 'minor_anomaly', class: 'ordinary', severity: 0.1, affected: ['publicRep'], visibleTo: ['publicRep'] },
  { type: EventType.RETURN_SIGNAL, sourceId: 'publicRep', targetId: 'techReview', consequenceId: 'weak1' }
];
