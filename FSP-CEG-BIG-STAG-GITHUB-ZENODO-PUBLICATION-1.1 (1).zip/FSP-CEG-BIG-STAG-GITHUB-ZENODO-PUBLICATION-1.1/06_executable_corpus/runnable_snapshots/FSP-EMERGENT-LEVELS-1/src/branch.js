import { run } from './reducer.js';

export function runBranch(initialState, spec) {
  const seeded = structuredClone(initialState);
  seeded.branch = {
    id: spec.id,
    parentId: spec.parentId ?? seeded.branch?.id ?? null,
    changedVariables: structuredClone(spec.changedVariables ?? []),
    unchangedAssumptions: structuredClone(spec.unchangedAssumptions ?? seeded.branch?.unchangedAssumptions ?? []),
    provenance: [{ type: 'branch_definition', rationale: spec.rationale ?? null }]
  };
  const finalState = run(seeded, spec.events);
  finalState.branch.provenance.push({ type: 'completed', tick: finalState.tick });
  return finalState;
}

export function compareBranches(a, b) {
  const keys = [...new Set([...Object.keys(a.metrics), ...Object.keys(b.metrics)])].sort();
  const metricDelta = Object.fromEntries(keys.map(k => [k, {
    a: a.metrics[k] ?? null,
    b: b.metrics[k] ?? null,
    delta: typeof a.metrics[k] === 'number' && typeof b.metrics[k] === 'number' ? b.metrics[k] - a.metrics[k] : null
  }]));
  return {
    branchA: a.branch.id,
    branchB: b.branch.id,
    changedVariablesA: a.branch.changedVariables,
    changedVariablesB: b.branch.changedVariables,
    commonAssumptions: a.branch.unchangedAssumptions.filter(x => b.branch.unchangedAssumptions.includes(x)),
    metricDelta,
    warrantDifference: Object.fromEntries(Object.keys(a.agents).map(id => [id, {
      a: a.agents[id].governanceWarrants,
      b: b.agents[id].governanceWarrants
    }]))
  };
}
