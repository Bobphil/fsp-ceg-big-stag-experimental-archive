export const WarrantState = Object.freeze({
  SUBSTANTIVE_ACCEPTANCE: 'substantive_acceptance',
  CONDITIONAL_ACCEPTANCE: 'conditional_acceptance',
  PROCEDURAL_ACCEPTANCE: 'procedural_acceptance',
  PRAGMATIC_COOPERATION: 'pragmatic_cooperation',
  UNCERTAIN: 'uncertain',
  SUBSTANTIVE_REJECTION: 'substantive_rejection',
  LEGITIMACY_REJECTION: 'legitimacy_rejection',
  RELUCTANT_COMPLIANCE: 'reluctant_compliance',
  COERCED_COMPLIANCE: 'coerced_compliance'
});

export const GovernanceWarrantState = Object.freeze({
  SUPPORTS: 'supports',
  CONDITIONAL: 'conditional',
  WITHHOLDS: 'withholds',
  REJECTS: 'rejects'
});

export const TaskPosition = Object.freeze({
  ACCEPT: 'accept',
  MODIFY: 'modify',
  REJECT: 'reject'
});

export const Role = Object.freeze({
  DEVELOPER: 'developer',
  STATE: 'state',
  TECHNICAL_REVIEW: 'technical_review',
  INTERNATIONAL_MONITOR: 'international_monitor',
  PUBLIC_REP: 'affected_public_representative'
});

export const GovernanceFunction = Object.freeze({
  DETECT: 'detect',
  CHARACTERIZE: 'characterize',
  AUTHORIZE: 'authorize',
  EXECUTE: 'execute',
  OBSERVE: 'observe',
  RETURN: 'return',
  REVIEW: 'review',
  RESTORE: 'restore'
});

export const EventType = Object.freeze({
  SHARE_EVIDENCE: 'share_evidence',
  CONCEAL_EVIDENCE: 'conceal_evidence',
  UPDATE_WARRANT: 'update_warrant',
  PROPOSE_SHARED_TASK: 'propose_shared_task',
  RESPOND_SHARED_TASK: 'respond_shared_task',
  FORM_SHARED_TASK: 'form_shared_task',
  SET_SECOND_ORDER_WARRANT: 'set_second_order_warrant',
  AUTHORIZE_ACTION: 'authorize_action',
  CLOSE_ACTION: 'close_action',
  SET_INQUIRY_OPENNESS: 'set_inquiry_openness',
  ASSIGN_GOVERNANCE_FUNCTION: 'assign_governance_function',
  SET_FUNCTIONAL_INDEPENDENCE: 'set_functional_independence',
  SET_RETURN_POLICY: 'set_return_policy',
  REGISTER_CONSEQUENCE: 'register_consequence',
  RETURN_SIGNAL: 'return_signal',
  ANTICIPATORY_RETURN: 'anticipatory_return',
  REOPEN: 'reopen',
  RESTORE_AUTHORITY: 'restore_authority',
  RENEW_AUTHORITY: 'renew_authority',
  INJECT_SHOCK: 'inject_shock'
});

export function createAgent({
  id,
  role,
  map = {},
  evidence = [],
  warrants = {},
  governanceWarrants = {},
  standing = [],
  capabilities = [],
  incentives = {},
  trust = {},
  revisionThresholds = {}
}) {
  return {
    id,
    role,
    map: structuredClone(map),
    evidence: [...evidence],
    warrants: structuredClone(warrants),
    governanceWarrants: structuredClone(governanceWarrants),
    standing: [...standing],
    capabilities: [...capabilities],
    incentives: structuredClone(incentives),
    trust: structuredClone(trust),
    revisionThresholds: structuredClone(revisionThresholds),
    memory: []
  };
}

export function createInitialState() {
  const agents = [
    createAgent({
      id: 'labA', role: Role.DEVELOPER,
      map: { catastrophicRisk: 0.35, capabilityThresholdReached: false },
      evidence: ['public_eval_v1', 'private_near_miss'],
      warrants: { restrictDeployment: WarrantState.CONDITIONAL_ACCEPTANCE },
      governanceWarrants: { temporary_restriction: GovernanceWarrantState.CONDITIONAL },
      standing: ['recommend', 'implement', 'report'],
      capabilities: ['develop', 'deploy', 'disclose']
    }),
    createAgent({
      id: 'labB', role: Role.DEVELOPER,
      map: { catastrophicRisk: 0.12, capabilityThresholdReached: false },
      evidence: ['public_eval_v1'],
      warrants: { restrictDeployment: WarrantState.SUBSTANTIVE_REJECTION },
      governanceWarrants: { temporary_restriction: GovernanceWarrantState.WITHHOLDS },
      standing: ['recommend', 'implement', 'report'],
      capabilities: ['develop', 'deploy', 'disclose']
    }),
    createAgent({
      id: 'stateA', role: Role.STATE,
      map: { strategicDelayCost: 0.7, catastrophicRisk: 0.25 },
      evidence: ['public_eval_v1'],
      warrants: { restrictDeployment: WarrantState.PROCEDURAL_ACCEPTANCE },
      governanceWarrants: { temporary_restriction: GovernanceWarrantState.SUPPORTS },
      standing: ['authorize', 'enforce', 'review'],
      capabilities: ['regulate', 'inspect', 'sanction']
    }),
    createAgent({
      id: 'stateB', role: Role.STATE,
      map: { strategicDelayCost: 0.9, catastrophicRisk: 0.10 },
      evidence: ['public_eval_v1'],
      warrants: { restrictDeployment: WarrantState.SUBSTANTIVE_REJECTION },
      governanceWarrants: { temporary_restriction: GovernanceWarrantState.CONDITIONAL },
      standing: ['authorize', 'enforce'],
      capabilities: ['regulate', 'inspect']
    }),
    createAgent({
      id: 'techReview', role: Role.TECHNICAL_REVIEW,
      map: { catastrophicRisk: 0.28 },
      evidence: ['public_eval_v1'],
      warrants: { restrictDeployment: WarrantState.CONDITIONAL_ACCEPTANCE },
      governanceWarrants: { temporary_restriction: GovernanceWarrantState.SUPPORTS },
      standing: ['inspect', 'recommend', 'trigger_reopen'],
      capabilities: ['audit', 'publish']
    }),
    createAgent({
      id: 'intlMonitor', role: Role.INTERNATIONAL_MONITOR,
      map: { treatyFragility: 0.4 },
      evidence: ['public_eval_v1'],
      warrants: { restrictDeployment: WarrantState.PROCEDURAL_ACCEPTANCE },
      governanceWarrants: { temporary_restriction: GovernanceWarrantState.CONDITIONAL },
      standing: ['inspect', 'trigger_reopen'],
      capabilities: ['verify', 'publish']
    }),
    createAgent({
      id: 'publicRep', role: Role.PUBLIC_REP,
      map: { concernAboutSurveillance: 0.8, catastrophicRisk: 0.30 },
      evidence: ['public_eval_v1'],
      warrants: { restrictDeployment: WarrantState.PRAGMATIC_COOPERATION },
      governanceWarrants: { temporary_restriction: GovernanceWarrantState.CONDITIONAL },
      standing: ['contest', 'report_harm', 'trigger_reopen'],
      capabilities: ['petition', 'publish']
    })
  ];

  return {
    tick: 0,
    agents: Object.fromEntries(agents.map(a => [a.id, a])),
    sharedTask: {
      status: 'candidate',
      text: 'reduce catastrophic AI risk without eliminating corrigibility',
      proposedBy: 'techReview',
      responses: {},
      formationRule: { minAcceptOrModify: 4, maxReject: 2 },
      formedAt: null,
      history: []
    },
    governance: {
      authorizedAction: null,
      actionClosed: false,
      inquiryOpenness: 1,
      emergencyAuthority: false,
      sunsetTick: null,
      restorationRequired: false,
      reviewIndependent: true,
      crossTriggerReopen: true,
      secondOrderWarrant: null,
      functions: {
        [GovernanceFunction.DETECT]: ['labA', 'labB', 'techReview'],
        [GovernanceFunction.CHARACTERIZE]: ['techReview'],
        [GovernanceFunction.AUTHORIZE]: ['stateA'],
        [GovernanceFunction.EXECUTE]: ['stateA'],
        [GovernanceFunction.OBSERVE]: ['techReview', 'intlMonitor'],
        [GovernanceFunction.RETURN]: ['publicRep', 'intlMonitor'],
        [GovernanceFunction.REVIEW]: ['techReview', 'stateA'],
        [GovernanceFunction.RESTORE]: ['stateA', 'intlMonitor']
      },
      independence: {
        'stateA->techReview': 0.8,
        'stateA->intlMonitor': 0.9,
        'stateA->publicRep': 0.9
      }
    },
    returnPolicy: {
      maxLatency: { catastrophic: 2, major: 4, ordinary: 8 },
      damping: { minSeverity: 0.25, repeatCount: 2, catastrophicSeverity: 0.7 },
      pendingSignals: []
    },
    information: {
      publicEvidence: ['public_eval_v1'],
      concealedEvidence: [],
      provenance: []
    },
    consequences: [],
    returnSignals: [],
    anticipatoryReturns: [],
    reopenEvents: [],
    shocks: [],
    branch: {
      id: 'root',
      parentId: null,
      changedVariables: [],
      unchangedAssumptions: ['agent_roster_v1', 'public_eval_v1'],
      provenance: []
    },
    metrics: {
      coordinationDelay: 0,
      catastrophicExposure: 0.2,
      falsePositiveClosure: 0,
      standingPreservation: 1,
      informationPreservation: 1,
      corrigibilityCost: 0.1,
      restorationSuccess: null,
      darkCoherenceRisk: 0,
      fragmentationRisk: 0.2,
      secondOrderWarrantStrength: 0,
      sharedTaskSupport: 0,
      functionalIndependence: 0.8,
      returnLatencyFailures: 0,
      dampedReturnCount: 0
    },
    audit: []
  };
}
