function independentCheckerExists(state) {
  const authorizers = state.governance.functions.authorize ?? [];
  const checkers = [...new Set([...(state.governance.functions.observe ?? []), ...(state.governance.functions.review ?? []), ...(state.governance.functions.restore ?? [])])];
  return authorizers.some(a => checkers.some(c => c !== a && (state.governance.independence[`${a}->${c}`] ?? 0.5) >= 0.5));
}

export function invariantResults(state) {
  const results = [];
  const risks = Object.values(state.agents).map(a => a.map.catastrophicRisk).filter(v => typeof v === 'number');
  results.push({ id: 'heterogeneous_maps', pass: new Set(risks.map(x => x.toFixed(4))).size > 1, detail: 'Agents retain distinct risk maps.' });

  const warrantStates = Object.values(state.agents).map(a => a.warrants.restrictDeployment).filter(Boolean);
  results.push({ id: 'warrant_plurality', pass: new Set(warrantStates).size > 1, detail: 'Population-level warrant states remain plural.' });

  results.push({ id: 'action_inquiry_separation', pass: !(state.governance.actionClosed && state.governance.inquiryOpenness === undefined), detail: 'Action closure and inquiry openness are distinct fields.' });

  const hasConsequences = state.consequences.length > 0;
  const hasReturn = state.returnSignals.length > 0;
  results.push({ id: 'return_not_automatic', pass: !hasConsequences || hasReturn, detail: 'Consequences require explicit Return routing.' });

  results.push({ id: 'anticipatory_return_provenance', pass: state.anticipatoryReturns.every(x => x.sourceType && x.provenance && x.claimCeiling), detail: 'Synthetic/historical warning signals retain provenance and claim ceilings.' });

  const reopened = state.reopenEvents.length > 0;
  results.push({ id: 'reopen_not_reversal', pass: !reopened || state.governance.authorizedAction !== undefined, detail: 'REOPEN changes review state without automatically determining policy outcome.' });

  if (state.metrics.restorationSuccess === true) {
    results.push({ id: 'functional_restoration', pass: !state.governance.emergencyAuthority && state.governance.authorizedAction === null, detail: 'Restoration removes exceptional authority, not merely its label.' });
  }

  results.push({ id: 'dark_coherence_detectable', pass: state.governance.inquiryOpenness === 1 && state.information.concealedEvidence.length === 0 ? state.metrics.darkCoherenceRisk <= 0.05 : state.metrics.darkCoherenceRisk > 0, detail: 'Blocked counter-signals are reflected in Dark-Coherence risk.' });

  results.push({ id: 'shared_task_not_assumed', pass: state.sharedTask.status !== 'formed' || Object.keys(state.sharedTask.responses).length >= state.sharedTask.formationRule.minAcceptOrModify, detail: 'Shared task formation requires recorded agent responses.' });

  const auth = state.governance.authorizedAction;
  results.push({ id: 'second_order_warrant_before_action', pass: !auth || state.governance.secondOrderWarrant?.formed === true, detail: 'Consequential action requires a formed second-order governance warrant.' });

  results.push({ id: 'functional_independence', pass: !state.governance.emergencyAuthority || independentCheckerExists(state), detail: 'Emergency authority retains at least one sufficiently independent observation/review/restoration path.' });

  results.push({ id: 'return_latency_governed', pass: state.returnSignals.every(x => typeof x.latency === 'number' && typeof x.maxLatency === 'number'), detail: 'Every Return signal records actual and allowed latency.' });

  results.push({ id: 'return_damping_explicit', pass: state.returnSignals.every(x => typeof x.damped === 'boolean'), detail: 'Return filtering is explicit rather than silently discarding weak signals.' });

  results.push({ id: 'branch_provenance_present', pass: Boolean(state.branch?.id) && Array.isArray(state.branch.provenance), detail: 'Every state retains branch identity and provenance.' });

  return results;
}

export function assertInvariants(state) {
  const failed = invariantResults(state).filter(x => !x.pass);
  if (failed.length) throw new Error(`Invariant failure(s):\n${failed.map(x => `${x.id}: ${x.detail}`).join('\n')}`);
}
