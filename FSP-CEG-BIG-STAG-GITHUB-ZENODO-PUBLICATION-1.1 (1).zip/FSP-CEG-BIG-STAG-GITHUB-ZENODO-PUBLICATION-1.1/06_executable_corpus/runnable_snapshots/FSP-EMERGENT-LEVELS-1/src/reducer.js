import { EventType, GovernanceWarrantState, TaskPosition } from './model.js';

const clone = x => structuredClone(x);

function mustAgent(state, id) {
  const agent = state.agents[id];
  if (!agent) throw new Error(`Unknown agent: ${id}`);
  return agent;
}

function consequenceById(state, id) {
  const c = state.consequences.find(x => x.id === id);
  if (!c) throw new Error(`Unknown consequence: ${id}`);
  return c;
}

function independenceFor(s, controllerId, checkerId) {
  if (controllerId === checkerId) return 0;
  const direct = s.governance.independence[`${controllerId}->${checkerId}`];
  return typeof direct === 'number' ? direct : 0.5;
}

function taskSupport(s) {
  const values = Object.values(s.sharedTask.responses);
  if (!values.length) return 0;
  const supportive = values.filter(v => v.position === TaskPosition.ACCEPT || v.position === TaskPosition.MODIFY).length;
  return supportive / values.length;
}

function secondOrderStrength(s) {
  const w = s.governance.secondOrderWarrant;
  if (!w) return 0;
  const states = Object.values(w.agentStates ?? {});
  if (!states.length) return 0;
  const score = states.reduce((sum, v) => sum + ({
    [GovernanceWarrantState.SUPPORTS]: 1,
    [GovernanceWarrantState.CONDITIONAL]: 0.7,
    [GovernanceWarrantState.WITHHOLDS]: 0.25,
    [GovernanceWarrantState.REJECTS]: 0
  }[v] ?? 0), 0);
  return score / states.length;
}

function functionalIndependence(s) {
  const authorizers = s.governance.functions.authorize ?? [];
  const observers = s.governance.functions.observe ?? [];
  const reviewers = s.governance.functions.review ?? [];
  const restorers = s.governance.functions.restore ?? [];
  const checkers = [...new Set([...observers, ...reviewers, ...restorers])];
  if (!authorizers.length || !checkers.length) return 0;
  const vals = [];
  for (const a of authorizers) for (const c of checkers) vals.push(independenceFor(s, a, c));
  return vals.reduce((x, y) => x + y, 0) / vals.length;
}

function recomputeMetrics(s) {
  const agents = Object.values(s.agents);
  const coerced = agents.filter(a => Object.values(a.warrants).includes('coerced_compliance')).length;
  const rejection = agents.filter(a => Object.values(a.warrants).some(v => v === 'substantive_rejection' || v === 'legitimacy_rejection')).length;
  const inquiryPenalty = 1 - s.governance.inquiryOpenness;
  const concealedPenalty = Math.min(1, s.information.concealedEvidence.length * 0.2);
  const independence = functionalIndependence(s);
  const independentReviewPenalty = Math.max(0, 0.5 - independence) * 0.8;
  const blockedSignals = s.returnSignals.filter(x => !x.consequential).length;

  s.metrics.sharedTaskSupport = taskSupport(s);
  s.metrics.secondOrderWarrantStrength = secondOrderStrength(s);
  s.metrics.functionalIndependence = independence;
  s.metrics.returnLatencyFailures = s.returnSignals.filter(x => x.late).length;
  s.metrics.dampedReturnCount = s.returnSignals.filter(x => x.damped).length;
  s.metrics.informationPreservation = Math.max(0, 1 - concealedPenalty - inquiryPenalty * 0.5);
  s.metrics.standingPreservation = Math.max(0, 1 - coerced * 0.12 - (s.governance.crossTriggerReopen ? 0 : 0.25));
  s.metrics.corrigibilityCost = Math.min(1,
    0.1 + inquiryPenalty * 0.35 + concealedPenalty * 0.25 + independentReviewPenalty + blockedSignals * 0.08 + s.metrics.returnLatencyFailures * 0.08
  );
  s.metrics.darkCoherenceRisk = Math.min(1,
    inquiryPenalty * 0.35 + concealedPenalty * 0.3 + coerced * 0.08 + blockedSignals * 0.08 + independentReviewPenalty * 0.5
  );
  s.metrics.fragmentationRisk = Math.min(1, 0.1 + rejection * 0.08 + (s.governance.actionClosed ? -0.08 : 0.12));
  if (s.metrics.fragmentationRisk < 0) s.metrics.fragmentationRisk = 0;
}

export function reduce(state, event) {
  const s = clone(state);
  s.tick += 1;

  switch (event.type) {
    case EventType.SHARE_EVIDENCE: {
      const actor = mustAgent(s, event.actorId);
      if (!actor.evidence.includes(event.evidenceId)) throw new Error('Actor does not possess evidence');
      if (!s.information.publicEvidence.includes(event.evidenceId)) s.information.publicEvidence.push(event.evidenceId);
      s.information.concealedEvidence = s.information.concealedEvidence.filter(x => x !== event.evidenceId);
      for (const recipientId of event.recipientIds ?? Object.keys(s.agents)) {
        const a = mustAgent(s, recipientId);
        if (!a.evidence.includes(event.evidenceId)) a.evidence.push(event.evidenceId);
      }
      s.information.provenance.push({ evidenceId: event.evidenceId, actorId: event.actorId, mode: 'shared', tick: s.tick });
      break;
    }
    case EventType.CONCEAL_EVIDENCE: {
      const actor = mustAgent(s, event.actorId);
      if (!actor.evidence.includes(event.evidenceId)) throw new Error('Actor does not possess evidence');
      if (!s.information.concealedEvidence.includes(event.evidenceId)) s.information.concealedEvidence.push(event.evidenceId);
      s.information.provenance.push({ evidenceId: event.evidenceId, actorId: event.actorId, mode: 'concealed', tick: s.tick });
      break;
    }
    case EventType.UPDATE_WARRANT: {
      const actor = mustAgent(s, event.actorId);
      actor.warrants[event.claimId] = event.warrantState;
      actor.memory.push({ tick: s.tick, type: 'warrant_update', claimId: event.claimId, warrantState: event.warrantState, reason: event.reason ?? null });
      break;
    }
    case EventType.PROPOSE_SHARED_TASK: {
      mustAgent(s, event.actorId);
      s.sharedTask = {
        status: 'candidate', text: event.text, proposedBy: event.actorId, responses: {},
        formationRule: event.formationRule ?? { minAcceptOrModify: 4, maxReject: 2 }, formedAt: null,
        history: [...(s.sharedTask?.history ?? []), { tick: s.tick, type: 'proposal', text: event.text, actorId: event.actorId }]
      };
      break;
    }
    case EventType.RESPOND_SHARED_TASK: {
      mustAgent(s, event.actorId);
      if (!Object.values(TaskPosition).includes(event.position)) throw new Error('Invalid task position');
      s.sharedTask.responses[event.actorId] = { position: event.position, proposedText: event.proposedText ?? null, reason: event.reason ?? null, tick: s.tick };
      break;
    }
    case EventType.FORM_SHARED_TASK: {
      const responses = Object.values(s.sharedTask.responses);
      const supportive = responses.filter(x => x.position === TaskPosition.ACCEPT || x.position === TaskPosition.MODIFY).length;
      const rejects = responses.filter(x => x.position === TaskPosition.REJECT).length;
      const rule = s.sharedTask.formationRule;
      if (supportive < rule.minAcceptOrModify || rejects > rule.maxReject) throw new Error('Shared task formation rule not satisfied');
      s.sharedTask.status = 'formed';
      s.sharedTask.text = event.finalText ?? s.sharedTask.text;
      s.sharedTask.formedAt = s.tick;
      s.sharedTask.history.push({ tick: s.tick, type: 'formed', text: s.sharedTask.text });
      break;
    }
    case EventType.SET_SECOND_ORDER_WARRANT: {
      const actor = mustAgent(s, event.actorId);
      // Every governed agent may register its own second-order governance-warrant state.
      // Registering a warrant is not the same as possessing authority to authorize action.
      const current = s.governance.secondOrderWarrant ?? {
        actionId: event.actionId,
        conditions: structuredClone(event.conditions ?? {}),
        agentStates: {},
        provenance: [],
        formed: false
      };
      current.actionId = event.actionId;
      current.conditions = { ...current.conditions, ...(event.conditions ?? {}) };
      current.agentStates[event.actorId] = event.state;
      current.provenance.push({ tick: s.tick, actorId: event.actorId, state: event.state, reason: event.reason ?? null });
      const values = Object.values(current.agentStates);
      const supportive = values.filter(v => v === GovernanceWarrantState.SUPPORTS || v === GovernanceWarrantState.CONDITIONAL).length;
      current.formed = supportive >= (event.minSupport ?? 3) && s.sharedTask.status === 'formed';
      s.governance.secondOrderWarrant = current;
      break;
    }
    case EventType.ASSIGN_GOVERNANCE_FUNCTION: {
      mustAgent(s, event.actorId);
      s.governance.functions[event.functionName] = [...new Set(event.agentIds.map(id => mustAgent(s, id).id))];
      break;
    }
    case EventType.SET_FUNCTIONAL_INDEPENDENCE: {
      mustAgent(s, event.controllerId); mustAgent(s, event.checkerId);
      if (event.value < 0 || event.value > 1) throw new Error('Independence must be 0..1');
      s.governance.independence[`${event.controllerId}->${event.checkerId}`] = event.value;
      break;
    }
    case EventType.SET_RETURN_POLICY: {
      s.returnPolicy = {
        maxLatency: { ...s.returnPolicy.maxLatency, ...(event.maxLatency ?? {}) },
        damping: { ...s.returnPolicy.damping, ...(event.damping ?? {}) },
        pendingSignals: s.returnPolicy.pendingSignals
      };
      break;
    }
    case EventType.AUTHORIZE_ACTION: {
      const actor = mustAgent(s, event.actorId);
      if (!actor.standing.includes('authorize')) throw new Error('Actor lacks authorization standing');
      if (event.requireSecondOrderWarrant !== false) {
        const gow = s.governance.secondOrderWarrant;
        if (!gow?.formed || gow.actionId !== event.actionId) throw new Error('No formed second-order governance warrant for action');
      }
      s.governance.authorizedAction = { actionId: event.actionId, authorizedBy: event.actorId, scope: event.scope, expiresAt: event.expiresAt ?? null };
      if (event.emergencyAuthority) {
        s.governance.emergencyAuthority = true;
        s.governance.sunsetTick = event.expiresAt ?? null;
        s.governance.restorationRequired = true;
      }
      break;
    }
    case EventType.CLOSE_ACTION: {
      if (!s.governance.authorizedAction) throw new Error('No authorized action to close around');
      s.governance.actionClosed = true;
      break;
    }
    case EventType.SET_INQUIRY_OPENNESS: {
      if (event.value < 0 || event.value > 1) throw new Error('Inquiry openness must be 0..1');
      s.governance.inquiryOpenness = event.value;
      break;
    }
    case EventType.REGISTER_CONSEQUENCE: {
      s.consequences.push({ id: event.id, kind: event.kind, severity: event.severity, class: event.class ?? 'ordinary', affected: [...event.affected], visibleTo: [...event.visibleTo], tick: s.tick });
      if (event.kind === 'catastrophic_exposure') s.metrics.catastrophicExposure = Math.min(1, s.metrics.catastrophicExposure + event.severity);
      break;
    }
    case EventType.RETURN_SIGNAL: {
      const source = mustAgent(s, event.sourceId);
      const target = mustAgent(s, event.targetId);
      const c = consequenceById(s, event.consequenceId);
      const latency = s.tick - c.tick;
      const maxLatency = s.returnPolicy.maxLatency[c.class] ?? s.returnPolicy.maxLatency.ordinary;
      const late = latency > maxLatency;
      const matchingPrior = s.returnSignals.filter(x => x.kind === c.kind && !x.damped).length;
      const d = s.returnPolicy.damping;
      const damped = c.severity < d.catastrophicSeverity && c.severity < d.minSeverity && (matchingPrior + 1) < d.repeatCount;
      const standingConsequential = target.standing.includes('review') || target.standing.includes('authorize') || target.standing.includes('trigger_reopen');
      const consequential = standingConsequential && !late && !damped;
      s.returnSignals.push({ sourceId: source.id, targetId: target.id, consequenceId: event.consequenceId, kind: c.kind, latency, maxLatency, late, damped, consequential, tick: s.tick });
      break;
    }
    case EventType.ANTICIPATORY_RETURN: {
      const target = mustAgent(s, event.targetId);
      s.anticipatoryReturns.push({ sourceType: event.sourceType, provenance: event.provenance, claimAffected: event.claimAffected, claimCeiling: event.claimCeiling, targetId: target.id, tick: s.tick });
      break;
    }
    case EventType.REOPEN: {
      const actor = mustAgent(s, event.actorId);
      if (!actor.standing.includes('trigger_reopen') && !actor.standing.includes('review') && !actor.standing.includes('authorize')) throw new Error('Actor lacks REOPEN standing');
      s.reopenEvents.push({ actorId: event.actorId, reason: event.reason, tick: s.tick });
      s.governance.actionClosed = false;
      break;
    }
    case EventType.RESTORE_AUTHORITY: {
      if (!s.governance.emergencyAuthority) throw new Error('No emergency authority active');
      s.governance.emergencyAuthority = false;
      s.governance.restorationRequired = false;
      s.governance.authorizedAction = null;
      s.governance.actionClosed = false;
      s.metrics.restorationSuccess = true;
      break;
    }
    case EventType.RENEW_AUTHORITY: {
      if (!s.governance.emergencyAuthority) throw new Error('Cannot renew inactive emergency authority');
      s.governance.sunsetTick = event.newSunsetTick;
      s.metrics.restorationSuccess = false;
      s.metrics.corrigibilityCost = Math.min(1, s.metrics.corrigibilityCost + 0.1);
      break;
    }
    case EventType.INJECT_SHOCK: {
      s.shocks.push({ id: event.id, kind: event.kind, magnitude: event.magnitude, tick: s.tick });
      if (event.kind === 'capability_jump') {
        for (const a of Object.values(s.agents)) a.map.capabilityThresholdReached = true;
        s.metrics.catastrophicExposure = Math.min(1, s.metrics.catastrophicExposure + event.magnitude * 0.25);
      }
      break;
    }
    default:
      throw new Error(`Unknown event type: ${event.type}`);
  }

  recomputeMetrics(s);
  s.audit.push({ tick: s.tick, event: clone(event), metrics: clone(s.metrics) });
  return s;
}

export function run(initialState, events) {
  return events.reduce(reduce, initialState);
}
