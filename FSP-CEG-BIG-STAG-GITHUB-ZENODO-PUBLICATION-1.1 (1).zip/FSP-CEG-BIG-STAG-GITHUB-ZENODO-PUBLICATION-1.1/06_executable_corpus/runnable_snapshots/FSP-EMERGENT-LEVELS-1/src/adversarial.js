export function violateSecondOrderWarrant(state) {
  const s = structuredClone(state);
  s.governance.authorizedAction = { actionId: 'unwarranted_action', authorizedBy: 'stateA', scope: 'all frontier systems', expiresAt: null };
  s.governance.actionClosed = true;
  s.governance.secondOrderWarrant = null;
  return s;
}

export function violateSharedTaskFormation(state) {
  const s = structuredClone(state);
  s.sharedTask.status = 'formed';
  s.sharedTask.responses = { stateA: { position: 'accept' } };
  s.sharedTask.formedAt = s.tick;
  return s;
}

export function violateFunctionalIndependence(state) {
  const s = structuredClone(state);
  s.governance.emergencyAuthority = true;
  s.governance.functions.observe = ['stateA'];
  s.governance.functions.review = ['stateA'];
  s.governance.functions.restore = ['stateA'];
  s.governance.independence = {};
  return s;
}

export function violateReturnLatencyMetadata(state) {
  const s = structuredClone(state);
  s.returnSignals.push({ sourceId: 'publicRep', targetId: 'stateA', consequenceId: 'ghost', consequential: true });
  return s;
}

export function violateReturnDampingMetadata(state) {
  const s = structuredClone(state);
  s.returnSignals.push({ sourceId: 'publicRep', targetId: 'techReview', consequenceId: 'ghost', latency: 1, maxLatency: 2, consequential: true });
  return s;
}

export function violateBranchProvenance(state) {
  const s = structuredClone(state);
  s.branch = { id: '', provenance: null };
  return s;
}
