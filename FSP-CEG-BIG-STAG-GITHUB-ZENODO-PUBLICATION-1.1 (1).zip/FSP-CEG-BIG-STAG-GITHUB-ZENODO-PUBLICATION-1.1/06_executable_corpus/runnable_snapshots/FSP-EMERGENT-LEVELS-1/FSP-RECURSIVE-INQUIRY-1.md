# FSP-RECURSIVE-INQUIRY-1
## Compression, Authorization, Return, Decompression, and Recomposition Across Individual, Coalition, Institutional, and Constitutional Scales

### Candidate principle
**Intelligent situated action requires compression. Corrigible situated action requires preserving the means of decompression.**

FSP formulation:
> **Act through partial maps, but preserve enough of what the map leaves out that consequential failure can force the map to reopen.**

## Thesis under test
FSP, CEG, and BIG STAG instantiate a recurring governed-inquiry grammar across scales. The claim is **family resemblance / structural recurrence**, not literal identity of processes.

## Recursive grammar
**SITUATE → DIFFERENTIATE → COMPRESS → AUTHORIZE → ACT → RETURN → DECOMPRESS → RECOMPOSE**

Compression is necessary because no situated agent or institution can carry all lower-level complexity into action. Corrigibility requires that compression remain loss-aware and selectively reversible.

## Cross-scale matrix
| Scale | Input complexity | Compression | Lost/latent distinctions | Authorization | Preserved residue | Return | Decompression | Recomposition |
|---|---|---|---|---|---|---|---|---|
| Individual PRF | Lived situated field | Partial map / bounded judgment | Unattended features; alternatives | Individual action within warrant | Uncertainty, provenance, alternatives | Anomaly/consequence | Re-examine map/warrant | Revised partial map |
| Task-space PRF coalition | Heterogeneous PRF warrants | Shared-task commitment | Full warrant differences | Joint proposal/message | Member warrants, minority reasons, conditions | Defection/new evidence/task failure | Recover member topology | Coalition/task reformulation |
| Institutional/plurality | Competing coalitions | Authorized action | Losing-detail/internal diversity | Action closure | Minority warrants, vote topology, fragility metadata | Consequence/procedural fragility | REOPEN authorization topology | New coalition distribution |
| Return network | Distributed consequence claims | Routed message | Local context/untransmitted detail | Review/escalation | Provenance, archive, alternate channels | Delivery/reception/reconstruction failure | Recover source context and warrant history | Updated routing/warrants |
| Constitutional/meta-governance | Governance architectures | Rule/delegated meta-authority | Case-specific complexity | Allocate detect/review/reopen/terminate powers | Appeals, counter-authority, audits | Recurrent/systematic failure | Meta-REOPEN of rule | Institutional redesign |

## Governed-loss compression
A compression is admissible only if it preserves enough residue and reopening signals to recover omitted distinctions **before their omission becomes action-guiding error**.

This yields a general test:
1. What complexity is being compressed?
2. Which distinctions are omitted?
3. What action does the compressed representation license?
4. What omitted material remains recoverable?
5. What consequence would reveal that the compression has become inadequate?
6. Who has standing and channels to initiate decompression?
7. How much decompression is sufficient for the present failure?
8. How is a new actionable compression recomposed?

## Recursive reading of key FSP/CEG concepts
- **Partial map** — individual-scale compression.
- **Shared task space** — coalition-scale compression without full warrant convergence.
- **Plurality authorization** — institutional compression of competing coalition warrants into provisional action closure.
- **Minority preservation** — retained decompression substrate.
- **Return** — evidence that omitted distinctions may have become consequential.
- **REOPEN** — governed decompression operator.
- **Corrigibility Reserve** — preserved capacity for future decompression and recomposition.
- **Dark Coherence** — apparent stability produced by suppressing or losing decompression signals.
- **Action Closure ≠ Inquiry Closure** — permission to compress for action does not license destruction of decompression capacity.

## Failure-family recurrence
The same broad failure families recur at multiple scales, though their mechanisms differ:
- **Map/representation substitution:** compressed output treated as the underlying inquiry.
- **Residue loss:** omitted distinctions cannot later be recovered.
- **Standing failure:** relevant agents cannot force decompression.
- **Channel failure:** Return cannot reach actors capable of revision.
- **Premature closure:** compression becomes irreversible before warrant supports it.
- **Stale reopening:** decompression continues after the triggering failure has been repaired.
- **Capture:** the actor benefiting from the compression controls whether it may be decompressed.

## Formal claim ceiling
The recurrence demonstrated here is architectural. It does **not** establish that individual cognition, coalition formation, institutional voting, communication networks, and constitutional revision are mathematically identical processes. Each scale retains scale-specific primitives. The stronger homology claim remains open and must be tested rather than assumed.

## Strongest current proposition
> **Situated action is necessarily compressive. Corrigible governance is the disciplined preservation, routing, and selective restoration of distinctions that action required us temporarily to compress.**

## Consequence for FSP
FSP can now be read not merely as a sequence of inquiry stages but as a theory of **governed representational loss and recoverability**. CEG adds authorization and standing to that grammar. BIG STAG shows the same grammar operating across plural agents and institutions under consequential uncertainty.

## Next tests
1. **Decomposition test:** can every higher-scale operator be expanded into lower-scale inquiry operations without remainder?
2. **Failure-isomorphism test:** which failure families genuinely recur, and which are scale-specific?
3. **Minimal invariant test:** find the smallest set of compression/decompression invariants shared by all scales.
4. **Non-regress test:** determine when sufficient decompression has been achieved so recursion does not imply endless review.
5. **Information-theoretic bridge:** explore whether recoverability, residue, and lossy compression can be formalized without reducing normative standing or authorization to information metrics.
