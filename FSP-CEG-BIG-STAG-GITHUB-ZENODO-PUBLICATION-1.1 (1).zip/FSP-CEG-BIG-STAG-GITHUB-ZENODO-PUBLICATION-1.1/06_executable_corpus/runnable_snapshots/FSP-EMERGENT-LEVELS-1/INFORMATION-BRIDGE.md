# Information-Theoretic Bridge

Permitted descriptive quantities include compression ratio, preserved-residue ratio, and Return-signal sensitivity. They may characterize representational loss, retained recoverability, and error-signaling capacity.

## Normative firewall
Information metrics do not determine:
- standing;
- authorization;
- legitimacy;
- truth.

Those are supplied by separate normative and institutional relations. The executable bridge therefore carries normative fields as external inputs and exposes no function by which information metrics assign standing or authorize action.

**Information loss can describe a governance problem without deciding who ought to count or who may act.**
