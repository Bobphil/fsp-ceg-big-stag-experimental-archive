import crypto from 'node:crypto';
import { memoryWorlds } from './fixtures.js';
import { MEMORY_MODES, hasField, ALL_BUNDLES, OBSERVE_THRESHOLD, COMPOSE_THRESHOLD, ACTIVATION_CONFIDENCE, trueCandidateStatus } from './model.js';

const policyFactor=p=>p==='POLICY_P3'?.72:p==='POLICY_P2'?.84:.95;
const key=c=>c.id;
const mkCandidate=(bundle,step)=>({id:'COMPOSED::'+bundle.join('+'),components:[...bundle],observed_quality:Math.min(...bundle.map(k=>step.observed_capacities[k]??0))});
const observed=(step,threshold=COMPOSE_THRESHOLD)=>ALL_BUNDLES.filter(b=>b.every(k=>(step.observed_capacities[k]??0)>=threshold)).map(b=>mkCandidate(b,step)).sort((a,b)=>b.observed_quality-a.observed_quality||a.id.localeCompare(b.id));

function createMemory(){return {incompatPairs:new Set(),riskyDeps:new Set(),lockSensitive:new Set(),failed:new Map(),degraded:new Set(),lastObserved:{},events:[]};}
function pairKey(a,b){return [a,b].sort().join('::');}
function repeatedDependency(candidate,step,memory){
  const counts={}; for(const c of candidate.components){const g=step.dependency_provenance?.[c]; if(g) counts[g]=(counts[g]??0)+1;}
  return Object.entries(counts).some(([g,n])=>n>=2 && memory.riskyDeps.has(g));
}
function candidateBlocked(c,step,memory,mode,locked){
  if(hasField(mode,'capacity_condition_history') && c.components.some(k=>locked.has(k)||memory.degraded.has(k))) return 'CONDITION_MEMORY';
  if(hasField(mode,'reversibility_history') && c.components.some(k=>memory.lockSensitive.has(k))) return 'REVERSIBILITY_MEMORY';
  if(hasField(mode,'compatibility_provenance')){
    for(let i=0;i<c.components.length;i++) for(let j=i+1;j<c.components.length;j++) if(memory.incompatPairs.has(pairKey(c.components[i],c.components[j]))) return 'COMPATIBILITY_MEMORY';
  }
  if(hasField(mode,'dependency_history') && repeatedDependency(c,step,memory)) return 'DEPENDENCY_MEMORY';
  if(hasField(mode,'candidate_failure_history')){
    const f=memory.failed.get(c.id); if(f && (step.observed_capacities[f.weakest]??0) < f.qualityAtFailure+.08) return 'FAILURE_MEMORY';
  }
  return null;
}
function choose(step,portfolio,memory,mode,locked){
  const ready=step.diagnostic_confidence>=ACTIVATION_CONFIDENCE || step.consequence_revealed;
  for(const c of observed(step,OBSERVE_THRESHOLD)) portfolio.set(key(c),c);
  if(!ready) return {selected:[],filtered:[]};
  const viable=[...portfolio.values()].filter(c=>c.components.every(k=>(step.observed_capacities[k]??0)>=OBSERVE_THRESHOLD)).map(c=>mkCandidate(c.components,step)).sort((a,b)=>b.observed_quality-a.observed_quality||a.id.localeCompare(b.id));
  const filtered=[]; for(const c of viable){const reason=candidateBlocked(c,step,memory,mode,locked); if(reason){filtered.push({id:c.id,reason}); continue;} return {selected:[c],filtered};}
  return {selected:[],filtered};
}
function updateConditionMemory(step,memory){
  for(const [k,v] of Object.entries(step.observed_capacities)){
    const prev=memory.lastObserved[k]; if(prev!=null && prev-v>=.12) memory.degraded.add(k);
    if(prev!=null && v-prev>=.12) memory.degraded.delete(k);
    memory.lastObserved[k]=v;
  }
}
function learnFromFailure(step,c,status,memory,mode){
  if(hasField(mode,'compatibility_provenance') && status.reason==='INCOMPATIBLE_COMPONENTS'){
    for(const [a,b] of step.incompatibilities??[]) if(c.components.includes(a)&&c.components.includes(b)) memory.incompatPairs.add(pairKey(a,b));
  }
  if(hasField(mode,'dependency_history') && ['FUNCTIONAL_MISMATCH','FALSE_COMPOSABILITY'].includes(status.reason)){
    const counts={}; for(const k of c.components){const g=step.dependency_provenance?.[k]; if(g) counts[g]=(counts[g]??0)+1;}
    for(const [g,n] of Object.entries(counts)) if(n>=2) memory.riskyDeps.add(g);
  }
  if(hasField(mode,'reversibility_history') && (step.lock_on_failed_attempt??[]).length) for(const k of step.lock_on_failed_attempt) memory.lockSensitive.add(k);
  if(hasField(mode,'candidate_failure_history')){
    const weakest=[...c.components].sort((a,b)=>(step.observed_capacities[a]??0)-(step.observed_capacities[b]??0))[0];
    memory.failed.set(c.id,{reason:status.reason,weakest,qualityAtFailure:step.observed_capacities[weakest]??0});
  }
}
export function runMemoryAblation(mode,worldName){
  if(!(mode in MEMORY_MODES)) throw new Error('Unknown memory mode '+mode);
  const fixture=memoryWorlds[worldName]; if(!fixture) throw new Error('Unknown world '+worldName);
  const portfolio=new Map(), memory=createMemory(), locked=new Map(); const episodes=[]; let pending=true,maintenance=0,compounding=0,successes=0;
  for(let i=0;i<fixture.length;i++){
    const step=fixture[i]; for(const [k,until] of [...locked]) if(i>=until) locked.delete(k);
    if(hasField(mode,'capacity_condition_history')) updateConditionMemory(step,memory);
    const {selected,filtered}=choose(step,portfolio,memory,mode,locked);
    const attempts=[];
    for(const c of selected){const status=trueCandidateStatus(step,c,new Set(locked.keys())); attempts.push({...c,...status}); if(status.success){pending=false;successes++;} else {learnFromFailure(step,c,status,memory,mode); for(const k of step.lock_on_failed_attempt??[]) locked.set(k,i+3);}}
    maintenance+=portfolio.size*.02;
    const policy=step.risk>=.75&&!pending?'POLICY_P3':'POLICY_P2'; const base=step.risk*policyFactor(policy); const deferred=pending?.065*step.risk:0; const failedCost=attempts.filter(a=>!a.success).length*.02; compounding+=deferred;
    episodes.push({time:step.time,label:step.label,mode,selected,filtered,attempts,portfolio_size:portfolio.size,memory:{incompat_pairs:[...memory.incompatPairs],risky_dependencies:[...memory.riskyDeps],lock_sensitive:[...memory.lockSensitive],failed_candidates:[...memory.failed.keys()],degraded:[...memory.degraded]},pending_failure:pending,policy,hazard:Number((base+deferred+failedCost).toFixed(4))});
  }
  const metrics={protection:{hazard_exposure:Number(episodes.reduce((a,e)=>a+e.hazard,0).toFixed(4)),deferred_failure_compounding:Number(compounding.toFixed(4)),final_pending_failure:pending,p3_transitions:episodes.filter(e=>e.policy==='POLICY_P3').length},composition:{successful_compositions:successes},overhead:{repair_attempts:episodes.reduce((a,e)=>a+e.attempts.length,0),failed_attempts:episodes.reduce((a,e)=>a+e.attempts.filter(x=>!x.success).length,0),filtered_candidates:episodes.reduce((a,e)=>a+e.filtered.length,0),candidate_maintenance_cost:Number(maintenance.toFixed(4))}};
  const out={experiment:'EXPERIMENT-1I',world:worldName,memory_mode:mode,episodes,metrics};
  out.invariants=[{id:'1I-01',pass:episodes.length===4},{id:'1I-02',pass:episodes.every(e=>e.selected.every(c=>c.id.startsWith('COMPOSED::')))},{id:'1I-03',pass:!('master_score' in metrics)},{id:'1I-04',pass:Object.keys(MEMORY_MODES).includes(mode)}];
  out.hash=crypto.createHash('sha256').update(JSON.stringify(out)).digest('hex'); return out;
}
export function runAllMemoryAblations(){const out=[]; for(const world of Object.keys(memoryWorlds)) for(const mode of Object.keys(MEMORY_MODES)) out.push(runMemoryAblation(mode,world)); return out;}
