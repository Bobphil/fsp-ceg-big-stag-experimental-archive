import { CAPACITIES, OBSERVE_THRESHOLD, COMPOSE_THRESHOLD, ACTIVATION_CONFIDENCE, BUNDLE_SIZE, ALL_BUNDLES, trueCandidateStatus } from '../experiment1h/model.js';
export { CAPACITIES, OBSERVE_THRESHOLD, COMPOSE_THRESHOLD, ACTIVATION_CONFIDENCE, BUNDLE_SIZE, ALL_BUNDLES, trueCandidateStatus };

export const MEMORY_FIELDS=['compatibility_provenance','dependency_history','reversibility_history','candidate_failure_history','capacity_condition_history'];
export const MEMORY_MODES={
  none:[],
  full:[...MEMORY_FIELDS],
  minus_compatibility:MEMORY_FIELDS.filter(x=>x!=='compatibility_provenance'),
  minus_dependency:MEMORY_FIELDS.filter(x=>x!=='dependency_history'),
  minus_reversibility:MEMORY_FIELDS.filter(x=>x!=='reversibility_history'),
  minus_failure:MEMORY_FIELDS.filter(x=>x!=='candidate_failure_history'),
  minus_condition:MEMORY_FIELDS.filter(x=>x!=='capacity_condition_history'),
  only_compatibility:['compatibility_provenance'],
  only_dependency:['dependency_history'],
  only_reversibility:['reversibility_history'],
  only_failure:['candidate_failure_history'],
  only_condition:['capacity_condition_history']
};
export function hasField(mode,field){return MEMORY_MODES[mode]?.includes(field)??false;}
