import { compositionWorlds } from '../experiment1h/fixtures.js';
const clone=x=>JSON.parse(JSON.stringify(x));

// Minimal provenance metadata attached to capacities. These are observed labels, not hidden truth.
const defaultDeps={
  evidence_access:'EVIDENCE_A', affected_standing:'PUBLIC_B', technical_competence:'TECH_C',
  review_authority:'INSTITUTION_D', cross_boundary_access:'INSTITUTION_D', data_portability:'EVIDENCE_A'
};

export const memoryWorlds={};
for(const [name,steps0] of Object.entries(compositionWorlds)){
  memoryWorlds[name]=steps0.map((s,i)=>{
    const x=clone(s);
    x.dependency_provenance={...defaultDeps};
    x.memory_event_id=`${name}:${x.time}`;
    // In the competing-partials world, the tempting institutional pair shares provenance.
    if(name==='competing_partials') x.dependency_provenance={...defaultDeps,review_authority:'ORG_X',cross_boundary_access:'ORG_X'};
    // In the path-dependency world, authority is visibly lock-sensitive after the first failed assembly.
    x.lock_sensitive_capacities=[...(x.lock_on_failed_attempt??[])];
    // Observed degradation is defined only by prior-to-current observed changes, never hidden true state.
    return x;
  });
}
