# FSP-CEG-BIG-STAG-EXPERIMENTAL-ARCHIVE-1.1

## Status
**PASS — EXECUTABLE REPRODUCIBILITY PACKAGE ASSEMBLED AND FRESH-RUN VERIFIED**

Archive 1.1 upgrades Archive 1.0 by recovering and binding the executable corpus behind the FSP / Corrigible Ethical Governance (CEG) / BIG STAG synthetic experimental line.

The ChatGPT Library recovery pass located the exact historical ZIP packages for:
- UCP-XR-EXPERIMENT-2 through 2F;
- FSP-RECURSIVE-INQUIRY-2;
- FSP-EMERGENT-LEVELS-1;
- the earlier 1C, 1E–1M sequence relevant to router bounds, route decay, situated recomposition, memory, partial observation, and contested history.

Two canonical runnable snapshots were freshly verified:
- `UCP-XR-EXPERIMENT-2F-CHANNEL-ABLATION`: **269/269 PASS**
- `FSP-EMERGENT-LEVELS-1`: **300/300 PASS**

See `06_executable_corpus/QUICK-REPRODUCTION.md` and the preserved fresh rerun receipts.

## Reproducibility scope
This archive supports computational reproducibility of the recovered synthetic model lineage in the included Node.js environment and source corpus. It does **not** establish external empirical validity or real-world effectiveness.

**Architectural coherence ≠ demonstrated effectiveness.**

**Execution inside a model ≠ causal validity in the world.**

## Historical packages
The exact recovered ZIP files are preserved unchanged under:
`06_executable_corpus/historical_packages/`

## Runnable snapshots
The canonical current runnable snapshots are under:
`06_executable_corpus/runnable_snapshots/`

## Public archive readiness
This package is ready for a GitHub release and Zenodo deposit after:
1. selecting an explicit license;
2. creating the public repository/release;
3. inserting the repository URL and eventual DOI into `CITATION.cff`.

The DOI should identify the immutable public release, not the living development repository.


## Publication metadata

This publication tree includes both `.zenodo.json` and `CITATION.cff`. Zenodo should use `.zenodo.json` as its authoritative GitHub-release metadata; `CITATION.cff` remains for GitHub citation display.

The public release is not complete until the license decision is explicitly resolved and the Zenodo version DOI is bound back into the archive metadata.
