# PUBLICATION GATE — GitHub / Zenodo DOI

## Current disposition
**GO for public executable archive preparation.**

The executable corpus has been recovered and fresh-run verified.

## Remaining publication tasks
1. Select explicit license(s) for code and prose.
2. Create a dedicated public GitHub repository or release location.
3. Commit the exact Archive 1.1 contents without modification.
4. Tag the release, recommended: `v1.1.0`.
5. Verify the release ZIP/checksums against this archive.
6. Connect the repository/release to Zenodo.
7. Mint the Zenodo version DOI.
8. Insert the version DOI and repository URL into `CITATION.cff`, README, and the essay's methods/provenance note.

## Public claim now supported by this package
“The archived synthetic experimental lineage is computationally rerunnable from the preserved source, fixtures, and tests; fresh archive verification reproduced 269/269 tests for the BIG STAG 2F lineage and 300/300 tests for the inherited emergence lineage.”

## Claim ceiling
Computational reproducibility does not establish empirical or normative validity.
