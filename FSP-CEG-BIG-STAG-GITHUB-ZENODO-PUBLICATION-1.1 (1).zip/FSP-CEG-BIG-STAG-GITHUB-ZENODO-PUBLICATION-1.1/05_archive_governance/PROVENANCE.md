# PROVENANCE MAP

| Claim / experimental result | Recovered source | Status in Archive 1.0 |
|---|---|---|
| BIG STAG population-level plurality, minority preservation, Return-driven recomposition | `02_big_stag_experiments/EXPERIMENT-2-AUDIT.md` | Exact audit recovered |
| Aggregation vulnerability: vote splitting, agenda dependence, bloc concentration, participation loss | `02_big_stag_experiments/EXPERIMENT-2A-AUDIT.md` | Exact audit recovered |
| Procedural-fragility recognition with scoped REOPEN commitment | `EXPERIMENT-2B-AUDIT.md` + `ACCEPTANCE-RECORD-2B.md` | Audit + acceptance recovered |
| Matched vs blanket reopening comparison | `EXPERIMENT-2C-AUDIT.md` + `ACCEPTANCE-RECORD-2C.md` | Audit + acceptance recovered |
| False positives, missed fragility, trigger capture, stale reopening, irrecoverable topology | `EXPERIMENT-2D-AUDIT.md` + `ACCEPTANCE-RECORD-2D.md` | Audit + acceptance recovered |
| Return-network decomposition into detection, transmission, reception, standing, escalation, reconstruction, termination | `EXPERIMENT-2E-AUDIT.md` + `ACCEPTANCE-RECORD-2E.md` | Audit + acceptance recovered |
| Recursive decomposition with explicit remainder | `03_recursive_emergence/FSP-RECURSIVE-INQUIRY-2.md` | Exact conceptual/build record recovered |
| Organizational/explanatory emergence, multiple realizability, bounded explanatory autonomy, downward constraint | `FSP-EMERGENT-LEVELS-1.md`, audit, acceptance record | Exact records recovered |
| Router collapse / diagnostic dependence | `04_reference_essays/FSP-ESSAY-EMERGENCE-1.docx` | Synthesis recovered; unique executable artifact not yet bound |
| Route decay | same | Synthesis recovered; unique executable artifact not yet bound |
| Sticky historical memory | same | Synthesis recovered; unique executable artifact not yet bound |
| Contested historical analogy | same | Synthesis recovered; unique executable artifact not yet bound |
| Full computational rerun of 2–2E and emergence tests | acceptance records refer to executable harnesses | **BLOCKED: source/fixtures/test corpus not yet recovered into archive** |

## Rule
No archive statement upgrades a documentary record into an executable record. Missing execution artifacts are reported as missing rather than reconstructed from prose.
