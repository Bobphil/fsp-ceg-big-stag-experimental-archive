# LICENSE DECISION — REQUIRED BEFORE PUBLIC RELEASE

No license is silently assigned by this publication build.

## Recommended dual-license structure

**Executable code:** MIT License  
**Prose, audit records, explanatory documentation, and original non-code materials:** Creative Commons Attribution 4.0 International (CC BY 4.0)

Why this combination:
- MIT is simple and widely understood for software reuse.
- CC BY 4.0 is designed for scholarly/textual materials and preserves attribution.
- Separating code and prose avoids forcing one license onto artifact types for which it is a poor fit.

## Required author decision
Before public release, explicitly adopt, reject, or modify this recommendation.

If adopted, add:
- `LICENSE-CODE` containing the MIT text;
- `LICENSE-CONTENT` containing the CC BY 4.0 notice/text or a clear pointer;
- a short licensing paragraph in README;
- `"license": "mit"` in `.zenodo.json` only if the Zenodo record is intended to characterize the software portion by MIT. If a dual-license description is preferred, describe it explicitly in the Zenodo description/notes instead of pretending the entire mixed archive is solely MIT-licensed.

No downstream user should infer reuse permissions from public visibility alone.
