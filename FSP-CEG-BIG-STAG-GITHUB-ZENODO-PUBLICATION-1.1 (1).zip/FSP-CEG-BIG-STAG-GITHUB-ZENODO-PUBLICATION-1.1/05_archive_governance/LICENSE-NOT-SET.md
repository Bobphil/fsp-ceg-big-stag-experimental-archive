# LICENSE STATUS

No license is assigned by this build.

Before public GitHub/Zenodo release, the author should choose licenses appropriate to:
- source code, if recovered;
- prose/documentation;
- datasets/fixtures/traces, if recovered.

Do not infer permission for reuse beyond rights already held by the author merely from inclusion in this archive candidate.
