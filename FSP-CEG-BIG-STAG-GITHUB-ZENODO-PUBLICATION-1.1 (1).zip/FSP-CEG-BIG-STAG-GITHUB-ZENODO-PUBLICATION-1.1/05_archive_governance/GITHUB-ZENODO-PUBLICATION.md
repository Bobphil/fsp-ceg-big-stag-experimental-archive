# GITHUB + ZENODO PUBLICATION PROCEDURE

## A. GitHub repository

Recommended repository name:

`fsp-ceg-big-stag-experimental-archive`

Recommended description:

> Executable reproducibility archive for FSP / Corrigible Ethical Governance / BIG STAG synthetic computational-philosophy experiments.

1. Create a new **public** GitHub repository with the recommended name.
2. Do not initialize it with a README, license, or .gitignore if you are uploading this prepared tree wholesale.
3. Upload/commit the complete contents of this publication build at repository root.
4. Confirm `.github/workflows/reproducibility.yml` runs successfully.
5. Confirm both CI jobs pass:
   - BIG STAG 2F: 269/269
   - Emergent Levels: 300/300
6. Resolve the license decision and commit the final license files.
7. Replace `REPOSITORY_URL_TO_BE_ADDED` in `CITATION.cff`.
8. Tag the exact release commit `v1.1.0`.
9. Create GitHub Release **v1.1.0** using `RELEASE-NOTES-v1.1.0.md`.

## B. Zenodo

Zenodo's GitHub integration archives new GitHub releases after the repository has been enabled.

1. Sign in to Zenodo.
2. Link the GitHub account if it is not already linked.
3. Open Zenodo's GitHub integration.
4. Sync repositories.
5. Enable `fsp-ceg-big-stag-experimental-archive`.
6. Publish GitHub Release `v1.1.0` (or, if already published after enabling, use Zenodo's release controls as documented).
7. Wait for Zenodo ingestion and inspect the record.
8. Confirm that `.zenodo.json` metadata was used.
9. Record the **version DOI** for v1.1.0.
10. Add the DOI back to:
    - README
    - CITATION.cff
    - the clean computational-prosthesis essay methods/provenance note
    - any public project index.

## Important Zenodo metadata behavior
This repository contains both `.zenodo.json` and `CITATION.cff`.
Zenodo gives `.zenodo.json` precedence for GitHub release archiving.
GitHub can still use `CITATION.cff` to display a citation suggestion.

## DOI rule
Published claims should cite the immutable **version DOI** that supports them, not merely the moving GitHub default branch.

## Optional manual-deposit route
If you want the DOI embedded inside files before publication, create a Zenodo draft manually and reserve a DOI first. Then insert that reserved DOI into the archive before uploading/publishing the record.
