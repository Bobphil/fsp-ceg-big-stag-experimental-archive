# DOI BINDING RECORD

Status: **PENDING ZENODO PUBLICATION**

Repository: `REPOSITORY_URL_TO_BE_ADDED`  
GitHub release tag: `v1.1.0`  
Zenodo version DOI: `DOI_TO_BE_ADDED`  
Zenodo concept DOI: `CONCEPT_DOI_TO_BE_ADDED_IF_ASSIGNED`

## Binding rule
The clean essay and future scholarly references should cite the **version DOI** for the specific frozen archive used to support their reproducibility claims.
