# CLAIM CEILING

This archive concerns **synthetic computational philosophy experiments** and their internal audit record.

It can support bounded claims such as:
- a specified synthetic fixture produced the recorded authorization sequence;
- particular aggregation pathologies occurred under the frozen cases described in the audit;
- particular distinctions became executable inside the documented architecture;
- specified test/invariant counts were reported as passing in the recovered acceptance records;
- later emergence builds reported organization-ablation, multiple-realizability, robustness, and downward-constraint probes inside the stated model boundary.

It does **not** establish:
- empirical prevalence of the modeled failure modes;
- causal validity in real institutions;
- superiority of plurality, BIG STAG, CEG, FSP, or UCP for real governance;
- normative legitimacy of any modeled policy;
- strong ontological emergence;
- public computational reproducibility until the executable corpus is archived and independently rerunnable.

Permanent firewalls:

**Architectural coherence ≠ demonstrated effectiveness.**

**Execution inside a model ≠ causal validity in the world.**

**Plurality selection ≠ truth.**

**Authorization ≠ consensus.**

**Action closure ≠ inquiry closure.**
