# REPRODUCIBILITY

## Status
**FULL EXECUTABLE CORPUS RECOVERED FOR THE ARCHIVED LINEAGE — FRESH RERUN PASS**

The earlier Archive 1.0 reproducibility blocker has been resolved by exact Library recovery of the historical ZIP packages.

### Fresh verification
- UCP-XR-EXPERIMENT-2F-CHANNEL-ABLATION: `npm run test:all` → **269/269 PASS**
- FSP-EMERGENT-LEVELS-1: `npm run test:all:emergent-levels` → **300/300 PASS**

Environment:
- Node v22.16.0
- npm 10.9.2

No external npm dependencies are declared in the recovered `package.json` files used for these reruns.

## What “reproducible” means here
A third party with Node.js can rerun the included deterministic synthetic test harnesses from the archived source and fixtures and compare the results to the fresh receipts preserved in this archive.

It does not mean:
- the models have been empirically validated against real institutions;
- the outputs estimate real-world probabilities;
- the governance procedures are normatively superior;
- external effectiveness has been demonstrated.

## Canonical command
From `06_executable_corpus/runnable_snapshots/FSP-EMERGENT-LEVELS-1`:

`npm run test:all:emergent-levels`

Expected:
- tests: 300
- pass: 300
- fail: 0
