# FSP-EMERGENT-LEVELS-1 — Audit

## Question
Can FSP, CEG, and BIG STAG preserve a recursively recurring governed-inquiry grammar while treating coalition, institutional, Return-network, and constitutional organization as genuinely distinguishable explanatory levels rather than reducible enlargements of individual PRF inquiry?

## Source lineage
Exact base: `FSP-RECURSIVE-INQUIRY-2.zip`.

The build preserves the prior negative results:
- strict decomposition without remainder is rejected;
- strict failure-isomorphism is rejected;
- scale-specific primitives remain explicit;
- information metrics cannot assign standing or authorization.

Integrity audit: **291 inherited files byte-identical; 0 unexpected changes.** `package.json` was extended only to expose the new tests.

## Emergence stance tested
The build does not assume strong emergence. It distinguishes:

1. **Organizational dependence** — the macrostate depends on lower-level components as organized.
2. **Relational novelty** — the higher level introduces predicates constituted by relations among components.
3. **Multiple realizability** — distinct microconfigurations instantiate the same macrostate.
4. **Robustness** — the macrostate is recoverable through several independent indicators.
5. **Bounded explanatory autonomy** — organization-level variables add counterfactual predictive leverage over an inventory-only description.
6. **Downward constraint** — higher-level organization changes the opportunity field of lower-level agents through rules, channels, permissions, sanctions, and commitments.

## Formal probes
For every modeled emergent scale, the same lower-level component inventory is evaluated in an organized and an organization-ablated state.

| Level | Organized macrostate | Organization-ablated state | Inventory-only score | Organization-aware score |
|---|---|---|---:|---:|
| Task-space coalition | TASK_SPACE_COALITION | FRAGMENTED_PRFS | 1/2 | 2/2 |
| Institutional/plurality | AUTHORIZED_P2 | NO_VALID_AUTHORIZATION | 1/2 | 2/2 |
| Return network | REOPEN_UPTAKE | RETURN_PATH_DEGRADED | 1/2 | 2/2 |
| Constitutional/meta-governance | META_REOPEN | CONSTITUTIONAL_STASIS | 1/2 | 2/2 |

The inventory-only probe is intentionally modest: it represents a description of which components are present but not how they are related. It is **not** a proxy for every possible microphysical or individualist theory. The result therefore establishes bounded organizational explanatory leverage, not in-principle underivability.

## Multiple realizability
Each emergent macrostate has two distinct frozen realizations:
- different PRF membership/reason structures can realize a task-space coalition;
- different coalition distributions can realize the same bounded authorization;
- different message paths can realize REOPEN uptake;
- different failure histories can realize constitutional meta-REOPEN.

This supports the use of higher-level variables across heterogeneous lower-level realizations.

## Robustness
Every frozen realization carries at least three independent positive indicators of its macrostate. This prevents emergence from being established merely by a single code label.

## Downward constraint
The executable `OPPORTUNITY_SET_CONSTRAINT` mechanism holds PRF beliefs and warrants fixed while a higher-level rule changes available actions. This represents downward influence as a change in the situated field, not as a new unexplained causal force.

This is especially compatible with FSP: higher-level organization changes what lower-level agents can perceive, communicate, authorize, or do because the relations and rules partly constitute their current situation.

## Literature comparison
The build is deliberately plural about emergence theory.

- **Anderson:** motivates the distinction between decomposition and successful construction/explanation at a new level.
- **Wimsatt:** motivates the organization-ablation test and failure of simple aggregativity.
- **Bedau:** motivates a stronger future test for macro-properties derivable only by simulation; this build does not yet establish that condition.
- **Sawyer:** supplies a close methodological precedent for using multi-agent simulation to investigate social emergence and methodological individualism.
- **Mitchell:** supports integrated multilevel explanation and robustness rather than elimination of higher-level models.
- **Kim/exclusion debate:** supplies a reason not to infer strong downward causation merely from higher-level explanatory usefulness.

## Result
The best-supported reading is neither strict reduction nor strong emergence:

> **recursive governed inquiry with organizational and explanatory emergence.**

The same corrigibility grammar recurs, but higher organization introduces new relational objects and governance primitives with their own counterfactual and explanatory roles.

## Important negative results / boundaries
- The individual PRF is a **modeled base**, not an asserted metaphysical fundamental.
- The build does not test emergence from neural/cognitive processes to PRF inquiry.
- The build does not show Bedau-style derivability only by simulation.
- The build does not establish strong ontological novelty or violation of causal closure.
- The higher-level vocabulary may in principle be reconstructible by a richer lower-level relational theory.
- The frozen macro variables are candidate explanatory kinds, not uniquely privileged kinds.

## Strongest current claim
> **Recurrence of governed inquiry grammar does not entail reduction of level. Organized relations among situated agents can support stable, multiply realizable higher-level structures whose variables add explanatory and intervention-relevant content while remaining dependent on lower-level realization.**
