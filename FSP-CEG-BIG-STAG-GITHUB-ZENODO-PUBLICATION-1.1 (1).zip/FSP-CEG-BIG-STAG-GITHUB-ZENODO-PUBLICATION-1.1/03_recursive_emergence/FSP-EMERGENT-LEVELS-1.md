# FSP-EMERGENT-LEVELS-1
## Organizational Emergence, Explanatory Autonomy, Scale-Specific Primitives, Multiple Realizability, Downward Constraint, and Recursive Inquiry Without Reduction

## Starting problem
FSP-RECURSIVE-INQUIRY-2 rejected two strong reductionist-looking claims: decomposition without remainder and strict failure-isomorphism. Each modeled scale retained scale-specific primitives even while sharing a recurring corrigibility grammar.

This build asks whether that remainder is merely an unfinished decomposition or evidence that higher organizational levels are legitimate explanatory objects in their own right.

## Core thesis under test
> **The inquiry grammar recurs across levels because organized systems repeatedly face problems of partial representation, bounded action, consequence, and revision. But each new level can generate genuinely new relational structures, primitives, constraints, and explanatory objects. Recurrence of grammar does not entail reduction of level.**

The build does **not** test or assume strong metaphysical emergence. It tests a bounded thesis of **organizational emergence plus explanatory autonomy**.

## Model boundary
The **individual PRF is the modeled base level**. The present build does not reduce PRF inquiry into neural, cognitive, biological, or phenomenological subprocesses. Emergence below the PRF boundary remains open.

The tested emergent transitions are:

1. individual PRFs → task-space PRF coalition;
2. task-space coalitions → institutional/plurality authorization;
3. institutional/task-space actors → Return network;
4. recurrent institutional/network failures → constitutional/meta-governance.

## Test 1 — Dependence
A higher-level pattern must depend on lower-level components **as organized**, not merely on their presence.

The fixtures therefore hold component inventories fixed and ablate an organizing relation:

- shared-task relation at coalition level;
- valid procedure at institutional level;
- channel topology at Return-network level;
- counter-authority at constitutional level.

In every modeled case the macrostate changes when organization is removed.

**Result:** dependence is supported inside the model.

This is anti-eliminative without being dualistic: no higher level floats free of its realizing organization.

## Test 2 — Novelty
Each higher level introduces relational predicates that are not naturally predicates of isolated lower-level components.

Examples:

- an isolated PRF is not itself a **membership relation** or **joint commitment**;
- an isolated coalition is not itself **institutional standing** or **coercive authority**;
- an isolated receiver is not itself **network reachability** or **cross-trigger capacity**;
- an isolated institution is not itself **constitutional counter-authority** or a **rule-revision procedure**.

**Result:** scale-specific primitive novelty is supported as an organizational/explanatory claim.

This does not prove metaphysical irreducibility.

## Test 3 — Multiple realizability
For every modeled emergent level, at least two materially different lower-level configurations instantiate the same higher-level macrostate.

Examples include:

- differently composed PRF groups with different reason families forming the same kind of task-space coalition;
- different coalition configurations yielding the same bounded authorization;
- different message paths yielding successful REOPEN uptake;
- different recurrent failure histories yielding constitutional meta-REOPEN.

**Result:** the higher-level categories are not one-to-one labels for a single microconfiguration.

## Test 4 — Robustness
A macrostate should not exist merely because the code gives it a label. Each macrostate is therefore required to be recoverable through at least three independent indicators.

For example, task-space coalition status is jointly indicated by shared-task persistence, coordinated proposal formation, and continued membership; Return-network uptake is indicated by review receipt, warrant update, and escalation availability.

**Result:** the modeled levels satisfy this bounded robustness criterion.

## Test 5 — Explanatory autonomy
The strongest nonreductive test in this build is counterfactual rather than verbal.

For each level, an **inventory-only predictor** sees the same lower-level components before and after an organizational intervention. An **organization-aware predictor** also sees the relations among those components.

When organization is ablated while component inventory is held fixed:

- the inventory-only description predicts no change;
- the organization-aware description correctly predicts a changed macrostate.

Thus organization-level variables add explanatory/predictive leverage over a mere inventory of lower-level parts.

**Result:** bounded explanatory autonomy is supported.

This is not the claim that no complete lower-level theory could reproduce the result. It is the claim that the organization-level variable captures counterfactual structure that the chosen component inventory omits.

## Test 6 — Downward constraint without mysterious downward force
The build represents higher-level influence by changing the **situated opportunity set** of lower-level PRFs while leaving their intrinsic belief/warrant state untouched unless a separate inquiry update occurs.

Examples include:

- institutional standing rules changing who may trigger review;
- coalition commitments changing which joint actions remain available;
- channel architecture changing which Return messages can reach review;
- constitutional rules changing institutional competence and termination authority.

The executable mechanism is labeled:

> **OPPORTUNITY_SET_CONSTRAINT**

This is intentionally weaker and clearer than positing an extra higher-level causal force. Higher-level organization acts through rules, relations, channels, permissions, sanctions, and structured environments that change what lower-level agents can do.

## Recursive inquiry without reduction
FSP-RECURSIVE-INQUIRY-2 identified a shared six-part corrigibility kernel:

1. Situated Input
2. Loss-Aware Compression
3. Bounded Authorization
4. Preserved Residue
5. Return Detectability
6. Selective Decompression/Recomposition

FSP-EMERGENT-LEVELS-1 retains that recurrence while rejecting the inference that recurrence entails identity.

Every higher level shares the grammar **and** adds scale-specific primitives.

So the supported architecture is:

> **shared recursive grammar + organizational dependence + scale-specific novelty + multiple realizability + explanatory autonomy + downward constraint**

not:

> one identical process repeated at larger size.

## Relation to emergence literature
The build uses six literature lenses as comparators rather than authorities.

- **Philip Anderson** motivates the distinction between reduction of a system to constituents and successful construction/explanation of higher-level organization.
- **William Wimsatt** motivates testing emergence through organization sensitivity and failures of simple aggregativity.
- **Mark Bedau** motivates a stronger future test in which macro-patterns may be obtainable from microdynamics only by running the simulation.
- **R. Keith Sawyer** is especially close methodologically: multi-agent simulation can test social emergence and limits of methodological individualism.
- **Sandra Mitchell** motivates integrated multilevel explanation rather than elimination of higher-level models.
- **The Kim/exclusion debate** motivates caution about strong causal emergence; this build therefore treats downward influence as organized constraint on lower-level possibilities.

See `EMERGENCE-LITERATURE-MAP.csv` and `REFERENCES.md`.

## What this build establishes
Inside the bounded formal model:

- higher-level states depend on lower-level components as organized;
- higher levels introduce stable relational primitives absent from isolated component inventories;
- distinct microconfigurations can realize the same macrostate;
- macrostate identification is robust across multiple indicators;
- organization-aware variables have counterfactual explanatory leverage over component inventory alone;
- higher-level organization can constrain lower-level situated action without altering intrinsic beliefs by fiat;
- recursive inquiry can therefore be nonreductive.

## What this build does NOT establish
It does not establish:

- strong ontological emergence;
- violation of physical causal closure;
- irreducibility in principle to a hypothetical complete lower-level science;
- that the chosen higher-level variables are uniquely correct;
- that explanatory usefulness proves metaphysical autonomy;
- that the PRF is itself a nonemergent or fundamental unit;
- that every real institution will exhibit the modeled emergence criteria.

## Current strongest thesis
> **FSP, CEG, and BIG STAG are recursively related without being strictly reductive. Higher-level governance structures depend on lower-level situated agents and their interactions, yet organization can generate stable relational primitives, explanatory variables, constraints, and failure modes that are not captured by inventories of the lower-level units alone.**

And therefore:

> **Recurrence of governed inquiry grammar does not entail reduction of level.**

## Deepest candidate principle after the emergence pass
> **Intelligent situated action requires loss-aware compression. Corrigible organization requires both recoverability across levels and respect for the genuinely new relations, powers, constraints, and responsibilities that arise when situated agents become organized into higher-level task spaces and institutions.**

## Claim ceiling
> **Organizational dependence + multiple realizability + bounded explanatory autonomy ≠ proof of strong ontological emergence.**

The present result supports **organizational and explanatory emergence** within the formal architecture, while preserving explicit dependence on lower-level realization and leaving stronger metaphysical claims open.
