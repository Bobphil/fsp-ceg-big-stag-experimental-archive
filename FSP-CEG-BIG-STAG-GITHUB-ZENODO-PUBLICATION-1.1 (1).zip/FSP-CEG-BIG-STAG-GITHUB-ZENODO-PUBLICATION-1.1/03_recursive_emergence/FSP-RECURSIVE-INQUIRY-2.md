# FSP-RECURSIVE-INQUIRY-2
## Remainder, Failure Recurrence, Minimal Corrigibility Invariants, Sufficient Decompression, and an Information-Theoretic Bridge

### Starting principle
**Intelligent situated action requires compression. Corrigible situated action requires preserving the means of decompression.**

FSP formulation:
> **Act through partial maps, but preserve enough of what the map leaves out that consequential failure can force the map to reopen.**

## Purpose
This build attacks five claims left open by FSP-RECURSIVE-INQUIRY-1:
1. decomposition without remainder;
2. failure-isomorphism across scales;
3. the minimal invariant set shared across scales;
4. a non-regress stopping condition for sufficient decompression;
5. an information-theoretic bridge that remains descriptively useful without reducing standing, authorization, or legitimacy to information metrics.

## 1. Decomposition without remainder — REJECTED
The strong claim fails. Every scale can be decomposed into lower-level inquiry operations, but every scale also retains explicit primitives that are not eliminated by that decomposition.

| Scale | Lower-level decomposition | Explicit remainder |
|---|---|---|
| Individual PRF | attention; differentiation; partial-map construction; bounded judgment; action; consequence monitoring; revision | embodied access; first-person attention |
| Task-space coalition | member inquiries; compatibility comparison; shared-task compression; conditional commitment; proposal; Return; recomposition | membership relation; alternative-warrant convergence; joint commitment |
| Institutional/plurality | coalition comparison; proposal compression; procedural selection; bounded authorization; action; Return; REOPEN | standing allocation; plurality procedure; coercive authority |
| Return network | source inquiry; encoding; routing; transmission; reception; warrant update; escalation/reconstruction; termination assessment | channel topology; latency/fidelity; receiver obligation; termination authority |
| Constitutional | cross-case inquiry; failure aggregation; rule compression; meta-authorization; redesign; systemic Return; meta-REOPEN | meta-warrant; counter-authority; constitutional amendment/reallocation |

Thus the supported claim is **recursive decomposition with explicit remainder**, not reduction without remainder.

## 2. Failure-isomorphism — PARTIAL, NOT STRICT
Strict failure-isomorphism also fails. Three failure families recur across all five scales:
- representation/map substitution;
- residue loss;
- premature closure.

Other failures recur only at some scales:
- standing failure;
- channel failure;
- capture;
- stale reopening.

And each scale retains failures tied to its own primitives:
- embodied-access failure;
- membership fragmentation;
- coercive-authority misallocation;
- routing-latency failure;
- meta-authority lock-in.

The stronger result is therefore **failure-family recurrence plus scale-specific pathology**, not one-to-one failure identity.

## 3. Minimal shared corrigibility kernel
The build identifies six candidate invariants shared across all five scales:

1. **Situated Input** — inquiry begins from a bounded field rather than an unsituated view from nowhere.
2. **Loss-Aware Compression** — an actionable representation is formed while omitted distinctions remain explicit as omissions.
3. **Bounded Authorization** — the compression licenses only specified action; it does not become truth.
4. **Preserved Residue** — relevant provenance, alternatives, minority warrants, or other recovery substrate survive compression.
5. **Return Detectability** — consequences can become evidence that the compression is inadequate.
6. **Selective Decompression and Recomposition** — action-sensitive distinctions can be restored and a new actionable compression formed.

Ablating any one makes the formal admissibility model fail. This is an architectural minimality result inside the model, not a proof of metaphysical necessity.

## 4. Non-regress stopping condition: sufficient decompression
Decompression need not recover everything. It is sufficient for the present task when:

- the current trigger has been addressed;
- the distinctions relevant to that trigger have been recovered (or explicitly classified as irrecoverable);
- affected standing is represented;
- authorization can be reassessed;
- no currently action-sensitive omitted distinction remains open;
- residual uncertainty is recorded; and
- a future REOPEN route is preserved.

When these conditions hold, the system may **RECOMPOSE** rather than continue decompression indefinitely.

### Irrecoverability rule
If an action-sensitive distinction cannot be recovered locally, the system must not recurse locally forever. If an escalation/meta-REOPEN route exists, local decompression terminates by escalating the problem. If no such route exists, corrigibility has failed at that level.

This yields:
> **Sufficient decompression ≠ total decompression.**

and:
> **Stopping inquiry locally ≠ declaring inquiry finally closed.**

## 5. Information-theoretic bridge with a normative firewall
The build permits descriptive metrics such as:
- compression ratio;
- preserved-residue ratio;
- Return-signal sensitivity.

These can describe how much complexity is made active, how much recoverability is retained, and how much error-signaling capacity remains.

But the interface explicitly prohibits these metrics from assigning:
- standing;
- authorization;
- legitimacy.

Those remain externally supplied normative-governance fields.

Thus:
> **Information loss can describe a governance problem without deciding who ought to count, who may act, or what action is legitimate.**

and:
> **Recoverability is partly informational; standing and authorization are not reducible to recoverability.**

## Revised recursive thesis
The evidence now supports a more precise claim:

> **FSP, CEG, and BIG STAG instantiate a recurring governed-inquiry grammar whose scales share a minimal corrigibility kernel, while retaining irreducible scale-specific primitives and failure modes. Higher-level operations are decomposable into lower-level inquiry operations plus explicit remainder, not reducible without remainder.**

## Strongest current principle
> **Intelligent situated action requires loss-aware compression. Corrigible situated action requires preserving enough residue, Return capacity, standing, and selective decompression routes to recover action-sensitive distinctions when consequences make them matter again.**

## Claim ceilings
- Recursive recurrence ≠ strict formal homology.
- Decomposition ≠ reduction without remainder.
- Failure-family recurrence ≠ failure-isomorphism.
- Minimality inside this formal model ≠ proof that no other invariant formulation is possible.
- Sufficient decompression rule ≠ universal real-world stopping rule.
- Information metrics ≠ normative standing, authorization, legitimacy, or truth.
