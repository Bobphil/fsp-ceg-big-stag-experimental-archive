# Release v1.1.0 — Executable Reproducibility Archive

## FSP-CEG-BIG-STAG Experimental Archive 1.1

This release upgrades the earlier documentary/audit archive by recovering and binding the executable experimental corpus.

### Fresh verification
- BIG STAG / UCP-XR Experiment 2F inherited harness: **269/269 PASS**
- FSP Emergent Levels inherited harness: **300/300 PASS**
- Node.js: **v22.16.0**
- npm: **10.9.2**

### Included
- exact recovered historical ZIP packages for the Experiment 2–2F lineage;
- earlier 1C and 1E–1M packages relevant to diagnostic bounds, route decay, situated recomposition, memory, partial observation, and contested history;
- `FSP-RECURSIVE-INQUIRY-2`;
- `FSP-EMERGENT-LEVELS-1`;
- runnable source snapshots;
- audits and acceptance records;
- fresh rerun receipts;
- provenance and recovery ledgers;
- claim ceilings;
- SHA-256 checksum inventory;
- GitHub Actions reproducibility workflow;
- Zenodo and GitHub citation metadata.

### Claim ceiling
This release establishes computational rerunnability of the included deterministic synthetic architectures. It does **not** establish empirical validity, external effectiveness, real-world prevalence, or normative superiority.

**Architectural coherence ≠ demonstrated effectiveness.**

**Execution inside a model ≠ causal validity in the world.**
